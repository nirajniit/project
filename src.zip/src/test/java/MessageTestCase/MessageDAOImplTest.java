package MessageTestCase;

import static org.junit.Assert.*;

import org.junit.Test;

public class MessageDAOImplTest {

	@Test
	public void test() {
		
		
		
		assert(true);
	}

}
