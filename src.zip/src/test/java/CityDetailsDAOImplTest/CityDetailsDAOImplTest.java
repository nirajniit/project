package CityDetailsDAOImplTest;

import java.util.Iterator;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import dao.CityDetailsDAO;
import dao.CountryDetailsDAO;
import daoimpl.CityDetailsDAOImpl;
import daoimpl.CountryDetailsDAOImpl;
import model.CityDetails;
import model.CountryDetails;

public class CityDetailsDAOImplTest {

	@Test
	public void test() {
		
			
			assert(true);
	}
	
	

	@Ignore
	@Test
	public void addCityTest(){
		
		System.out.println("====================================");
		System.out.println(" ==  addCityTest() : JUnitTesting");
		System.out.println("====================================");
		
		
		CityDetailsDAO citydetailsDAO = new CityDetailsDAOImpl();
		CityDetails citydetails = new CityDetails();
		
		
		
		citydetails.setCountryId("971");
		citydetails.setCityId("200");
		citydetails.setCityName("Dubai9");
		
		boolean flag = citydetailsDAO.addCity(citydetails);
		
		
		
		assert(flag);
}
	
	

	
	
    @Ignore
	@Test
	public void deleteCitybyIdTest() {
	
		System.out.println("=======================================");
		System.out.println(" == deleteCitybyIdTest() : JUnitTesting");
		System.out.println("=======================================");
	
		
		CityDetailsDAO cityDetailsDAO = new CityDetailsDAOImpl();
		CityDetails citydetails=new CityDetails();
		citydetails.setCityId("101");
		
		boolean flag  =cityDetailsDAO.deleteCity(citydetails);
		assert(flag);
}
	
////////////////////////// Fetch all COUNTRY ============================

//   @Ignore
	@Test
	public void getallCitiesTest() {
	   System.out.println("========================================");
		System.out.println(" == getallCitiesTest() : JUnitTesting ");
		System.out.println("=======================================");
	
		CityDetailsDAO cityDetailsDAO = new CityDetailsDAOImpl();
		List <CityDetails>  allcity =cityDetailsDAO.getAllCities();
		
		 Iterator itr =  allcity.iterator();
		
		while(itr.hasNext())
		{
			
			CityDetails citydetails = (CityDetails) itr.next();
			System.out.println(citydetails);
			
			
		}
	}

//////////////////////////Search CITY By ID============================
@Ignore
@Test
public void getCityByIdTest(){

CityDetailsDAO cityDetailsDAO = new CityDetailsDAOImpl();
CityDetails citydetails=new CityDetails();
citydetails.setCityId("1");

citydetails  =cityDetailsDAO.getCityById(citydetails);

System.out.println(citydetails);
}

//////////////////////UPDATE COUNTRY==========================

@Ignore
@Test
public void updateCityByIdTest(){
	boolean flag=false;
	CityDetailsDAO cityDetailsDAO = new CityDetailsDAOImpl();
	CityDetails citydetails=new CityDetails();
	
	citydetails.setCityId("1");
	citydetails.setCityName("Dubai");
	
	
	flag  =cityDetailsDAO.updateCity(citydetails);
	
	System.out.println(citydetails);
	System.out.println("updateCityDetailsTest method running ");
	assert(true);
	
	System.out.println(flag);
	}

////////////////////// CITY By Name==========================
@Ignore
@Test
public void getCitybyNameTest(){

CityDetailsDAO cityDetailsDAO = new CityDetailsDAOImpl();
CityDetails citydetails=new CityDetails();
citydetails.setCityName("USA");

citydetails  =cityDetailsDAO.getCityByName(citydetails);


System.out.println(citydetails);

}


@Ignore
@Test
public void getCitybyCountryIdTest(){

CityDetailsDAO cityDetailsDAO = new CityDetailsDAOImpl();
CityDetails citydetails=new CityDetails();
citydetails.setCountryId("111");


List <CityDetails> citydetailsbyid  = cityDetailsDAO.getAllCitiesByCountryID(citydetails);



System.out.println(citydetailsbyid);

}





}
