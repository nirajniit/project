package TestiMonialTest;
import static org.junit.Assert.*;
import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;
import java.util.List;
import javax.transaction.Transactional;
import java.util.Date;
import org.hibernate.engine.jdbc.BlobProxy;
import org.junit.Ignore;
import org.junit.Test;
import dao.TestimonialDetailsDAO;
import daoimpl.TestimonialDetailsDAOImpl;
import model.TestimonialDetails;
public class TestiMonialTest 
{
	
	
	@Test
	public void test()
	{
		
		assert(true);
	}
	
	@Ignore
	@Test
	public void addTestimonialTest()
	{
		TestimonialDetailsDAO testimonialDetailsDAO = new TestimonialDetailsDAOImpl();
		TestimonialDetails testimonial = new TestimonialDetails();
		testimonial .setTestiMonial("About Worklooper");
		Date d = new Date();
		testimonial .setTestiMonialDateTime(d.toString());
		testimonial.setTestiMonialOrganization("Google");
		testimonial.setTestiMonialStatus("yes");
		testimonial.setUserEmail("neeraj.t@worklooper.com");
		testimonial.setApproved("N");
		testimonial.setRrating("0");
		testimonial.setTestiMonialStatus("n");
	   boolean flag =	testimonialDetailsDAO.addTestimonial(testimonial);
	   assert(flag);
	   
	}
	
	@Ignore
	@Test
	public void getTestimonialByIdTest()
	{
		
		TestimonialDetailsDAO testimonialDetailsDAO = new TestimonialDetailsDAOImpl();
		TestimonialDetails testimonialdetails=new TestimonialDetails();
		testimonialdetails.setTestiMonialId(42);
		testimonialdetails  =testimonialDetailsDAO.getTestimonialById(testimonialdetails);
		System.out.println(testimonialdetails);
	}

	@Ignore
	@Test
	public void getTestimonialByStatusTest(){
		
		TestimonialDetailsDAO testimonialDetailsDAO = new TestimonialDetailsDAOImpl();
		TestimonialDetails testimonialdetails=new TestimonialDetails();
		testimonialdetails.setTestiMonialStatus("yes");
		
		List <TestimonialDetails> currentTestimonialdetails  =testimonialDetailsDAO.getTestimonialByStatus(testimonialdetails);
		
		System.out.println(currentTestimonialdetails );	
	}
	
	@Ignore
    @Test
    
    public void deleteTestimonialTest()
    {

		TestimonialDetailsDAO testimonialDetailsDAO = new TestimonialDetailsDAOImpl();
		TestimonialDetails testimonialdetails=new TestimonialDetails();
		testimonialdetails.setTestiMonialId(28);
		boolean flag  =testimonialDetailsDAO.deleteTestimonial(testimonialdetails);
		System.out.println(testimonialdetails);
    }

	@Ignore
    @Test
	public void updateTestimonialTest(){

		TestimonialDetailsDAO testimonialDetailsDAO  = new TestimonialDetailsDAOImpl();
		TestimonialDetails testimonialDetails = new TestimonialDetails();
		
		testimonialDetails.setTestiMonialId(28);
		TestimonialDetails currentTestimonialDetails = testimonialDetailsDAO.getTestimonialById(testimonialDetails);
		currentTestimonialDetails.setTestiMonial("Y");
		
				    
	   boolean flag =	testimonialDetailsDAO.updateTestimonial(currentTestimonialDetails);
	   assert(flag);

		
	}

   @Ignore
    @Test
    
	public void updateTestimonialShowTest(){
		
		
	   
		boolean flag = false;
		TestimonialDetailsDAO testimonialDetailsDAO  = new TestimonialDetailsDAOImpl();
		TestimonialDetails testimonialDetails = new TestimonialDetails();
		testimonialDetails.setTestiMonialId(29);
		TestimonialDetails currentTestimonialDetails =testimonialDetailsDAO.getTestimonialById(testimonialDetails);
	    currentTestimonialDetails.setApproved("Y");
	    
		
	    flag = testimonialDetailsDAO.updateTestimonialShow(currentTestimonialDetails);
		assert(true);
		
	}
	
  //@Ignore
   @Test
   public void getAllTestimonialsTest()
   {
	TestimonialDetailsDAO testimonialDetailsDAO = new TestimonialDetailsDAOImpl();
	List <TestimonialDetails>  allTestimonial =testimonialDetailsDAO.getAllTestimonial();
	
	Iterator itr =  allTestimonial.iterator();
	
	while(itr.hasNext())
	{
		TestimonialDetails u = (TestimonialDetails) itr.next();
		System.out.println(u);
	}
   }

  
  
  @Ignore
  @Test
  public void getAllTestimonialsByApproved()
  {
	TestimonialDetailsDAO testimonialDetailsDAO = new TestimonialDetailsDAOImpl();
	
	TestimonialDetails testimonialDetails= new TestimonialDetails();
	testimonialDetails.setApproved("Y");
	List <TestimonialDetails>  allTestimonial =testimonialDetailsDAO.getTestimonialByApproved(testimonialDetails);
	
	Iterator itr =  allTestimonial.iterator();
	
	while(itr.hasNext())
	{
		TestimonialDetails u = (TestimonialDetails) itr.next();
		System.out.println(u);
	}
  }

  
  
  
  
  
  
  
  @Ignore
  @Test
  public void getTestimonialsByEmailTest() {
		TestimonialDetailsDAO testimonialDetailsDAO = new TestimonialDetailsDAOImpl();
		TestimonialDetails testimonialDetails = new TestimonialDetails();
		testimonialDetails.setUserEmail("neeraj.t@worklooper.com");
		
		List <TestimonialDetails> allTestimonialByEmail= testimonialDetailsDAO.getTestimonialByEmail(testimonialDetails);
		
		Iterator itr= allTestimonialByEmail.iterator();
		while(itr.hasNext())
		{
			TestimonialDetails u = (TestimonialDetails) itr.next();
			System.out.println(u);
		}
  
  }
  
}
