package JobCategoryDetailsTest;
import java.text.SimpleDateFormat ;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.junit.Ignore;
import org.junit.Test;
import dao.JobCategoryDetailsDAO;
import daoimpl.JobCategoryDetailsDAOImpl;
import model.JobCategoryDetails;

public class JobCategoryTest {
	
	@Test
	public void test() {
		assert(true);
	}
   @Ignore
	@Test	
public void SaveTest()
{

	JobCategoryDetailsDAO jobDetailsDAO=new JobCategoryDetailsDAOImpl();
	JobCategoryDetails jobDetails=new JobCategoryDetails();
	
	jobDetails.setJobTypeId("5001");
	jobDetails.setJobCategoryId("991");
	jobDetails.setJobCategoryType("Navy Force");
	jobDetails.setJobTitle("Navi");
	jobDetails.setSalary("120000");
	jobDetails.setDescription("For Navi");
    Date d = new Date();
	jobDetails.setDateTime(d.toString());
	jobDetails.setStatus("u");
	jobDetails.setQualification("PHgfdgfdD");
	boolean flag=jobDetailsDAO.saveJobCategoryDetails(jobDetails);
	assert(flag);
}
 @Ignore
 @Test	
	public void getJobDetailsByIdTest()
	{
		 JobCategoryDetailsDAO jobDetailsDAO=new JobCategoryDetailsDAOImpl();
		 JobCategoryDetails jobDetails=new JobCategoryDetails();
		 jobDetails.setJobCategoryId("212130");
		 jobDetails=jobDetailsDAO.getJobByID(jobDetails);
      
	}
 
 //@Ignore
 @Test	
	public void getJobDetailsByTitleTest()
	{
	  JobCategoryDetailsDAO jobDetailsDAO = new JobCategoryDetailsDAOImpl();
	  JobCategoryDetails jobdetails=new JobCategoryDetails();
	  jobdetails.setJobTitle("Software Developer");
	  
		List<JobCategoryDetails>  alljobDetails =jobDetailsDAO.getJobByTitle(jobdetails);
		Iterator itr =  alljobDetails.iterator();
		while(itr.hasNext())
		{
			JobCategoryDetails  u = (JobCategoryDetails) itr.next();
			System.out.println(u);
		}
		
	}
 
  @Ignore
 @Test	
	public void deleteJobDetailsTest()
	{
		JobCategoryDetailsDAO jobDetailsDAO=new JobCategoryDetailsDAOImpl();
		JobCategoryDetails jobDetails=new JobCategoryDetails();
		 jobDetails.setJobCategoryId("212132");
		boolean flag=jobDetailsDAO.deleteJobCategoryDetails(jobDetails);
		assert(flag);
	}
 
 @Ignore
 @Test	
	public void updateJobDetailsTest() throws Exception
	{
		
		JobCategoryDetailsDAO jobDetailsDAO=new JobCategoryDetailsDAOImpl();
		JobCategoryDetails jobDetails = new JobCategoryDetails();
			
		    jobDetails.setJobCategoryId("999");
			jobDetails.setJobCategoryType("Air Force");
			jobDetails.setJobTitle("Dr.");
			jobDetails.setSalary("120000");
			jobDetails.setDescription("For Made");
		
			Date d = new Date();
			jobDetails.setDateTime(d.toString());
			jobDetails.setStatus("T");
			jobDetails.setQualification("BA");
			jobDetails.setJobTypeId("5001");
			
			
		boolean flag=jobDetailsDAO.updateJobCategoryDetails(jobDetails);
		assert(flag);
		
	}
    @Ignore
	@Test	
	public void getAllJobDetailsTest()
	{
		JobCategoryDetailsDAO jobDetailsDAO = new JobCategoryDetailsDAOImpl();
		List<JobCategoryDetails>  alljobDetails =jobDetailsDAO.getAllJobDetails();
		
		Iterator itr =  alljobDetails.iterator();
		
		while(itr.hasNext())
		{
			JobCategoryDetails  u = (JobCategoryDetails) itr.next();
			System.out.println(u);
		}
		
	}
    
    @Ignore
   	@Test	
    public void getJobDetailsByTypeIdTest()
	{
	  JobCategoryDetailsDAO jobDetailsDAO = new JobCategoryDetailsDAOImpl();
	  JobCategoryDetails jobdetails=new JobCategoryDetails();
	  jobdetails.setJobTypeId("999");
	  
		List<JobCategoryDetails>  alljobDetails =jobDetailsDAO.getJobTypeId(jobdetails);
		Iterator itr =  alljobDetails.iterator();
			while(itr.hasNext())
		{
			
			JobCategoryDetails  u = (JobCategoryDetails) itr.next();
			System.out.println(u);
			
			
		}
		
	}
}
