package NewsDetailsTest;
import static org.junit.Assert.*;
import java.io.File;
import java.io.FileInputStream;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.hibernate.engine.jdbc.BlobProxy;
import org.junit.Ignore;
import org.junit.Test;
import dao.NewsDetailsDAO;
import daoimpl.NewsDetailsDAOImpl;
import model.NewsDetails;

public class NewsDetailsTest {

	@Test
	public void test() 
	{
		assert(true);
	}

	//@Ignore
	@Test
	public void addNewsTest()
	{
		
		NewsDetailsDAO newsDetailsDAO = new NewsDetailsDAOImpl();
		NewsDetails newsDetails = new NewsDetails();
		
		 newsDetails.setUserEmail("neeraj.t@worklooper.com");
		 newsDetails.setNewsTitle("News Title");
		 newsDetails.setNewsContent("Sahad leaves behind a wife and two children back in Kollam, one of 14 districts of the southern state of Kerala, India.");
		 newsDetails.setNewsAuthor("Ravi Kuamr");
		 newsDetails.setApproved("Y");
		 newsDetails.setRrating("0");
		 
		 Date d = new Date();
		 newsDetails.setNewsDate(d.toString());
		 newsDetails.setNewsImagenamne("AA.jpg");
		 
		 
		 try
		 {
		    File imagePath = new File("D://ALL Image//AA.jpg");
			byte[] imageInBytes = new byte[(int)imagePath.length()]; //image convert in byte form
			FileInputStream inputStream = new FileInputStream(imagePath);  //input stream object create to read the file
			inputStream.read(imageInBytes); // here inputstream object read the file
			inputStream.close();
		
			// newsDetails.setNewsImage(BlobProxy.generateProxy(imageInBytes));
			 
		 }
			
		catch(Exception e)
		{
		System.out.println(e);	
		}
	
	     boolean flag =	newsDetailsDAO.addNews(newsDetails);
		 assert(flag);
		 System.out.println(newsDetails);

	}
	

	@Ignore
	@Test
	public void getNewsByIdTest(){
		
		NewsDetailsDAO newsDetailsDAO = new NewsDetailsDAOImpl();
		NewsDetails newsdetails=new NewsDetails();
		newsdetails.setNewsId(151);
		
		newsdetails  =newsDetailsDAO.getNewsById(newsdetails);
		System.out.println(newsdetails );
		
	}

   @Ignore
   @Test
	public void getNewssByNameTest(){
		
		NewsDetailsDAO newsDetailsDAO = new NewsDetailsDAOImpl();
		NewsDetails newsdetails=new NewsDetails();
		newsdetails.setNewsTitle("News Title");
		
		List <NewsDetails> currentNewsdetails  =newsDetailsDAO.getNewsByTitle(newsdetails);
		
		System.out.println(currentNewsdetails );	
	}

  @Ignore
  @Test
  public void deleteNewsTest()
  {
	boolean flag =false;
	NewsDetailsDAO newsDetailsDAO = new NewsDetailsDAOImpl();
	NewsDetails newsdetails=new NewsDetails();
	newsdetails.setNewsId(102);
    flag  =newsDetailsDAO.deleteNews(newsdetails);
	System.out.println(newsdetails);
  }

  //@Ignore
  @Test
	public void updateNewssdetailsByIDTest(){

		NewsDetailsDAO newsDetailsDAO  = new NewsDetailsDAOImpl();
		NewsDetails newsDetails = new NewsDetails();
		newsDetails.setNewsId(67);
		NewsDetails currentNewsDetails =newsDetailsDAO.getNewsById(newsDetails);
		
		
		
		System.out.println(currentNewsDetails);
		currentNewsDetails.setApproved("N");
		
		
		
		/*currentNewsDetails.setUserEmail("kumar@worklooper.com");
		currentNewsDetails.setNewsTitle("Worklooper got Govt Project : It is big assignment ");
		currentNewsDetails.setNewsContent("About the Worklooper");
		currentNewsDetails.setNewsAuthor("Worklooper");
		 Date d = new Date();
		 currentNewsDetails.setNewsDate(d.toString());
		 
		 
		 try
		 {
			 File imagePath = new File("D://final//9y9te2s-free-car-wallpaper-hd.jpg");
			byte[] imageInBytes = new byte[(int)imagePath.length()]; //image convert in byte form
			FileInputStream inputStream = new FileInputStream(imagePath);  //input stream object create to read the file
			inputStream.read(imageInBytes); // here inputstream object read the file
			inputStream.close();
		
			currentNewsDetails.setNewsImage(BlobProxy.generateProxy(imageInBytes));
			 
		 }
			
		catch(Exception e)
		{
		System.out.println(e);	
		}
		 */
		
	
	     boolean flag =	newsDetailsDAO.updateNews(currentNewsDetails);
		 assert(flag);
		
		
	}

   @Ignore
   @Test
   public void getAllNewssTest()
  {
	NewsDetailsDAO newsDetailsDAO = new NewsDetailsDAOImpl();
	List <NewsDetails>  allNews =newsDetailsDAO.getAllNews();
	
	Iterator itr =  allNews.iterator();
	
	while(itr.hasNext())
	{
		NewsDetails u = (NewsDetails) itr.next();
		System.out.println(u);
	}
	
 }
   
   
   @Ignore
   @Test
   public void getAllNewssByApproved()
  {
	NewsDetailsDAO newsDetailsDAO = new NewsDetailsDAOImpl();
	NewsDetails news = new NewsDetails();
	news.setApproved("Y");
	
	List <NewsDetails>  allNews =newsDetailsDAO.getNewsByApproved(news);
	
	Iterator itr =  allNews.iterator();
	
	while(itr.hasNext())
	{
		NewsDetails u = (NewsDetails) itr.next();
		System.out.println(u);
	}
	
 } 
   
   
   
   
}
