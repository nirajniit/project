package UserDetailsTest;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Iterator;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import dao.UserDetailsDAO;
import daoimpl.UserDetailsDAOImpl;
import model.UserDetails;


public class UserDetailsDAOImplTest {
	
	@Test
	public void test()
	{
		
		System.out.println("==================================");
		System.out.println(" test() : @JunitTest Begin");
		System.out.println("==================================");
		assert(true);
		
	}
	
	
   //@Ignore
	@Test
	public void testAddUserDetails(){
		
		System.out.println("==================================");
		System.out.println(" testAddUserDetails() : @JunitTest Begin");
		System.out.println("==================================");
		
        boolean flag = false;
		
		UserDetails user = new UserDetails();
		UserDetailsDAO userDetailsDAO = new UserDetailsDAOImpl();
		
		user.setUserEmail("niit.delhi5.ind@gmail.com");
		user.setUserPassword("admin");
		user.setUserName("Niraj");
		user.setUserAddress("Worklooper Noida");
		user.setUserMobile("9650403988");
		
		
		
		
		flag = userDetailsDAO.addUserDetails(user);
		System.out.println("Flag = "+ flag);
		assert(flag);
		
		
	}
	
	@Ignore
	@Test
	public void testgetAllUserDetailstest(){
		System.out.println("==================================");
		System.out.println(" testgetAllUserDetailstest : @JunitTest Begin ");
		System.out.println("==================================");

		UserDetailsDAO userDetailsDAO = new UserDetailsDAOImpl();
		List <UserDetails> userList = userDetailsDAO.getAllUserDetails();
		Iterator items =userList.iterator();
		while(items.hasNext())
		{
			UserDetails user = (UserDetails) items.next();
			System.out.println(user);
		}
		Assert.assertNotNull(userDetailsDAO);
	}
	
	@Ignore
	@Test
	public void testdeleteUserDetailstest(){
		
		boolean flag;
		System.out.println("==================================");
		System.out.println(" testdeleteUserDetailstest :  @JunitTest Begin ");
		System.out.println("==================================");

		UserDetailsDAO userDetailsDAO  = new UserDetailsDAOImpl();
		UserDetails cserDetails = new UserDetails();
		cserDetails.setUserEmail("worklooper222@worklooper.com");
		flag = userDetailsDAO.deleteUserDetails(cserDetails);
		
		assert(true);
		
	}
	@Ignore
	@Test
	public void testupdateUserDetailstest(){

		boolean flag = false;
		UserDetailsDAO userDetailsDAO  = new UserDetailsDAOImpl();
		UserDetails cserDetails = new UserDetails();
		cserDetails.setUserEmail("abc@abc.com");
		cserDetails.setUserPassword("superuser");
		cserDetails.setUserName("Rahul");
		cserDetails.setUserAddress("Worklooper Nodia UP has changed");
		cserDetails.setUserMobile("11111111");
		cserDetails.setUserRole("adminchanged");
		cserDetails.setUserStatus("Y Changed");
		cserDetails.setUserActive("activeChanged");
		cserDetails.setUserBlock("BlockChanged");
		
		
		
		
		flag = userDetailsDAO.updateUserDetails(cserDetails);
		System.out.println(cserDetails);
		System.out.println("updateUserDetailsTest method running ");
		assert(true);
		
	}
	

	
	@Ignore
	@Test
	public void setActiveTest(){
		

		System.out.println("==================================");
		System.out.println(" setActiveTest : Junit Tesing ");
		System.out.println("==================================");
		
		
		
		boolean flag = false;
		UserDetailsDAO userDetailsDAO  = new UserDetailsDAOImpl();
		UserDetails cserDetails = new UserDetails();
		cserDetails.setUserEmail("rkkumar276306@gmail.com");
		cserDetails.setUserActive("DeActivated");
		
		cserDetails = userDetailsDAO.setActive(cserDetails);
		
		System.out.println(cserDetails);
		
		assert(true);
		
	}

	
	
	@Ignore
	@Test
	public void setBlockTest(){
		

		System.out.println("==================================");
		System.out.println(" setBlockTest : Junit Tesing ");
		System.out.println("==================================");
		
		
		UserDetailsDAO userDetailsDAO  = new UserDetailsDAOImpl();
		UserDetails cserDetails = new UserDetails();
		cserDetails.setUserEmail("rkkumar276306@gmail.com");
		cserDetails.setUserBlock("Blocked");
		
		cserDetails = userDetailsDAO.setBlock(cserDetails);
		
		System.out.println(cserDetails);
		
		assertNotNull(cserDetails);
		
	}


	@Ignore
	@Test
	public void setStatusTest(){
		

		System.out.println("==================================");
		System.out.println(" setStatusTest : Junit Tesing ");
		System.out.println("==================================");
		
		
		UserDetailsDAO userDetailsDAO  = new UserDetailsDAOImpl();
		UserDetails cserDetails = new UserDetails();
		cserDetails.setUserEmail("rkkumar276306@gmail.com");
		cserDetails.setUserStatus("Logoff");
		
		cserDetails = userDetailsDAO.setStatus(cserDetails);
		
		System.out.println(cserDetails);
		
		assertNotNull(cserDetails);
		
	}


	
	 @Ignore
	@Test
	public void setRoleTest(){
		

		System.out.println("==================================");
		System.out.println(" setRoleTest : Junit Tesing ");
		System.out.println("==================================");
		
		
		UserDetailsDAO userDetailsDAO  = new UserDetailsDAOImpl();
		UserDetails cserDetails = new UserDetails();
		cserDetails.setUserEmail("rkkumar276306@gmail.com");
		cserDetails.setUserRole("admin");
		
		cserDetails = userDetailsDAO.setRole(cserDetails);
		
		System.out.println(cserDetails);
		
		assertNotNull(cserDetails);
		
	}



	
	
	
	@Ignore
	@Test
	public void testgetUserDetailsByEmailtest()
	{
				
		System.out.println("getUserDetailsByEmailTest method running ");
		
		
		UserDetailsDAO userDetailsDAO  = new UserDetailsDAOImpl();
		
		UserDetails cserDetails = new UserDetails();
		cserDetails.setUserEmail("worklooper125@worklooper.com");
		cserDetails = userDetailsDAO.getUserDetailsByEmail(cserDetails);
		System.out.println(cserDetails);
		
		assertNotNull(cserDetails);
		
	}
	@Ignore
	@Test
	public void testvalidateUserDetailstest (){
		
		
		System.out.println("validateUserDetailsTest method running ");
		System.out.println("getUserDetailsByEmailTest method running ");
		UserDetailsDAO userDetailsDAO  = new UserDetailsDAOImpl();
		UserDetails cserDetails = new UserDetails();
		cserDetails.setUserEmail("niit.delhi.ind@gmail.com");
		cserDetails.setUserPassword("222222222");
		cserDetails = userDetailsDAO.validateUserDetails(cserDetails);
		System.out.println(cserDetails);
	    assertNotNull(cserDetails);
		
	}
	
	
	

}
