package CountryDetailsDAOImplTest;

import java.util.Iterator;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.After;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import dao.CountryDetailsDAO;

import daoimpl.CountryDetailsDAOImpl;

import model.CountryDetails;


public class CountryDetailsDAOImplTest {
	
	@Autowired
	private SessionFactory sessionFactory;
	@Test
	public void test(){
		
		
		System.out.println("  ===============================  ");
		System.out.println("  CountryDetailsDAOImplTest tested  ");
		System.out.println("  ===============================  ");
		
		assert(true);
	}
	
	
	//==================ADDDING COUNTRY=========================
	
	
    @Ignore
	@Test
	public void addCountryTest() {
		
	   System.out.println("  ===============================  ");
	   System.out.println("  addCountryTest   ");
	   System.out.println("  ===============================  ");
	   CountryDetailsDAO cdDAO = new CountryDetailsDAOImpl();
	   CountryDetails cd = new CountryDetails();
	   cd.setCountryId("972");
	   cd.setCountryName("UAE");
	   boolean flag =	cdDAO .addCountry(cd);
	 
		assert(flag);
}
	
	
	
  //============================== DELETING COUNTRY By ID========================
  
 @Ignore
	@Test
	public void deleteCountrybyIdTest(){
	 
		CountryDetailsDAO countryDetailsDAO = new CountryDetailsDAOImpl();
		CountryDetails countrydetails=new CountryDetails();
		countrydetails.setCountryId("973");
		boolean t  =countryDetailsDAO.deleteCountrybyId(countrydetails);
		System.out.println(t);
	}
	
// ============================== Fetch all COUNTRY  ============================
// ============================== Tested By Rahul       =============================	
	
	@Ignore
	@Test
	public void getallCountriesTest()
	{
		
		
		System.out.println("=============================== ");
			System.out.println("getallCountriesTest ");
		System.out.println("=============================== ");
		
		CountryDetailsDAO countryDetailsDAO = new CountryDetailsDAOImpl();
		List <CountryDetails>  countryDetails  =  countryDetailsDAO.getallCountries();
		
		Iterator itr = countryDetails.iterator();
		while(itr.hasNext())
		{
			CountryDetails countryDetailsCurrent = (CountryDetails) itr.next();
			System.out.println(countryDetailsCurrent);
			
		}
		}
	
//////////////////////////Search COUNTRY By ID============================
	@Ignore
	@Test
	public void getCountryByIdTest(){

			
		System.out.println("  ===============================  ");
		System.out.println("  getCountryByIdTest   ");
		System.out.println("  ===============================  ");
			
		CountryDetailsDAO countryDetailsDAO = new CountryDetailsDAOImpl();
		CountryDetails countrydetails=new CountryDetails();
		countrydetails.setCountryId("3");
		
		countrydetails  =countryDetailsDAO.getCountrybyId(countrydetails);
		
		System.out.println(countrydetails);
		
		
	}
	
	//////////////////////UPDATE COUNTRY==========================

	@Ignore
	@Test
	public void updateCountryByIdTest(){
		boolean flag=false;
		CountryDetailsDAO countryDetailsDAO = new CountryDetailsDAOImpl();
		CountryDetails countrydetails=new CountryDetails();
		
		countrydetails.setCountryId("4");
		countrydetails.setCountryName("United Arab Emirate");
		
		
		flag  =countryDetailsDAO.updateCountry(countrydetails);
		
		System.out.println(countrydetails);
		System.out.println("updateCountryDetailsTest method running ");
		assert(true);
		
		System.out.println(flag);
		
		
		
	}
	

//////////////////////Get country by name==========================
	
	 @Ignore
	@Test
	public void getCountrybyNameTest(){
	
	CountryDetailsDAO countryDetailsDAO = new CountryDetailsDAOImpl();
	CountryDetails countrydetails=new CountryDetails();
	countrydetails.setCountryName("USA");
	
	countrydetails  =countryDetailsDAO.getCountrybyName(countrydetails);
	
	
	System.out.println(countrydetails);
	
	

	}

}
