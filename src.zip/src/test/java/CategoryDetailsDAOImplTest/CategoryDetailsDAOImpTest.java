package CategoryDetailsDAOImplTest;

import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;
import java.util.List;
import org.hibernate.engine.jdbc.BlobProxy;
import org.junit.Ignore;
import org.junit.Test;
import dao.CategoryDetailsDAO;
import daoimpl.CategoryDetailsDAOImpl;
import model.CategoryDetails;

public class CategoryDetailsDAOImpTest 
{

	@Test
	public void test() 
	{
		assert(true);
	}
	
	//@Ignore
	@Test
	public void addCategoryTest()
	{
		
		CategoryDetailsDAO categoryDetailsDAO = new CategoryDetailsDAOImpl();
		CategoryDetails cat = new CategoryDetails();
		//cat.setProductID("555555");
		//cat.setCatId("22531");
		cat.setCatName("Audio999999999");
		Long catID = cat.getCatId();
		cat.setCatImg("Audio3"+catID+".jpg");
		cat.setCatPrice(900977);
		cat.setCatDscription("Luxury in the this world ");
		
		cat.setCountryID("111");
		cat.setCityID("111");
		cat.setProductID(1L);
		
		
		
		
		/*
		 try
		 {
		 
		cat.setCatAudio(null);
		cat.setCatVideo(null);
		
			File imagePath = new File("D://kk.jpg");
			byte[] imageInBytes = new byte[(int)imagePath.length()]; //image convert in byte form
			FileInputStream inputStream = new FileInputStream(imagePath);  //input stream object create to read the file
			inputStream.read(imageInBytes); // here inputstream object read the file
			inputStream.close();
		
			cat.setByteCatImg(BlobProxy.generateProxy(imageInBytes));
		
		
			cat.setByteCatAudio(null);
			cat.setByteCatVideo(null);
			
		}
		catch(Exception e)
		{
			
			
		}
		
		*/
		
			
			
	
		
	   boolean flag =	categoryDetailsDAO.addCategory(cat);
	   assert(flag);

	}
	
	@Ignore
	@Test
	  public void deleteCategoryDetailsTest()
	  {
     		boolean flag =false;
	    	CategoryDetailsDAO categoryDetailsDAO = new CategoryDetailsDAOImpl();
		    CategoryDetails categorydetails=new CategoryDetails();
		    
		    Long l = 1111111L;
		    
		    categorydetails.setCatId(l);
			
		 flag  =categoryDetailsDAO.deleteCategory(categorydetails);
		
		 System.out.println(categorydetails);
		
		
	}
	
	
	@Ignore
    @Test
   public void getCategoryByIdTest(){
		
		CategoryDetailsDAO categoryDetailsDAO = new CategoryDetailsDAOImpl();
		CategoryDetails categorydetails=new CategoryDetails();
		
		
		Long l = 222222L;
		categorydetails.setCatId(l);
		
		categorydetails = categoryDetailsDAO.getCategoryById(categorydetails);
		
		System.out.println(categorydetails);
		
		
	}
	
	
	@Ignore
	@Test
	public void getCategoryByPriceTest()
	{
			
			CategoryDetailsDAO categoryDetailsDAO = new CategoryDetailsDAOImpl();
			CategoryDetails categorydetails=new CategoryDetails();
			categorydetails.setCatPrice(11122);
			List <CategoryDetails>  currentcategorydetails =  categoryDetailsDAO.getCategoryByPrice(categorydetails);
			Iterator item = currentcategorydetails.iterator();
			while(item.hasNext())
			{
				CategoryDetails curretncat =(CategoryDetails) item.next();
				System.out.println(curretncat);
			}
		}

	@Ignore 
    @Test
	   public void getCategoryByNameTest(){
			
			CategoryDetailsDAO categoryDetailsDAO = new CategoryDetailsDAOImpl();
			CategoryDetails categorydetails=new CategoryDetails();
			categorydetails.setCatName("Audi222");
			List <CategoryDetails> allcatbynamedetails = categoryDetailsDAO.getCategoryByName(categorydetails);
			System.out.println(allcatbynamedetails);
		}

    
    
	@Ignore
	@Test
	   public void getProductIdTest(){
			
			CategoryDetailsDAO categoryDetailsDAO = new CategoryDetailsDAOImpl();
			CategoryDetails categorydetails=new CategoryDetails();
			
			Long LongProductID = 11111L; 
			categorydetails.setProductID(LongProductID);
			List <CategoryDetails> allcatbyproduct  = categoryDetailsDAO.getCategoryProcutById(categorydetails);
			Iterator item = allcatbyproduct.iterator();
			while(item.hasNext())
			{
				CategoryDetails currcat =(CategoryDetails) item.next();
			    System.out.println(currcat);
			}
			
			
			
			
		}
	
	@Ignore
	@Test
	public void updateCategorydetailsByIDTest(){

		boolean flag=false;
		CategoryDetailsDAO categoryDetailsDAO  = new CategoryDetailsDAOImpl();
		CategoryDetails categoryDetails = new CategoryDetails();
		
		Long l = 22222L;
		
		categoryDetails.setCatId(l);
		
		CategoryDetails currcategoryDetails = categoryDetailsDAO.getCategoryById(categoryDetails);
		
		
		currcategoryDetails.setApproved("N");
		currcategoryDetails.setRrating("90");
	
		/*categoryDetails.setCatDscription("Swift Description");
		String catID = categoryDetails.getCatId();
		categoryDetails.setCatImg("Audio3"+catID+".jpg");
		*/
		
		
		flag = categoryDetailsDAO.updateCategory(currcategoryDetails);
		System.out.println(currcategoryDetails);
		System.out.println("updateMotorsDetailsTest method running ");
		assert(flag);
		
	}

	//@Ignore
	@Test
	public void getAllCategoryTest()
	{
		CategoryDetailsDAO categoryDetailsDAO = new CategoryDetailsDAOImpl();
		List <CategoryDetails> allCategory =categoryDetailsDAO.getAllCategory();
		
		Iterator itr =  allCategory.iterator();
		
		while(itr.hasNext())
		{
			
			CategoryDetails u = (CategoryDetails) itr.next();
			System.out.println(u);
			
			
		}
	}
}
