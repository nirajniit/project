package JobTypeDetailsTest;
import java.util.Iterator;
import java.util.List;
import org.junit.Ignore;
import org.junit.Test;
import dao.JobTypeDetailsDAO;
import daoimpl.JobTypeDetailsDAOImpl;
import model.JobTypeDetails;

public class JobTypeDetailsTest 
{
	@Test
	public void test() {
		assert(true);
}

//@Ignore
@Test	
public void SaveTest()
{
	JobTypeDetailsDAO jobTypeDetailsDAO=new JobTypeDetailsDAOImpl();
	JobTypeDetails jobTypeDetails  = new JobTypeDetails();
	
	jobTypeDetails.setJobTypeId("5003");
	jobTypeDetails.setJobType("Train Ticket Collector");
	jobTypeDetails.setCityId("100");
		
	boolean flag=jobTypeDetailsDAO.saveJobTypeDetails(jobTypeDetails);
	assert(flag);
}
	
	@Ignore
    @Test	
	public void getJobTypeDetailsByIdTest()
	{
		 JobTypeDetailsDAO jobTypeDetailsDAO=new JobTypeDetailsDAOImpl();
		 JobTypeDetails jobTypeDetails=new JobTypeDetails();
		 jobTypeDetails.setJobTypeId("5002");
		 jobTypeDetails = jobTypeDetailsDAO.getJobByTypeId(jobTypeDetails);
		 System.out.println(jobTypeDetails);
	}
	
	//@Ignore
	@Test	
	public void getJobTypeDetailsByTitleTest()
	{
	  JobTypeDetailsDAO jobTypeDetailsDAO = new JobTypeDetailsDAOImpl();
	  JobTypeDetails jobTypeDetails=new JobTypeDetails();
	  jobTypeDetails.setJobType("Train Ticket Collector");
	  
		List<JobTypeDetails>  allJobTypeDetails =jobTypeDetailsDAO.getJobByType(jobTypeDetails);
		
		Iterator itr =  allJobTypeDetails.iterator();
		
		while(itr.hasNext())
		{
			JobTypeDetails  u = (JobTypeDetails) itr.next();
			System.out.println(u);
		}
	}
	
	@Ignore
	@Test	
	public void deleteJobTypeDetailsTest()
	{
		
		JobTypeDetailsDAO jobTypeDetailsDAO=new JobTypeDetailsDAOImpl();
		
		JobTypeDetails jobTypeDetails=new JobTypeDetails();
		 jobTypeDetails.setJobTypeId("111221");
		boolean flag=jobTypeDetailsDAO.deleteJobTypeDetails(jobTypeDetails);
		assert(flag);
	}
	
    @Ignore
	@Test	
	public void updateJobTypeDetailsTest()
	{
		JobTypeDetailsDAO jobTypeDetailsDAO=new JobTypeDetailsDAOImpl();
		JobTypeDetails jobTypeDetails = new JobTypeDetails();
		jobTypeDetails.setJobTypeId("1112211");
		jobTypeDetails.setJobType("Land Army");
		jobTypeDetails.setCityId("101");
		boolean flag=jobTypeDetailsDAO.updateJobTypeDetails(jobTypeDetails);
		assert(flag);
	}
   
   @Ignore
   @Test	
	public void getAllJobTypeDetailsTest()
	{
		JobTypeDetailsDAO jobTypeDetailsDAO = new JobTypeDetailsDAOImpl();
		List<JobTypeDetails>  allJobTypeDetails =jobTypeDetailsDAO.getAllJobTypeDetails();
		Iterator itr =  allJobTypeDetails.iterator();
		while(itr.hasNext())
		{
			JobTypeDetails  u = (JobTypeDetails) itr.next();
			System.out.println(u);
		}
		
	}	
	
}
