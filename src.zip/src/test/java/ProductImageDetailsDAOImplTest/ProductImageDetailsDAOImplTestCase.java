package ProductImageDetailsDAOImplTest;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;
import java.util.List;

import org.hibernate.engine.jdbc.BlobProxy;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

import dao.ProductImageDetailsDAO;
import dao.UserDetailsDAO;
import daoimpl.ProductImageDetailsDAOImpl;
import daoimpl.UserDetailsDAOImpl;
import model.ProductImageDetails;
import model.UserDetails;
public class ProductImageDetailsDAOImplTestCase {

	@Test
	public void test() {
		System.out.println(" Test begin ");
		assert(true);
	}
	
	
	//@Ignore
	@Test
	public void testAllProductImageDetails(){
		System.out.println("==================================");
		System.out.println(" AllProductImageDetails : @JunitTest Begin ");
		System.out.println("==================================");

		ProductImageDetailsDAO productImageDetailsDAO = new ProductImageDetailsDAOImpl();
		List <ProductImageDetails> productImageDetailsList = productImageDetailsDAO.allProductImageDetails();
	    Iterator items =productImageDetailsList.iterator();
		
	    while(items.hasNext())
		{
			ProductImageDetails productImageDetails = (ProductImageDetails) items.next();
			System.out.println(productImageDetails);
		
			
		}
		Assert.assertNotNull(productImageDetailsList);
	}

	
	@Ignore
	@Test
	public void addProductImageDetailsTest()
	{
			
			boolean flag=false;
			ProductImageDetailsDAO productImageDetailsDAO = new ProductImageDetailsDAOImpl();
			ProductImageDetails productImageDetails = new ProductImageDetails();
			
			
			
			 try
			 {
			
				 // Auto Generated
				// productImageDetails.setProductImageId(productImageId);
				 
				 productImageDetails.setCatId(111L);
				 productImageDetails.setImageVideoUrl(null);
				 
		 
				 File imagePath = new File("D://kk.jpg");
				 byte[] imageInBytes = new byte[(int)imagePath.length()]; //image convert in byte form
				 FileInputStream inputStream = new FileInputStream(imagePath);  //input stream object create to read the file
				 inputStream.read(imageInBytes); 
				 inputStream.close();
			
				 productImageDetails.setByteCatImg1(BlobProxy.generateProxy(imageInBytes));
				 productImageDetails.setByteCatImg2(BlobProxy.generateProxy(imageInBytes));
				 productImageDetails.setByteCatImg3(BlobProxy.generateProxy(imageInBytes));
				 productImageDetails.setByteCatImg4(BlobProxy.generateProxy(imageInBytes));
				 productImageDetails.setByteCatImg5(BlobProxy.generateProxy(imageInBytes));
			
				 flag =	productImageDetailsDAO.addProductImageDetails(productImageDetails);
			}
			catch(Exception e)
			{
				System.out.println("  Runtime Error in Testing in adding image " + e.toString());
				flag = false;
			}
		   assert(flag);

	}


}
