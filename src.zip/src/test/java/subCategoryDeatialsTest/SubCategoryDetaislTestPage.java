package subCategoryDeatialsTest;

import static org.junit.Assert.*;

import java.util.Date;
import java.util.Iterator;
import java.util.List;


import org.junit.Ignore;
import org.junit.Test;
import dao.SubcategoryDetailsDAO;
import daoimpl.SubcategoryDetailsDAOImpl;
import model.SubcategoryDetails;
import java.text.SimpleDateFormat;




public class SubCategoryDetaislTestPage {

	@Test
	public void test() {
		
		assert(true);
		
	}
	//@Ignore
	@Test
	public void addSubProductDetaislTest()
	
	{
		
		SubcategoryDetailsDAO subcategoryDetailsDAO = new SubcategoryDetailsDAOImpl();
	    SubcategoryDetails  subcategoryDetails = new SubcategoryDetails();
		
	       
	    subcategoryDetails.setCatId(25L);
	    subcategoryDetails.setProductID(4L);
	        subcategoryDetails.setSubCategoryName("Audi 10z");
			Date myDate = new Date();
		    SimpleDateFormat dmyFormat = new SimpleDateFormat("dd-MM-yyyy");
		    String date = dmyFormat.format(myDate); 
		    System.out.println(date);
		    subcategoryDetails.setDateTime(date);
		    
		   boolean flag =	subcategoryDetailsDAO.addSubcategoryDetails(subcategoryDetails);
		   assert(flag);
	}
@Ignore
@Test
public void updateSubproductDetailsTest(){



		
	SubcategoryDetailsDAO subcategoryDetailsDAO = new SubcategoryDetailsDAOImpl();
    SubcategoryDetails  subcategoryDetails = new SubcategoryDetails();
	
    subcategoryDetails.setSubCategoryId(187L);
		
		SubcategoryDetails currentSubcategory=subcategoryDetailsDAO.getSubcategoryDetailsById(subcategoryDetails);
		
		currentSubcategory.setSubCategoryName("Audi 10z");
		Date myDate = new Date();
		 SimpleDateFormat dmyFormat = new SimpleDateFormat("dd-MM-yyyy");
	    String date = dmyFormat.format(myDate); 
	    System.out.println(date);
	    subcategoryDetails.setDateTime(date);
	    
	   boolean flag =	subcategoryDetailsDAO.updateSubcategoryDetails(currentSubcategory);
	   assert(flag);
	
	
	
}
@Ignore
@Test
public void deleteSubproductDetailsTest()
{

	 SubcategoryDetailsDAO subcategoryDetailsDAO = new SubcategoryDetailsDAOImpl();
	    SubcategoryDetails  subcategoryDetails = new SubcategoryDetails();
	
	    subcategoryDetails.setSubCategoryId(162L);
	
   boolean flag  =subcategoryDetailsDAO.deleteSubcategoryDetails(subcategoryDetails);

}
@Ignore
@Test
public void getSubproductDetailsByIdTest(){
	
	  SubcategoryDetailsDAO subcategoryDetailsDAO = new SubcategoryDetailsDAOImpl();
	    SubcategoryDetails  subcategoryDetails = new SubcategoryDetails();
	
	    subcategoryDetails.setSubCategoryId(162L);
	
	    subcategoryDetails =subcategoryDetailsDAO.getSubcategoryDetailsById(subcategoryDetails);
	
    System.out.println(subcategoryDetails);

	
}
	@Ignore
	   @Test
	   public void getAllSubproductDetailsTest()
	   {
		   SubcategoryDetailsDAO subcategoryDetailsDAO = new SubcategoryDetailsDAOImpl();
		List <SubcategoryDetails> subcategory=subcategoryDetailsDAO.getAllSubcategoryDetails();
		System.out.println(subcategory);
		
		Iterator itr =  subcategory.iterator();
		
		while(itr.hasNext())
		{
			SubcategoryDetails u = (SubcategoryDetails)itr.next();
			System.out.println(u);
		}
		
	   }

  @Ignore
	@Test
	   public void getCategoryIdTest(){
			
		    SubcategoryDetailsDAO subcategoryDetailsDAO = new SubcategoryDetailsDAOImpl();
		    SubcategoryDetails  subcategoryDetails = new SubcategoryDetails();
		    subcategoryDetails.setCatId(111111L);
			List <SubcategoryDetails> allsubcategory  = subcategoryDetailsDAO.getSubcategoryDetailsByMainCatId(subcategoryDetails);
			Iterator item = allsubcategory.iterator();
			while(item.hasNext())
			{
				SubcategoryDetails currcat =(SubcategoryDetails) item.next();
			    System.out.println(currcat);
			}
			
			
			
			
		}
}
