package BlogTestCase;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;

import dao.BlogDAO;
import daoimpl.BlogDAOImpl;
import model.Blog;

public class BlogDAOImplTest {

	@Test
	public void test() {
		System.out.println(" Done ");
		fail("Not yet implemented");
	}
	
	@Test
	public void testAddBlog() {
		
		
		Blog blog = new Blog();
		BlogDAO 	blogDAO = new 	BlogDAOImpl();
		
		blog.setBlogName("About Worllooper");
		blog.setBlogComment("WEB And MOBILE Development Comany");
		//blog.getBlogCreatedDate(null);
		blog.setUserEmail("worklooper10.com");
		
		
		boolean flag =blogDAO.save(blog);
		
		
		
		
		assert(flag);
	}
	

}
