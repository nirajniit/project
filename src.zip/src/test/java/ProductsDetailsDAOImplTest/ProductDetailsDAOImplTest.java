package ProductsDetailsDAOImplTest;

import static org.junit.Assert.*;

import java.util.Iterator;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;

import org.junit.Test;

import dao.ProductDetailsDAO;
import daoimpl.ProductDetailsDAOImpl;
import model.ProductDetails;

public class ProductDetailsDAOImplTest {

	@Test
	public void test() {
		assert(true);
		
	}
	



  @Ignore	
   @Test
public void addProductsTest()
{
	ProductDetailsDAO productDetailsDAO = new ProductDetailsDAOImpl();
	ProductDetails prd = new ProductDetails();
	
	prd.setCityId("222");
	Long l=222222L;
	prd.setProductID(l);
	prd.setProductType("Motor2");
	
	
    boolean flag =	productDetailsDAO.addProduct(prd);
	assert(flag);
}


	@Ignore
	@Test
	public void getProductsByIdTest(){
		
		ProductDetailsDAO productDetailsDAO = new ProductDetailsDAOImpl();
		ProductDetails productdetails=new ProductDetails();
		Long l=222222L;
		productdetails.setProductID(l);
		
		productdetails  = productDetailsDAO.getProductById(productdetails);
		
		if(productdetails == null)
		{
			System.out.println(" data not found " );
		}
		else
		{
			System.out.println(productdetails);
			
		}
		
	}



@Ignore
@Test
	public void getProductsByNameTest(){
		
		ProductDetailsDAO productDetailsDAO = new ProductDetailsDAOImpl();
		ProductDetails productdetails=new ProductDetails();
		productdetails.setProductType("NIIT1sss");
		List <ProductDetails> currentproductdetails  =productDetailsDAO.getProductByName(productdetails);
		System.out.println(currentproductdetails );
	}



@Ignore
@Test
public void deleteProductTest()
{
	boolean flag =false;
	ProductDetailsDAO productDetailsDAO = new ProductDetailsDAOImpl();
	ProductDetails productdetails=new ProductDetails();
	Long l=222222L;
	productdetails.setProductID(l);
    flag  =productDetailsDAO.deleteProduct(productdetails);
	System.out.println(productdetails);
}



 @Ignore
@Test
	public void updateProductsdetailsByIDTest(){

		boolean flag=false;
		ProductDetailsDAO productDetailsDAO  = new ProductDetailsDAOImpl();
		ProductDetails productDetails = new ProductDetails();
		Long l=222222L;
		productDetails.setProductID(l);
		productDetails.setProductType("Hotel Furniture");
		
		flag = productDetailsDAO.updateProduct(productDetails);
		
		System.out.println(productDetails);
		
		System.out.println("updateproductDetailsTest method running ");
		assert(true);
		
	}


//@Ignore
@Test
public void getAllProductsTest()
{
	ProductDetailsDAO productDetailsDAO = new ProductDetailsDAOImpl();
	List <ProductDetails>  allproduct =productDetailsDAO.getAllProduct();
	
	Iterator itr =  allproduct.iterator();
	while(itr.hasNext())
	{
		ProductDetails u = (ProductDetails) itr.next();
		System.out.println(u);
	}
	
}
}

