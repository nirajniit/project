package userProfileDetailsTest;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.hibernate.engine.jdbc.BlobProxy;
import org.junit.Ignore;
import org.junit.Test;


import dao.UserProfileDetailsDAO;

import daoimpl.UserProfileDetailsDAOImpl;
import model.TestimonialDetails;
import model.UserProfileDetails;

public class UserProfileDetailsTest {

	@Test
	public void test() {
		assert(true);
	}

@Ignore
@Test
public void getAllUserProfileDetailsTest()
{
	UserProfileDetailsDAO userProfileDetailsTestDAO = new UserProfileDetailsDAOImpl();
	
	List<UserProfileDetails>  allProfileDetails =userProfileDetailsTestDAO.getUserProfileDetails();
	
	Iterator itr =  allProfileDetails.iterator();
	
	while(itr.hasNext())
	{
		UserProfileDetails  u = (UserProfileDetails) itr.next();
		System.out.println(u);
	}
		
}
@Ignore
@Test
public void saveUserProfileDetailsTest() throws IOException{
	
	UserProfileDetailsDAO userProfileDetailsTestDAO = new UserProfileDetailsDAOImpl();
	UserProfileDetails userProfileDetails=new UserProfileDetails();
	
	userProfileDetails.setUserName("Krishan");
	userProfileDetails.setNationality("hululu");
	userProfileDetails.setDob("13/03/1998");
	userProfileDetails.setCareerLevel(" java Devloper");
	userProfileDetails.setCurrentLoction("India");
	userProfileDetails.setCurrentPosition("Sector 12 Dubai");
	userProfileDetails.setCareerLevel("TheFulfRoad Pvl.Dubail");
	userProfileDetails.setSalaryExpectaions("120000000");
	userProfileDetails.setCommitment("Bussy");
	userProfileDetails.setNationality("Some Time");
	userProfileDetails.setUserEmail("KKKKKKer2@worklooper.com");
	Date d = new Date();
	userProfileDetails.setDateTime(d.toString());
	userProfileDetails.setNoticePeriod("14 days");
	userProfileDetails.setCurrentCompany("google");
	userProfileDetails.setVisaStatus("No");
	userProfileDetails.setHidePhoto("YYY.jpeg");
	userProfileDetails.setProfileImgName("CarImage");
	userProfileDetails.setCvFileName("Krishna cv");
	
	 try
	 {
		 File imagePath = new File("D://ALL Image//8iEbeXX5T.jpg");
		byte[] imageInBytes = new byte[(int)imagePath.length()]; //image convert in byte form
		FileInputStream inputStream = new FileInputStream(imagePath);  //input stream object create to read the file
		inputStream.read(imageInBytes); // here inputstream object read the file
		inputStream.close();
	
		  userProfileDetails.setProfileImg(BlobProxy.generateProxy(imageInBytes));
		  userProfileDetails.setChooseFile(BlobProxy.generateProxy(imageInBytes));
	}
	catch(Exception e)
	{
	System.out.println(e);	
	}
	
	 
	  
		userProfileDetails.setEducation("MCA");
		userProfileDetails.setYourCVsummary("your Cv time");
		userProfileDetails.setiHavegot1("5");
		userProfileDetails.setiHavegot2("4");
		userProfileDetails.setiHavegot3("3");
		userProfileDetails.setiHavegot4("2");
		userProfileDetails.setiHavegot5("1");
		userProfileDetails.setExperienceIn1("5");
		userProfileDetails.setExperienceIn2("4");
		userProfileDetails.setExperienceIn3("3");
		userProfileDetails.setExperienceIn4("2");
		userProfileDetails.setExperienceIn5("1");
		userProfileDetails.setCheckBox1("y");
		userProfileDetails.setCheckBox2("n");
		
	boolean flag=userProfileDetailsTestDAO.saveUserProfileDetails(userProfileDetails);
	assert(flag);
}
@Ignore
@Test
public void updateUserProfileDetailsTest(){

	UserProfileDetailsDAO userProfileDetailsTestDAO = new UserProfileDetailsDAOImpl();
	UserProfileDetails userProfileDetails=new UserProfileDetails();
	userProfileDetails.setId(110);
	UserProfileDetails currUserProfiledetails =userProfileDetailsTestDAO.getProfileById(userProfileDetails);

	
	userProfileDetails.setUserName("Krishan");
	currUserProfiledetails.setNationality("Usa");
	currUserProfiledetails.setDob("12/03/1998");
	currUserProfiledetails.setCareerLevel("Devloper");
	currUserProfiledetails.setCurrentLoction("dubai");
	currUserProfiledetails.setCurrentPosition("Sector 62 Dubai");
	currUserProfiledetails.setCareerLevel("TheFulfRoad Pvl.Dubail");
	currUserProfiledetails.setSalaryExpectaions("2000");
	currUserProfiledetails.setCommitment("Bussy");
	currUserProfiledetails.setNoticePeriod("16 days");
	currUserProfiledetails.setCurrentCompany("MicroSoft");
	Date d = new Date();
	currUserProfiledetails.setDateTime(d.toString());
	currUserProfiledetails.setVisaStatus("no");
	currUserProfiledetails.setHidePhoto("YYY.jpeg");
	
	userProfileDetails.setProfileImgName("CarImage");
	userProfileDetails.setCvFileName("Krishna cv");
	
	 try
	 {
		 File imagePath = new File("D://ALL Image//pi58xaL5T.jpg");
		byte[] imageInBytes = new byte[(int)imagePath.length()]; //image convert in byte form
		FileInputStream inputStream = new FileInputStream(imagePath);  //input stream object create to read the file
		inputStream.read(imageInBytes); // here inputstream object read the file
		inputStream.close();
	
		currUserProfiledetails.setProfileImg(BlobProxy.generateProxy(imageInBytes));
		currUserProfiledetails.setChooseFile(BlobProxy.generateProxy(imageInBytes));
	}
	catch(Exception e)
	{
	e.getMessage();	
	}
	   
	 currUserProfiledetails.setEducation("msc");
	 currUserProfiledetails.setYourCVsummary("your Cv ");
	 currUserProfiledetails.setiHavegot1("1");
	 currUserProfiledetails.setiHavegot2("2");
	 currUserProfiledetails.setiHavegot3("3");
	 currUserProfiledetails.setiHavegot4("4");
	 currUserProfiledetails.setiHavegot5("5");
	 currUserProfiledetails.setExperienceIn1("1");
	 currUserProfiledetails.setExperienceIn2("2");
	 currUserProfiledetails.setExperienceIn3("3");
	 currUserProfiledetails.setExperienceIn4("4");
	 currUserProfiledetails.setExperienceIn5("5");
	 currUserProfiledetails.setCheckBox1("1");
	 currUserProfiledetails.setCheckBox2("2");
	
	boolean flag=userProfileDetailsTestDAO.updateUserProfileDetails(currUserProfiledetails);
	assert(flag);
	
}

@Ignore
@Test	
	public void getUserProfileDetailsByIdTest()
	{
		 UserProfileDetailsDAO userPorfileDetailsDAO=new UserProfileDetailsDAOImpl();
		 UserProfileDetails userProfileDetails=new UserProfileDetails();
		 userProfileDetails.setId(110);
		 userProfileDetails=userPorfileDetailsDAO.getProfileById(userProfileDetails);
     
	}

//@Ignore
@Test	
	public void deleteUserProfileDetailsTest()
	{

	 UserProfileDetailsDAO userPorfileDetailsDAO=new UserProfileDetailsDAOImpl();
	UserProfileDetails userProfileDetails=new UserProfileDetails();
	userProfileDetails.setId(19);
  boolean	flag=userPorfileDetailsDAO.deleteUserProfileDetails(userProfileDetails);
  assert(flag);
	
	}


@Ignore
	@Test	
	public void getuserProfileDetailsByEmailTest()
	{
	UserProfileDetailsDAO userProfileDetailsDAO = new UserProfileDetailsDAOImpl();
	  UserProfileDetails userProfileDetails=new UserProfileDetails();
	  userProfileDetails.setUserEmail("KKKKKKer2@worklooper.com");
	List<UserProfileDetails>  allUserProfileDetails =userProfileDetailsDAO.getProfileByEmailId(userProfileDetails);
		
		Iterator itr =  allUserProfileDetails.iterator();
		
		while(itr.hasNext())
		{
			UserProfileDetails  u = (UserProfileDetails) itr.next();
			System.out.println(u);
		}
	}
	
}
