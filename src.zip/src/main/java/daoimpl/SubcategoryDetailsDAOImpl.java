package daoimpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import dao.SubcategoryDetailsDAO;
import dbconfig.ApplicationContextConfig;
import model.SubcategoryDetails;



public class SubcategoryDetailsDAOImpl implements SubcategoryDetailsDAO{

	@Autowired
	private SessionFactory sessionFactory;
	public boolean addSubcategoryDetails(SubcategoryDetails subcategory) 
    {
		
		System.out.println("==============================");
		System.out.println("addSubproductDetails : BackEnd begin");
		System.out.println("==============================");
		
		try 
		{
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
	            System.out.println(subcategory);				
	            SubcategoryDetailsDAO subcategoryDetailsDAO = new SubcategoryDetailsDAOImpl();
	            SubcategoryDetails subcategoryCurrent = subcategoryDetailsDAO.getSubcategoryDetailsById(subcategory);
			
				
			if(null == subcategoryCurrent )
			{
				session.save(subcategory);
		  	}
			else
			{
				System.out.println("=======================");
				System.out.println(subcategoryCurrent  + " has allredy  exists");
				System.out.println("=======================");
				return false;
			}
			
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==============================");
			System.out.println("addSubproductDetails : BackEnd end Successfully");
			System.out.println("==============================");
           return true;
		}

		catch (Exception e) {
			System.out.println("==============================");
			System.out.println("addSubproductDetails : BackEnd end with Error ");
			System.out.println(e  +" because Category Id is wrong");
			System.out.println("==============================");
           return false;
		 }
	}

	public boolean deleteSubcategoryDetails(SubcategoryDetails subcategory) {
		
		System.out.println("==============================");
		System.out.println(" deleteSubproductDetails : BackEnd begin");
		System.out.println("==============================");
		
		try {
		
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			System.out.println(subcategory);
			
			     SubcategoryDetailsDAO subproductDetailsDAO = new SubcategoryDetailsDAOImpl();
	            SubcategoryDetails subproductCurrent = subproductDetailsDAO.getSubcategoryDetailsById(subcategory);
			
			if(null == subproductCurrent)
			{
				System.out.println("=======================");
				System.out.println(subcategory + " not Found");
				System.out.println("=======================");
				return false;
			}
			else
			{
			 session.delete(subcategory);
			
			 	tx.commit();
			 	session.flush();
			 	session.close();
			 	System.out.println("==============================");
			 	System.out.println(" deleteSubproductDetails : BackEnd end Successfully");
			 	System.out.println("==============================");
			
			return true;
			}
		   }

		  catch (Exception e) 
		  {

			System.out.println("==============================");
			System.out.println(" deleteSubproductDetails : BackEnd end with Error ");
			System.out.println(e);
			System.out.println("==============================");
			
			return false;
		   }
	}

	public boolean updateSubcategoryDetails(SubcategoryDetails subcategory) {
		
		System.out.println("==============================");
		System.out.println("updateSubproductDetails : BackEnd begin");
		System.out.println("==============================");

		
			try
			{
				SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
				Session session = sessionFactory.openSession();
				Transaction tx = session.beginTransaction();
				
				   SubcategoryDetailsDAO subcategoryDetailsDAO = new SubcategoryDetailsDAOImpl();
		           SubcategoryDetails subcategoryCurrent = subcategoryDetailsDAO.getSubcategoryDetailsById(subcategory);
			
		           
				if(subcategoryCurrent!= null)
				{
					subcategoryCurrent = subcategory;
				    session.update(subcategoryCurrent);
					
				}
				else
				{
					
					return false;
				}
				tx.commit();
				session.flush();
				session.close();
				System.out.println("==============================");
				System.out.println("updateSubproductDetails : BackEnd end Successfully");
				System.out.println("==============================");
				return true;
				
			}

			 catch (Exception e) {
				System.out.println("=========================================");
				System.out.println("updateSubproductDetails : BackEnd end with Error ");
				System.out.println(e);
				System.out.println("===========================================");
				return false;
			}
	}

	public List<SubcategoryDetails> getAllSubcategoryDetails()
	{
		System.out.println("===========================================");
		System.out.println(" getAllSubproductDetails() : BackEnd begin");
		System.out.println("============================================");
		
		try 
		{
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			List<SubcategoryDetails> subproduct = session.createQuery("from SubcategoryDetails").list();
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==============================");
			System.out.println("getAllSubproductDetails(): BackEnd end Successfully");
			System.out.println("==============================");
			return subproduct;

		}
		    catch (Exception e) {
		    System.out.println("==============================");
			System.out.println("getAllSubproductDetails() : BackEnd end with Error ");
			System.out.println(e);
			System.out.println("==============================");
			return null;
		}
	}

	public List<SubcategoryDetails> getSubcategoryDetailsByMainCatId(SubcategoryDetails subcategory) {
		
		System.out.println("=================================");
		System.out.println("getCategoryProcutById : BackEnd Begin ");
		System.out.println("=================================");
		
		try {
			  
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			
			Transaction tx = session.beginTransaction();
			
			String hql = "from SubcategoryDetails where productID ='" + subcategory.getProductID() + "'";


			
			List <SubcategoryDetails> currentsubcategory =  session.createQuery(hql).list();
			
			System.out.println(currentsubcategory );
			
			
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println("=================================");
			System.out.println(" getCategoryProcutById  : BackEnd END successfully ");
			System.out.println("=================================");
				
			return currentsubcategory;

			
		}

		catch (Exception e) {
			System.out.println("=================================");
			System.out.println(" getCategorycategoryById  : BackEnd END with error  ");
			System.out.println(e);
			System.out.println("=================================");
			return null;
		}
		
	}

	public SubcategoryDetails getSubcategoryDetailsById(SubcategoryDetails subcategory) {

		System.out.println("=================================");
   	System.out.println(" getSubcategoryDetailsById : BackEnd Begin ");
	    System.out.println("=================================");
	
	  try {
		  
	   Long Id=subcategory.getSubCategoryId();
	
		SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		
		
		SubcategoryDetails currentsubcategory = (SubcategoryDetails) session.get(SubcategoryDetails.class,Id);
		
		tx.commit();
		session.flush();
		session.close();
		
		
		
		
		System.out.println("=================================");
		System.out.println(" getSubproductDetailsById   : BackEnd END successfully ");
		System.out.println("=================================");
	
		
			if(currentsubcategory == null)
			{
				return null;
			}
			return currentsubcategory;
		
	}

	catch (Exception e) {
		System.out.println("=================================");
		System.out.println(" getSubproductDetailsById : BackEnd END with error  ");
		System.out.println(e);
		System.out.println("=================================");
		return null;
	}
	}

}
