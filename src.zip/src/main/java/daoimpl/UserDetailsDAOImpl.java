package daoimpl;
import java.beans.Expression;
import java.util.List;

import javax.management.Query;
import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import java.util.List;

import dao.UserDetailsDAO;
import dbconfig.ApplicationContextConfig;
import model.UserDetails;

public class UserDetailsDAOImpl implements UserDetailsDAO  {

	@Override
	public boolean addUserDetails(UserDetails user) 
	{
		System.out.println("==================================");
		System.out.println(" addUserDetails : @BACKEND BEGIN");
		System.out.println("==================================");
		boolean flag = false;
		try {
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			user.setUserEmail(user.getUserEmail().trim());
			user.setUserPassword(user.getUserPassword().trim());
			user.setUserRole("normal");
			user.setUserStatus("N");
			user.setUserActive("N");
			user.setUserBlock("N");
			
			
			
			
			
			UserDetailsDAO userDetailsDAO  = new UserDetailsDAOImpl();
			UserDetails cuser  = userDetailsDAO.getUserDetailsByEmail(user);
			if(cuser==null)
			{
				
			        session.save(user);
			        session.flush();
					session.close();
					
			
			}
			else
			{
				System.out.println("==================================");
				System.out.println(user.getUserEmail() + " has already exists ");
				System.out.println("==================================");
				
				return false;
				
			}
			tx.commit();
	
			
			session.flush();
			session.close();

			
			
			
			System.out.println("==================================");
			System.out.println(" addUserDetails : @BACKEND END successfully");
			System.out.println("==================================");
			
			
			return true;
		}

		catch (Exception e) 
		{
			
			System.out.println("==================================");
			System.out.println(" addUserDetails : @BACKEND END wiht error");
			System.out.println(e.toString());
			System.out.println("==================================");
			e.printStackTrace();
			return false;
		}
			
	}
	
	
	

	@Override
	public boolean deleteUserDetails(UserDetails user) {
		System.out.println("==================================");
		System.out.println(" deleteUserDetails : @BACKEND BEGIN");
		System.out.println("==================================");
		
		
			try
			{
			

			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			UserDetailsDAO userDetailsDAO  = new UserDetailsDAOImpl();
			user  = userDetailsDAO.getUserDetailsByEmail(user);
			if(null != user )
			{
			session.delete(user);
			}
			else
			{
				System.out.println("==================================");
				System.out.println(user.getUserEmail() + " not found");
				System.out.println("==================================");
				
				return false;
			}
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==================================");
			System.out.println(" deleteUserDetails : @BACKEND End Successfully");
			System.out.println("==================================");
			
			
			return true;
		}

		catch (Exception e) {
			System.out.println("==================================");
			System.out.println(" deleteUserDetails : @BACKEND End with error");
			System.out.println(e);
			System.out.println("==================================");

			e.printStackTrace();
			return false;
		}
}

@Override
public boolean updateUserDetails(UserDetails user) {
	System.out.println("==================================");
	System.out.println(" updateUserDetails : @BACKEND Begin");
	System.out.println("==================================");

		try
		{

			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			UserDetailsDAO userDetailsDAO  = new UserDetailsDAOImpl();
			UserDetails cuser  = userDetailsDAO.getUserDetailsByEmail(user);
			
			
			
			String userActive=cuser.getUserActive();
			String userRole = cuser.getUserRole();
			String userBlock = cuser.getUserBlock();
			String userStatus = cuser.getUserStatus();
			
			
			if(cuser!= null)
			{
				cuser = user;
				
			/*		
					cuser.setUserActive(userActive);
					cuser.setUserBlock(userBlock);
					cuser.setUserRole(userRole);
					cuser.setUserStatus(userStatus);
			*/
				
			    session.update(cuser);
			}
			else
			{
				System.out.println("==================================");
				System.out.println(user.getUserEmail() + " not found");
				System.out.println("==================================");
				return false;
			}
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==================================");
			System.out.println(" updateUserDetails : @BACKEND End Successfully");
			System.out.println("==================================");

			return true;
		}

		catch(Exception e) 
		{
			System.out.println("==================================");
			System.out.println(" updateUserDetails : @BACKEND End with error");
			System.out.println(e);
			System.out.println("==================================");

			e.printStackTrace();
			return false;
		}

	}

	@Override
	public List<UserDetails> getAllUserDetails() {
		
		System.out.println("==================================");
		System.out.println(" getAllUserDetails : @BACKEND Begin");
		System.out.println("==================================");

		try 
		{
		
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			List<UserDetails> user = session.createQuery("from UserDetails").list();
			tx.commit();
			session.flush();
			session.close();
			if(null == user)
			{
				System.out.println("==================================");
				System.out.println("  Data Not Found  ");
				System.out.println("==================================");

			
			}
			System.out.println("==================================");
			System.out.println(" getAllUserDetails : @BACKEND End Successfully");
			System.out.println("==================================");

			
			return user;

		}
		catch (Exception e) {
		
			System.out.println("==================================");
			System.out.println(" getAllUserDetails : @BACKEND END with error ");
			System.out.println(e);
			System.out.println("==================================");

			return null;
		}

	}

	@Override
	public UserDetails getUserDetailsByEmail(UserDetails user) {
		
		System.out.println("==================================");
		System.out.println(" getUserDetailsByEmail : @BACKEND Begin");
		System.out.println("==================================");

		
		try {

			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			String userEmail = user.getUserEmail();
			String hql = "from UserDetails where userEmail ='" + user.getUserEmail() + "'";
			
		    user = (UserDetails) session.createQuery(hql).uniqueResult();
			
		    if(null == user)
		    {
		    	System.out.println("==================================");
				System.out.println(userEmail + "  Data Not Found   ");
				System.out.println("==================================");

		    }
		    
		    
		    
		    tx.commit();
			session.flush();
			session.close();
		
			System.out.println("==================================");
			System.out.println(" getUserDetailsByEmail : @BACKEND end successfully");
			System.out.println("==================================");

			return user;
		}
		catch (Exception e) {
			System.out.println("==================================");
			System.out.println(" getUserDetailsByEmail : @BACKEND end with error ");
			System.out.println(e);
			System.out.println("==================================");

			return null;
		}

	}

	@Override
	public UserDetails validateUserDetails(UserDetails user){
		System.out.println("==================================");
		System.out.println(" validateUserDetails : @BACKEND Begin");
		System.out.println("==================================");

		try {

			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			String userEmail = user.getUserEmail();
			String hql = "from UserDetails where userEmail ='"+user.getUserEmail().trim()+"' and userPassword='"+user.getUserPassword().trim()+"'";

			System.out.println(" HQL " + hql);
		    user = (UserDetails) session.createQuery(hql).uniqueResult();
			if(null == user)
			{
				
				System.out.println("==================================");
				System.out.println(userEmail + " Not Found");
				System.out.println("==================================");
			}
		    tx.commit();
			session.flush();
			session.close();

			System.out.println("==================================");
			System.out.println(" validateUserDetails : @BACKEND end successfully");
			System.out.println("==================================");

			return user;
		}
		catch (Exception e) {
			System.out.println("==================================");
			System.out.println(" validateUserDetails : @BACKEND end with error");
			System.out.println(e);
			System.out.println("==================================");
			return null;
		}

	}




	@Override
	public UserDetails setActive(UserDetails user) {
		System.out.println("==================================");
		System.out.println(" setActive : @BACKEND Begin");
		System.out.println("==================================");

			try
			{

				
				SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
				Session session = sessionFactory.openSession();
				Transaction tx = session.beginTransaction();
				UserDetailsDAO userDetailsDAO  = new UserDetailsDAOImpl();
				UserDetails cuser  = userDetailsDAO.getUserDetailsByEmail(user);
				
				
				
				
				if(cuser!= null)
				{
					
					cuser.setUserActive(user.getUserActive());
					
				    session.update(cuser);
				}
				else
				{
					System.out.println("==================================");
					System.out.println(user.getUserEmail() + " not found");
					System.out.println("==================================");
					return null;
				}
				tx.commit();
				session.flush();
				session.close();
				System.out.println("==================================");
				System.out.println(" setActive : @BACKEND End Successfully ");
				System.out.println("==================================");

				return cuser;
			}

			catch(Exception e) 
			{
				System.out.println("==================================    ");
				System.out.println(" setActive : @BACKEND End with error  ");
				System.out.println(e);
				System.out.println("==================================     ");

				e.printStackTrace();
				return null;
			}

	}




	@Override
	public UserDetails setBlock(UserDetails user) {
		System.out.println("==================================");
		System.out.println(" setBlock : @BACKEND Begin");
		System.out.println("==================================");

			try
			{

				
				SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
				Session session = sessionFactory.openSession();
				Transaction tx = session.beginTransaction();
				UserDetailsDAO userDetailsDAO  = new UserDetailsDAOImpl();
				UserDetails cuser  = userDetailsDAO.getUserDetailsByEmail(user);
				
				if(cuser!= null)
				{
					cuser.setUserBlock(user.getUserBlock());
				    session.update(cuser);
				}
				else
				{
					System.out.println("==================================");
					System.out.println(user.getUserEmail() + " not found");
					System.out.println("==================================");
					return null;
				}
				tx.commit();
				session.flush();
				session.close();
				System.out.println("==================================");
				System.out.println(" setBlock : @BACKEND End Successfully ");
				System.out.println("==================================");

				return cuser;
			}

			catch(Exception e) 
			{
				System.out.println("==================================    ");
				System.out.println(" setBlock : @BACKEND End with error  ");
				System.out.println(e);
				System.out.println("==================================     ");

				//e.printStackTrace();
				return null;
			}

		
	}




	@Override
	public UserDetails setStatus(UserDetails user) {
		
		System.out.println("==================================");
		System.out.println(" setStatus : @BACKEND Begin        ");
		System.out.println("==================================");

			try
			{

				
				SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
				Session session = sessionFactory.openSession();
				Transaction tx = session.beginTransaction();
				UserDetailsDAO userDetailsDAO  = new UserDetailsDAOImpl();
				UserDetails cuser  = userDetailsDAO.getUserDetailsByEmail(user);
				if(cuser!= null)
				{
					cuser.setUserStatus(user.getUserStatus());
				    session.update(cuser);
				}
				else
				{
					
					System.out.println("==================================");
					System.out.println(user.getUserEmail() + " not found");
					System.out.println("==================================");
					return null;
					
				}
				tx.commit();
				session.flush();
				session.close();
				System.out.println("==================================");
				System.out.println(" setStatus : @BACKEND End Successfully ");
				System.out.println("==================================");

				return cuser;
			}

			catch(Exception e) 
			{
				System.out.println("==================================    ");
				System.out.println(" setStatus : @BACKEND End with error  ");
				System.out.println(e);
				System.out.println("==================================     ");

				//e.printStackTrace();
				return null;
			}


		
	}



	
	
	
	

	@Override
	public UserDetails setRole(UserDetails user) {
		
		System.out.println("==================================");
		System.out.println(" setRole : @BACKEND Begin        ");
		System.out.println("==================================");

			try
			{

				
				SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
				Session session = sessionFactory.openSession();
				Transaction tx = session.beginTransaction();
				UserDetailsDAO userDetailsDAO  = new UserDetailsDAOImpl();
				UserDetails cuser  = userDetailsDAO.getUserDetailsByEmail(user);
				if(cuser!= null)
				{
					cuser.setUserRole(user.getUserRole());
				    session.update(cuser);
				}
				else
				{
					
					System.out.println("==================================");
					System.out.println(user.getUserEmail() + " not found");
					System.out.println("==================================");
					return null;
					
				}
				tx.commit();
				session.flush();
				session.close();
				System.out.println("==================================");
				System.out.println(" setRole : @BACKEND End Successfully ");
				System.out.println("==================================");

				return cuser;
			}

			catch(Exception e) 
			{
				System.out.println("==================================    ");
				System.out.println(" setRole : @BACKEND End with error  ");
				System.out.println(e);
				System.out.println("==================================     ");

				//e.printStackTrace();
				return null;
			}


	}

}
