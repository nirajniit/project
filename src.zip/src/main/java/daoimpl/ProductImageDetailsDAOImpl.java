package daoimpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import dao.ProductImageDetailsDAO;
import dao.UserDetailsDAO;
import dbconfig.ApplicationContextConfig;
import model.CategoryDetails;
import model.ProductImageDetails;
import model.UserDetails;

public class ProductImageDetailsDAOImpl implements ProductImageDetailsDAO {

	@Override
	public boolean addProductImageDetails(ProductImageDetails productImageDetails) 
	{
		System.out.println("==================================");
		System.out.println(" ProductImageDetailsDAOImpl : @BACKEND BEGIN");
		System.out.println("==================================");
		boolean flag = false;
		try {
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			        session.save(productImageDetails);
			        tx.commit();
					session.flush();
					session.close();
			System.out.println("========================================================");
			System.out.println(" ProductImageDetailsDAOImpl : @BACKEND END successfully");
			System.out.println("=======================================================");
			return true;
		}

		catch (Exception e) 
		{
			System.out.println("=========================================== ");
			System.out.println(" ProductImageDetailsDAOImpl : @BACKEND END wiht error   ");
			System.out.println(e.toString());
			System.out.println("=========================================== ");
			e.printStackTrace();
			return false;
		}

	}

	@Override
	public boolean deleteProductImageDetails(ProductImageDetails productImageDetails) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateProductImageDetails(ProductImageDetails productImageDetails) {
		// TODO Auto-generated method stub
		return false;
	}

	
	
	@Override
	public List<ProductImageDetails> allProductImageDetails() 
	{
		
		System.out.println(" =========================================== ");
		System.out.println("   allProductImageDetails : BackEnd begin    ");
		System.out.println(" =========================================== ");
		
		try 
		{
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			List<ProductImageDetails> productImageDetails = session.createQuery(" from ProductImageDetails order by productImageId desc ").list();
			tx.commit();
			session.flush();
			session.close();
			System.out.println("===================================================== ");
			System.out.println(" ProductImageDetails : BackEnd end Successfully       ");
			System.out.println("==============================");
			return productImageDetails;

		}
		catch (Exception e)
		{
			
		    System.out.println("===========================================");
			System.out.println("ProductImageDetails : BackEnd end with Error ");
			System.out.println(e);
			System.out.println("===========================================");
			return null;
		}
		

	}

	@Override
	public ProductImageDetails getProductImageDetailsByproductImageId(ProductImageDetails productImageDetails) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ProductImageDetails> getProductImageDetailsBycatID(ProductImageDetails productImageDetails) {
		// TODO Auto-generated method stub
		return null;
	}

}
