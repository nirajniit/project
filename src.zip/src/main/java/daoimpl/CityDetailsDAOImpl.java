package daoimpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import dao.CityDetailsDAO;
import dao.CountryDetailsDAO;
import dao.CityDetailsDAO;
import dbconfig.ApplicationContextConfig;
import model.CityDetails;
import model.CountryDetails;
import model.CityDetails;

public class CityDetailsDAOImpl implements CityDetailsDAO {
	

	
	public List <CityDetails> getAllCitiesByCountryID(CityDetails citydetail)
	{
		try {
			System.out.println(" ========================================= ");
			System.out.println("   getAllCitiesByCountryID  : @BackEnd Begin ");
			System.out.println(" ========================================= ");
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			System.out.println(citydetail.getCityName() );
			String hql = "from CityDetails where countryId  ='" +citydetail.getCountryId()+"'" ;

			System.out.println("=========================hql===================");
			System.out.println(hql);
			System.out.println("=========================hql===================");
			
			
			List <CityDetails> cityDetails =  session.createQuery(hql).list();
			
	
			
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println(" ========================================= ");
			System.out.println(" getCitybyName : @BackEnd End Successfully ");
			System.out.println(" ========================================= ");
			
			return cityDetails;

			
		}

		catch (Exception e) {
			System.out.println(" ========================================= ");
			System.out.println(" getCitybyName : @BackEnd End With Error ");
			System.out.println(" ========================================= ");
			return null;
		}
		
	}
	

	public boolean addCity(CityDetails citydetail) {
		System.out.println(" ========================================= ");
		System.out.println(" addCity : @BackEnd Begin ");
		System.out.println(" ========================================= ");
		
		try
		{
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			CityDetailsDAO citydetailsDAO = new CityDetailsDAOImpl();
			CityDetails citydetailsCurrent = citydetailsDAO.getCityById(citydetail);
			if(null == citydetailsCurrent)
			{
			     session.save(citydetail);
			}
			else
			{
				System.out.println(" ========================================= ");
				System.out.println(citydetail.getCityId() + " has allredy  exists");
				System.out.println(" ========================================= ");
				
				return false;
				
			}
			
			
			tx.commit();
			
			session.flush();
			session.close();

			
			System.out.println(" ========================================= ");
			System.out.println(" addCity : @BackEnd End Successfully ");
			System.out.println(" ========================================= ");
			
			
			return true;
		}

		catch (Exception e) {
			System.out.println(" ========================================= ");
			System.out.println(" addCity : @BackEnd End wiht eror ");
			System.out.println(" ========================================= ");
			
			e.printStackTrace();

			return false;
		}
	}

	public boolean deleteCity(CityDetails citydetail) {
	
		try {
			
			System.out.println(" ========================================= ");
			System.out.println("  deleteCity  : @BackEnd Begin ");
			System.out.println(" ========================================= ");
					
					System.out.println(" user delete process begin111111111111111 ");
					
					SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
					Session session = sessionFactory.openSession();
					Transaction tx = session.beginTransaction();
					System.out.println(citydetail);
					CityDetailsDAO  obj = new CityDetailsDAOImpl();
					citydetail = obj.getCityById(citydetail);
					System.out.println(citydetail);
					session.delete(citydetail);
				
					tx.commit();
					session.flush();
					session.close();
			
					
					System.out.println(" ========================================= ");
					System.out.println(" deleteCity : @BackEnd End Successfully ");
					System.out.println(" ========================================= ");
					return true;
				}

				catch (Exception e) {
					
					System.out.println(" ========================================= ");
					System.out.println(  " deleteCity : @BackEnd End With ERROR "+e);
					System.out.println(" ========================================= ");
					//e.printStackTrace();
					return false;
				}

				


		
	}

	public boolean updateCity(CityDetails citydetail) {
		try {
			
			System.out.println(" ========================================= ");
			System.out.println("  updateCountry : @BackEnd Begin ");
			System.out.println(" ========================================= ");
					
					SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
					Session session = sessionFactory.openSession();
					Transaction tx = session.beginTransaction();
					System.out.println(citydetail);
					CityDetailsDAO  citydetailsDAO =new CityDetailsDAOImpl() ;
				CityDetails citydetails =  citydetailsDAO.getCityById(citydetail);
				
				String countryId = citydetails.getCountryId();
				System.out.println(citydetails);
			
				
				if(citydetails!= null)
				{
					
					citydetail.setCountryId(countryId);
					citydetails = citydetail;
				
					
					System.out.println("================================UPDATION1111 ");
					System.out.println(citydetails);
					System.out.println("================================UPDATION ");
				    session.update(citydetails);
				}
				
				else
				{
					return false;
				}
				tx.commit();
				session.flush();
				session.close();
				System.out.println(" ========================================= ");
				System.out.println(" updateCity : @BackEnd End Successfully ");
				System.out.println(" ========================================= ");
				

					return true;
				}

				catch (Exception e) {
					System.out.println(" ========================================= ");
					System.out.println(" updateCity : @BackEnd End with error ");
					System.out.println(" ========================================= ");
					e.printStackTrace();
					return false;
				}
	}

	public List<CityDetails> getAllCities() {
	
		try 
		{
			
			
			System.out.println(" ========================================= ");
			System.out.println("  getallCities : @BackEnd Begin ");
			System.out.println(" ========================================= ");
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			List<CityDetails> cityDetails = session.createQuery(" from CityDetails ").list();
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println(" ========================================= ");
			System.out.println(" getallCities : @BackEnd End Successfully ");
			System.out.println(" ========================================= ");
			
			return cityDetails;

		}
		catch (Exception e) {
		
			System.out.println(" ========================================= ");
			System.out.println(" getallCities : @BackEnd End With Error ");
			System.out.println(" ========================================= ");
			return null;
		}


		
		
	}

	public CityDetails getCityByName(CityDetails citydetail) {
	
		try {
			System.out.println(" ========================================= ");
			System.out.println("   getCitybyName  : @BackEnd Begin ");
			System.out.println(" ========================================= ");
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			System.out.println(citydetail.getCityName() );
			String hql = "from CityDetails where CityName  ='" +citydetail.getCityName()+"'" ;

			System.out.println("=========================hql===================");
			System.out.println(hql);
			System.out.println("=========================hql===================");
			
			
			CityDetails cityDetails = (CityDetails) session.createQuery(hql).uniqueResult();
			
	
			
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println(" ========================================= ");
			System.out.println(" getCitybyName : @BackEnd End Successfully ");
			System.out.println(" ========================================= ");
			
			return cityDetails;

			
		}

		catch (Exception e) {
			System.out.println(" ========================================= ");
			System.out.println(" getCitybyName : @BackEnd End With Error ");
			System.out.println(" ========================================= ");
			return null;
		}
		
}






	public CityDetails getCityById(CityDetails citydetail) {
	
		try {
			System.out.println(" ========================================= ");
			System.out.println("  getCountrybyId  : @BackEnd Begin ");
			System.out.println(" ========================================= ");
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			System.out.println(citydetail.getCityId() );
			String hql = "from CityDetails where cityId  = '" + citydetail.getCityId()+"'" ;


			CityDetails cityDetails = (CityDetails) session.createQuery(hql).uniqueResult();
			
			if(cityDetails == null){
				
				System.out.println("NO DATA OF THIS TYPE");
				return null;
			}
			
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println(" ========================================= ");
			System.out.println(" getCitybyId : @BackEnd End Successfully ");
			System.out.println(" ========================================= ");
			return cityDetails;

			
		}

		catch (Exception e) {
			System.out.println(" ========================================= ");
			System.out.println(" getCitybyId : @BackEnd End With Error ");
			System.out.println(" ========================================= ");
			return null;
		}
		
	}

	



}
