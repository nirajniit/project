package daoimpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import dao.CategoryDetailsDAO;
import dao.ProductDetailsDAO;
import dbconfig.ApplicationContextConfig;
import model.CategoryDetails;
import model.ProductDetails;



public class CategoryDetailsDAOImpl implements CategoryDetailsDAO {
	
	
	
	@Autowired
	private SessionFactory sessionFactory;
		
	public List <CategoryDetails> getCategoryProcutApproved(CategoryDetails cat){
		
		System.out.println("=================================");
		System.out.println("getCategoryProcutApproved : BackEnd Begin ");
		System.out.println("=================================");
		
		try {
			  
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			String hql = "from CategoryDetails where approved ='" + cat.getApproved() + "'";

			
			List <CategoryDetails> category =  session.createQuery(hql).list();
			System.out.println(category );
			
			
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println("=================================");
			System.out.println(" getCategoryProcutApproved  : BackEnd END successfully ");
			System.out.println("=================================");
				
			return category ;

			
		}

		catch (Exception e) {
			System.out.println("=================================");
			System.out.println(" getCategoryProcutApproved  : BackEnd END with error  ");
			System.out.println(e);
			System.out.println("=================================");
			return null;
		}
		
}
	public List <CategoryDetails> getCategoryProcutRating(CategoryDetails cat){
		

		
		
		
		return null;
	}
	
		
	public boolean addCategory(CategoryDetails cat)
	{
		
		System.out.println("==============================");
		System.out.println("addCategory : BackEnd begin");
		System.out.println("==============================");
		
		try {
	
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
		
			cat.setApproved("N");
			cat.setRrating("0");
			
		     System.out.println(cat);
				
		     CategoryDetailsDAO catDetailsDAO = new CategoryDetailsDAOImpl();
				
		     CategoryDetails catCurrent = catDetailsDAO.getCategoryById(cat);
			
			if(null == catCurrent)
			{
				
				System.out.println(cat);
				session.save(cat);
			
			}
			else
			{
				System.out.println("=======================");
				System.out.println(catCurrent +"\n has allredy  exists");
				System.out.println("=======================");
			}
			
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==============================");
			System.out.println("addCategory : BackEnd end Successfully");
			System.out.println("==============================");
           return true;
		}

		catch (Exception e) {
			System.out.println("==============================");
			System.out.println("addCategory : BackEnd end with Error ");
			System.out.println(e);
			e.printStackTrace();
			System.out.println("==============================");
           return false;
		}
		
	}
	

	
	    public boolean deleteCategory(CategoryDetails cat) {
		
	    	
	    System.out.println("==============================");
		System.out.println("deleteCategory : BackEnd begin");
		System.out.println("==============================");
		
		
		
		try {
			
		
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			System.out.println(cat);
			
			CategoryDetailsDAO categoryDetailsDAO = new CategoryDetailsDAOImpl();
			
			cat = categoryDetailsDAO.getCategoryById(cat);
			
			if(null == cat)
			{
				System.out.println("=======================");
				System.out.println(cat + " not Found");
				System.out.println("=======================");
				return false;
			}
			else
			{
				  session.delete(cat);
			}
			
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==============================");
			System.out.println("deleteCategory : BackEnd end Successfully");
			System.out.println("==============================");
			return true;
		}

		catch (Exception e) {
			

			System.out.println("==============================");
			System.out.println("deleteCategory : BackEnd end with Error ");
			System.out.println(e);
			System.out.println("==============================");
			return false;
		}
	}

	    
	public boolean updateCategory(CategoryDetails cat) {
		
		
		System.out.println("==============================");
		System.out.println("updateCategory : BackEnd begin");
		System.out.println("==============================");

			try
			{
				
				
				SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
				Session session = sessionFactory.openSession();
				Transaction tx = session.beginTransaction();
				CategoryDetailsDAO categoryDetailsDAO  = new CategoryDetailsDAOImpl();
				CategoryDetails currentCategoryDetails  = categoryDetailsDAO.getCategoryById(cat);
		
				if(currentCategoryDetails!= null)
				{
					
					Long productID = currentCategoryDetails.getProductID();
					cat.setProductID(productID);
					
					currentCategoryDetails = cat;
					
					System.out.println("================================UPDATION1111 ");
					System.out.println(currentCategoryDetails);
					System.out.println("================================UPDATION ");
				    session.update(currentCategoryDetails);

					tx.commit();
					session.flush();
					session.close();
				
				}
				else
				{
					return false;
				}
					
				
				
				System.out.println("==============================");
				System.out.println("updateCategory : BackEnd end Successfully");
				System.out.println("==============================");
				return true;
				
			}

			catch (Exception e) {
				System.out.println("==============================");
				System.out.println("updateCategory : BackEnd end with Error ");
				System.out.println(e);
				System.out.println("==============================");
				return false;
			}

	}

	public List<CategoryDetails> getAllCategory() {
		
		System.out.println("==============================");
		System.out.println("getAllCategory : BackEnd begin");
		System.out.println("==============================");
		
		try 
		{
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			List<CategoryDetails> cat = session.createQuery("from CategoryDetails order by catId desc").list();
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==============================");
			System.out.println("getAllCategory : BackEnd end 11111111111111111111111111111111111111111Successfully");
			System.out.println("==============================");
			return cat;

		}
		catch (Exception e) {
		    System.out.println("==============================");
			System.out.println("getAllCategory : BackEnd end with Error ");
			System.out.println(e);
			System.out.println("==============================");
			return null;
		}
	}



	public List<CategoryDetails> getAllCategoryForImage() {
		
		System.out.println("==============================");
		System.out.println("getAllCategory : BackEnd begin");
		System.out.println("==============================");
		
		try 
		{
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			List<CategoryDetails> cat = session.createQuery("from CategoryDetails").list();
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==============================");
			System.out.println("getAllCategory : BackEnd end 11111111111111111111111111111111111111111Successfully");
			System.out.println("==============================");
			return cat;

		}
		catch (Exception e) {
		    System.out.println("==============================");
			System.out.println("getAllCategory : BackEnd end with Error ");
			System.out.println(e);
			System.out.println("==============================");
			return null;
		}
	}

	
	
	public List <CategoryDetails> getCategoryByPrice(CategoryDetails cat) {
		
		
		System.out.println("=================================");
		System.out.println("getCategoryByPrice : BackEnd Begin ");
		System.out.println("=================================");
		
		try {
			  
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			String hql = "from CategoryDetails where CatPrice ='" + cat.getCatPrice() + "'";


			
			List <CategoryDetails> category =  session.createQuery(hql).list();
			System.out.println(category );
			
			
			
			
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println("=================================");
			System.out.println(" getCategoryByPrice  : BackEnd END successfully ");
			System.out.println("=================================");
				
			return category ;

			
		}

		catch (Exception e) {
			System.out.println("=================================");
			System.out.println(" getCategoryByPrice  : BackEnd END with error  ");
			System.out.println(e);
			System.out.println("=================================");
			return null;
		}
	}

	public List <CategoryDetails> getCategoryByName(CategoryDetails cat) {
		System.out.println("=================================");
		System.out.println("getCategoryByName : BackEnd Begin ");
		System.out.println("=================================");
		
		try {
			  
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			String hql = "from CategoryDetails where CatName ='" + cat.getCatName() + "'";


			
			List <CategoryDetails> category =  session.createQuery(hql).list();
			System.out.println(category );
			
			
			
			
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println("=================================");
			System.out.println(" getCategoryByName  : BackEnd END successfully ");
			System.out.println("=================================");
				
			return category ;

			
		}

		catch (Exception e) {
			System.out.println("=================================");
			System.out.println(" getCategoryByName  : BackEnd END with error  ");
			System.out.println(e);
			System.out.println("=================================");
			return null;
		}
	}

	public CategoryDetails getCategoryById(CategoryDetails cat) {
		
		System.out.println("=================================");
		System.out.println("getCategoryById : BackEnd Begin ");
		System.out.println("=================================");
		
		try {
			  
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			String hql = "from CategoryDetails where CatId ='" + cat.getCatId() + "'";


			
			CategoryDetails category = (CategoryDetails) session.createQuery(hql).uniqueResult();
			
			
			
			
			
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println("=================================");
			System.out.println(" getCategoryById  : BackEnd END successfully ");
			System.out.println("=================================");
				
			return category ;

			
		}

		catch (Exception e) {
			System.out.println("=================================");
			System.out.println(" getCategoryById  : BackEnd END with error  ");
			System.out.println(e);
			System.out.println("=================================");
			return null;
		}
	}

	public List <CategoryDetails> getCategoryProcutById(CategoryDetails cat) {
		System.out.println("=================================");
		System.out.println("getCategoryProcutById : BackEnd Begin ");
		System.out.println("=================================");
		
		try {
			  
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			String hql = "from CategoryDetails where ProductId ='" + cat.getProductID() + "'";


			
			List <CategoryDetails> category =  session.createQuery(hql).list();
			System.out.println(category );
			
			
			
			
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println("=================================");
			System.out.println(" getCategoryProcutById  : BackEnd END successfully ");
			System.out.println("=================================");
				
			return category ;

			
		}

		catch (Exception e) {
			System.out.println("=================================");
			System.out.println(" getCategoryProcutById  : BackEnd END with error  ");
			System.out.println(e);
			System.out.println("=================================");
			return null;
		}
		
	}
	@Override
	public List<CategoryDetails> getCategoryProcutApprovedandCountryID(CategoryDetails cat) {

		System.out.println("=================================");
		System.out.println("getCategoryProcutApproved : BackEnd Begin ");
		System.out.println("=================================");
		
		try {
			  
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			String hql = "from CategoryDetails where approved  ='" + cat.getApproved() + "' and countryId='"+cat.getCountryID()+"'";

			
			List <CategoryDetails> category =  session.createQuery(hql).list();
			System.out.println(category );
			
			
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println("=================================");
			System.out.println(" getCategoryProcutApproved  : BackEnd END successfully ");
			System.out.println("=================================");
				
			return category ;

			
		}

		catch (Exception e) {
			System.out.println("=================================");
			System.out.println(" getCategoryProcutApproved  : BackEnd END with error  ");
			System.out.println(e);
			System.out.println("=================================");
			return null;
		}

		
	}
	@Override
	public List<CategoryDetails> getCategoryProcutCountryId(CategoryDetails cat) {
		
		System.out.println("=================================");
		System.out.println("getCategoryProcutApproved : BackEnd Begin ");
		System.out.println("=================================");
		
		try {
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			String hql = "from CategoryDetails where  countryId ='"+cat.getCountryID()+"'";

			
			List <CategoryDetails> category =  session.createQuery(hql).list();
			System.out.println(category );
			
			
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println("=================================");
			System.out.println(" getCategoryProcutApproved  : BackEnd END successfully ");
			System.out.println("=================================");
				
			return category ;

			
		}

		catch (Exception e) {
			System.out.println("=================================");
			System.out.println(" getCategoryProcutApproved  : BackEnd END with error  ");
			System.out.println(e);
			System.out.println("=================================");
			return null;
		}

		
	}

}
