package daoimpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import dao.NewsDetailsDAO;
import dbconfig.ApplicationContextConfig;
import model.NewsDetails ;
import model.UserProfileDetails;
import model.NewsDetails;

public class NewsDetailsDAOImpl implements NewsDetailsDAO 
{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	    public boolean addNews(NewsDetails news) {
		
		System.out.println("==============================");
		System.out.println("addNews : BackEnd begin");
		System.out.println("==============================");
		
		try {
	
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
	             System.out.println(news);
				
		        NewsDetailsDAO newsDetailsDAO = new NewsDetailsDAOImpl();
				
				NewsDetails newsCurrent = newsDetailsDAO.getNewsById(news);
			
			if(null == newsCurrent )
			{
				
				
			session.save(news);
				
				
			}
			else
			{
				System.out.println("=======================");
				System.out.println(newsCurrent  + " has allredy  exists");
				System.out.println("=======================");
				return false;
			}
			
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==============================");
			System.out.println("addNews : BackEnd end Successfully");
			System.out.println("==============================");
           return true;
		}

		catch (Exception e) {
			System.out.println("==============================");
			System.out.println("addNews : BackEnd end with Error ");
			System.out.println(e);
			System.out.println("==============================");
           return false;
		}
		
	}
	

	   public boolean deleteNews(NewsDetails news) {
		
		
		System.out.println("==============================");
		System.out.println("deleteNews : BackEnd begin");
		System.out.println("==============================");
		
		
		
		try {
			
		
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			System.out.println(news);
			
			NewsDetailsDAO newsDetailsDAO = new NewsDetailsDAOImpl();
			
			news = newsDetailsDAO.getNewsById(news);
			
			if(null == news)
			{
				System.out.println("=======================");
				System.out.println(news + " not Found");
				System.out.println("=======================");
				return false;
			}
			else
			{
				  session.delete(news);
			}
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==============================");
			System.out.println("deleteNews : BackEnd end Successfully");
			System.out.println("==============================");
			
			return true;
		}

		  catch (Exception e) {

			System.out.println("==============================");
			System.out.println("deleteNews : BackEnd end with Error ");
			System.out.println(e);
			System.out.println("==============================");
			
			return false;
		}
	}
	

	   @Transactional
	   public boolean updateNews(NewsDetails news) {
		
		
		
		System.out.println("==============================");
		System.out.println("updateNews : BackEnd begin");
		System.out.println("==============================");

			try
			{
				SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
				Session session = sessionFactory.openSession();
				Transaction tx = session.beginTransaction();
				NewsDetailsDAO newsDetailsDAO  = new NewsDetailsDAOImpl();
				
				NewsDetails currentNewsDetails  = newsDetailsDAO.getNewsById(news);
				
				if(currentNewsDetails!= null)
				{
					 currentNewsDetails = news;
				    session.update(currentNewsDetails);
				    
					
				}
				else
				{
					
					return false;
				}
				tx.commit();
				session.flush();
				session.close();
				System.out.println("==============================");
				System.out.println("updateNews : BackEnd end Successfully");
				System.out.println("==============================");
				return true;
				
			}

			 catch (Exception e) {
				System.out.println("=========================================");
				System.out.println("updateNews : BackEnd end with Error ");
				System.out.println(e);
				System.out.println("===========================================");
				return false;
			}

		 }


	    public List<NewsDetails> getAllNews() {
		
		
		System.out.println("==============================");
		System.out.println("getAllNews() : BackEnd begin");
		System.out.println("==============================");
		
		try 
		{
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			List<NewsDetails> news = session.createQuery("from NewsDetails").list();
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==============================");
			System.out.println("getAllNews() : BackEnd end Successfully");
			System.out.println("==============================");
			return news;

		}
		    catch (Exception e) {
		    System.out.println("==============================");
			System.out.println("getAllNews() : BackEnd end with Error ");
			System.out.println(e);
			System.out.println("==============================");
			return null;
		}
		
}

	    public List<NewsDetails> getNewsByTitle(NewsDetails news) 
	    {
	    	
		System.out.println("=================================");
		System.out.println(" getNewsByTitle  : BackEnd Begin ");
		System.out.println("=================================");
		  
		try 
		{
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			String hql = "from NewsDetails where NewsTitle ='" + news.getNewsTitle() + "'";

			
			List <NewsDetails> newsDetails =  session.createQuery(hql).list();
			
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println("=================================");
			System.out.println(" getNewsByTitle  : BackEnd END successfully ");
			System.out.println("=================================");
			
			return newsDetails ;

			
		}

		catch (Exception e) {
			System.out.println("=================================");
			System.out.println("  getNewsByTitle  : BackEnd END with error  ");
			System.out.println(e);
			System.out.println("=================================");
			return null;
		}
	}

	public NewsDetails getNewsById(NewsDetails news) 
	
	{
		
		System.out.println("=================================");
		System.out.println(" getNewsById : BackEnd Begin ");
		System.out.println("=================================");
		
		try 
		{
			  int newsId= news.getNewsId();
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
		    
		  
		    
		    NewsDetails cnews = (NewsDetails) session.get(NewsDetails.class,newsId);
			
			
		    if(null == 	cnews)
		    {
		    	System.out.println("==================================");
				System.out.println(cnews+ " = NewsId");
				System.out.println("==================================");
				return null;
		    }
			
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println("=================================");
			System.out.println(" getNewsById  : BackEnd END successfully ");
			System.out.println("=================================");
				
			return cnews;
			
		}

		 catch (Exception e) {
			System.out.println("=================================");
			System.out.println(" getNewsById  : BackEnd END with error  ");
			System.out.println(e);
			System.out.println("=================================");
			return null;
		}
	}


	@Override
	public List<NewsDetails> getNewsByApproved(NewsDetails news) {
		System.out.println("=================================");
		System.out.println(" getNewsByApproved  : BackEnd Begin ");
		System.out.println("=================================");
		  
		try 
		{
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			String hql = "from NewsDetails where approved ='" + news.getApproved() + "'";

			
			List <NewsDetails> newsDetails =  session.createQuery(hql).list();
			
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println("=================================");
			System.out.println(" getNewsByApproved  : BackEnd END successfully ");
			System.out.println("=================================");
			
			return newsDetails ;

			
		}

		catch (Exception e) {
			System.out.println("=================================");
			System.out.println("  getNewsByApproved  : BackEnd END with error  ");
			System.out.println(e);
			System.out.println("=================================");
			return null;
		}

		
	}


	@Override
	public List<NewsDetails> getNewsByRating(NewsDetails news) {
		// TODO Auto-generated method stub
		return null;
	}

}
