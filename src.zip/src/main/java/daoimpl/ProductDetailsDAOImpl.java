package daoimpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Transaction;
import org.junit.Ignore;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import dao.ProductDetailsDAO;
import dbconfig.ApplicationContextConfig;
import model.ProductDetails;


public class ProductDetailsDAOImpl implements ProductDetailsDAO{
	@Autowired
	private SessionFactory sessionFactory;
	
		
	public List <ProductDetails> getProductByCityId(ProductDetails prd)
	{
		System.out.println("=================================");
		System.out.println(" getProductByCityId  : BackEnd Begin ");
		System.out.println("=================================");
		try {
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			String hql = "from ProductDetails where cityId ='" + prd.getCityId() + "'";

			
			List <ProductDetails> prds =  session.createQuery(hql).list();
			
			
			
			
			
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println("=================================");
			System.out.println(" getProductByCityId  : BackEnd END successfully ");
			System.out.println("=================================");
			
			return prds ;

			
		}

		catch (Exception e) {
			System.out.println("=================================");
			System.out.println("  getProductByCityId  : BackEnd END with error  ");
			System.out.println(e);
			System.out.println("=================================");
			return null;
		}
		
	}
	
	
	
	public boolean addProduct(ProductDetails prd) {
		
		System.out.println("==============================");
		System.out.println("addProduct : BackEnd begin");
		System.out.println("==============================");
		
		try {
	
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
	     System.out.println(prd);
				
				ProductDetailsDAO productDetailsDAO = new ProductDetailsDAOImpl();
				
				ProductDetails productCurrent = productDetailsDAO.getProductById(prd);
			
			if(null == productCurrent)
			{
				session.save(prd);
				
			}
			else
			{
				System.out.println("=======================");
				System.out.println(productCurrent + " has allredy  exists");
				System.out.println("=======================");
				return false;
			}
			
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==============================");
			 System.out.println("addProduct : data added in the BackEnd end Successfully");
			System.out.println("==============================");
            return true;
		}

		catch (Exception e) {
			System.out.println("==============================");
			System.out.println("addProduct : BackEnd end with Error ");
			System.out.println(e);
			System.out.println("==============================");
           return false;
		}
		
	}
	
	
	
	public boolean deleteProduct(ProductDetails prd) {
		
		System.out.println("==============================");
		System.out.println("deleteProduct : BackEnd begin");
		System.out.println("==============================");
		
		
		
		try {
			
		
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			System.out.println(prd);
			
			ProductDetailsDAO productDetailsDAO = new ProductDetailsDAOImpl();
			
			prd = productDetailsDAO.getProductById(prd);
			
			if(null == prd)
			{
				System.out.println("=======================");
				System.out.println(prd + " not Found");
				System.out.println("=======================");
				return false;
			}
			else
			{
				  session.delete(prd);
			}
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==============================");
			System.out.println("deleteProduct : BackEnd end Successfully");
			System.out.println("==============================");
			
			return true;
		}

		catch (Exception e) {

			System.out.println("==============================");
			System.out.println("deleteProduct : BackEnd end with Error ");
			System.out.println(e);
			System.out.println("==============================");
			
			return false;
		}
	}
	
	
	
	

	public boolean updateProduct(ProductDetails prd) {
	System.out.println("==============================");
	System.out.println("updateProduct : BackEnd begin");
	System.out.println("==============================");

		try
		{
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			ProductDetailsDAO productDetailsDAO  = new ProductDetailsDAOImpl();
			ProductDetails currentProductDetails  = productDetailsDAO.getProductById(prd);
			
			if(currentProductDetails != null)
			{
				String cityID = currentProductDetails.getCityId();
				prd.setCityId(cityID);
				currentProductDetails = prd;
			    session.update(currentProductDetails);
				
			}
			else
			{
				
				System.out.println(prd  + "  Not Found in the database ");
				return false;
			}
			
			
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==============================");
			System.out.println(" updateProduct : BackEnd end Successfully ");
			System.out.println("==============================");
			return true;
			
		}

		catch (Exception e) 
		{
			
			System.out.println("=========================================");
			System.out.println("updateProduct : BackEnd end with Error ");
			System.out.println(e);
			System.out.println("===========================================");
			return false;
			
			
		}

	}

	
	
	
	public List <ProductDetails> getAllProduct() {
		
		System.out.println("==============================");
		System.out.println("getAllProduct() : BackEnd begin");
		System.out.println("==============================");
		try 
		{
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			List<ProductDetails> prd = session.createQuery("from ProductDetails ORDER BY productID DESC").list();
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==============================");
			System.out.println("getAllProduct() : BackEnd end Successfully");
			System.out.println("==============================");
			return prd;

		}
		catch (Exception e) {
		    System.out.println("==============================");
			System.out.println("getAllProduct() : BackEnd end with Error ");
			System.out.println(e);
			System.out.println("==============================");
			return null;
		}
	}
	
	
	
	public ProductDetails getProductById(ProductDetails prd) {
		
		System.out.println("=================================");
		System.out.println(" getProductById : BackEnd Begin ");
		System.out.println("=================================");
		
		try 
		{
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			String hql = "from  ProductDetails where ProductID ='" + prd.getProductID()+"'" ;
		
			ProductDetails prd1 = (ProductDetails) session.createQuery(hql).uniqueResult();
			
			
			
			if(prd1 == null)
			{
				System.out.println(prd.getProductID() + " Does not Exists int the database ");
				return null;
			}
			
			
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println("=================================");
			System.out.println(" getProductById  : BackEnd END successfully ");
			System.out.println("=================================");
			
			return prd1;
			
		}

		catch (Exception e)
		{
			
			System.out.println("=================================");
			System.out.println(" getProductById  : BackEnd END with error  ");
			System.out.println(e);
			System.out.println("=================================");
			return null;
		}
	}

	
	public List<ProductDetails> getProductByName(ProductDetails prd) {
		
		System.out.println("=================================");
		System.out.println(" getProductByName  : BackEnd Begin ");
		System.out.println("=================================");
		try {
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			String hql = "from ProductDetails where ProductType ='" + prd.getProductType() + "'";

			
			List <ProductDetails> prds =  session.createQuery(hql).list();
			
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println("=================================");
			System.out.println(" getProductByName  : BackEnd END successfully ");
			System.out.println("=================================");
			
			return prds ;

			
		}

		catch (Exception e) {
			System.out.println("=================================");
			System.out.println("  getProductByName  : BackEnd END with error  ");
			System.out.println(e);
			System.out.println("=================================");
			return null;
		}

	}



	
}
