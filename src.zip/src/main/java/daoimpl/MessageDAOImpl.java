package daoimpl;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import dao.MessageDAO;
import dbconfig.ApplicationContextConfig;
import model.Message;


public class MessageDAOImpl implements  MessageDAO{

	@Override
	public boolean addMessage(Message message) {
		
		System.out.println(" ============================== ");
		System.out.println(" addMessage : BackEnd begin");
		System.out.println(" ============================== ");
		
		try {
	
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
	  		
			
			if(message!=null)
			{
		    	 session.save(message);
			
			}
			else
			{
				System.out.println("==================================================== ");
				System.out.println(message +" \n THERE IS NOTHING IN MESSAGE OBJECT ");
				System.out.println("==================================================== ");
				
				 return false;
				
			}
			tx.commit();
			session.flush();
			session.close();
			System.out.println(" ======================================= ");
			System.out.println(" addMessage : BackEnd end Successfully   ");
			System.out.println(" =======================================  ");
           return true;
		}

		catch (Exception e)
		{
			System.out.println(" ====================================== ");
			System.out.println(" addMessage : BackEnd end with Error    ");
			System.out.println(e);
			System.out.println(" ====================================== ");
            return false;
		}
		
	}

	@Override
	public boolean deleteMessageFrom(Message message) {
		
		
		
		
		return false;
	}

	@Override
	public boolean deleteMessageTo(Message message) {
		
		
		
		return false;
	}

	@Override
	public List<Message> getAllMessage() {
		
		
		return null;
	}

	@Override
	public List<Message> getAllMessageFrom(Message message) {
		
		
		
		
		return null;
	}

	@Override
	public List<Message> getAllMessageTo(Message message) {
		
		
		
		
		return null;
	}

}
