package daoimpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import dao.TestimonialDetailsDAO;
import dbconfig.ApplicationContextConfig;
import model.TestimonialDetails;



public class TestimonialDetailsDAOImpl implements TestimonialDetailsDAO{
	
	@Autowired
	private SessionFactory sessionFactory;

	public boolean addTestimonial(TestimonialDetails testimonial) {
		
		System.out.println("==============================");
		System.out.println("addTestimonial : BackEnd begin");
		System.out.println("==============================");
		
		try {
	
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
	            System.out.println(testimonial);
				
	            TestimonialDetailsDAO testimonialDetailsDAO = new TestimonialDetailsDAOImpl();
				TestimonialDetails testimonialCurrent = testimonialDetailsDAO.getTestimonialById(testimonial);
			
				
			if(null == testimonialCurrent )
			{
				
				
			session.save(testimonial);
		System.out.println(testimonial);
				
				
			}
			else
			{
				System.out.println("=======================");
				System.out.println(testimonialCurrent  + " has allredy  exists");
				System.out.println("=======================");
				return false;
			}
			
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==============================");
			System.out.println("addTestimonial : BackEnd end Successfully");
			System.out.println("==============================");
           return true;
		}

		catch (Exception e) {
			System.out.println("==============================");
			System.out.println("addTestimonial : BackEnd end with Error ");
			System.out.println(e);
			System.out.println("==============================");
           return false;
		 }
		
	}

	public boolean deleteTestimonial(TestimonialDetails testimonial) 
	{
		
		System.out.println("==============================");
		System.out.println("deleteTestimonial : BackEnd begin");
		System.out.println("==============================");
		
		try {
			
		
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			System.out.println(testimonial);
			
			TestimonialDetailsDAO testimonialDetailsDAO = new TestimonialDetailsDAOImpl();
			
			testimonial = testimonialDetailsDAO.getTestimonialById(testimonial);
			
			if(null == testimonial)
			{
				System.out.println("=======================");
				System.out.println(testimonial + " not Found");
				System.out.println("=======================");
				return false;
			}
			else
			{
				  session.delete(testimonial);
			}
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==============================");
			System.out.println("deleteTestimonial : BackEnd end Successfully");
			System.out.println("==============================");
			
			return true;
		   }

		  catch (Exception e) {

			System.out.println("==============================");
			System.out.println("deleteTestimonial : BackEnd end with Error ");
			System.out.println(e);
			System.out.println("==============================");
			
			return false;
		   }
	}

	public boolean updateTestimonial(TestimonialDetails testimonial) {
		
		System.out.println("==============================");
		System.out.println("updateTestimonial : BackEnd begin");
		System.out.println("==============================");

			try
			{
				SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
				Session session = sessionFactory.openSession();
				Transaction tx = session.beginTransaction();
				
				TestimonialDetailsDAO testimonialDetailsDAO  = new TestimonialDetailsDAOImpl();
				TestimonialDetails currentTestimonialDetails  = testimonialDetailsDAO.getTestimonialById(testimonial);
				
				if(currentTestimonialDetails!= null)
				{
					/*String cityID = currentTestimonialDetails.getCityId();
					Testimonial.setCityId(cityID);
					currentTestimonialDetails = Testimonial;*/
				    session.update(testimonial);
					
				}
				else
				{
					
					return false;
				}
				tx.commit();
				session.flush();
				session.close();
				System.out.println("==============================");
				System.out.println("updateTestimonial : BackEnd end Successfully");
				System.out.println("==============================");
				return true;
				
			}

			 catch (Exception e) {
				System.out.println("=========================================");
				System.out.println("updateTestimonial : BackEnd end with Error ");
				System.out.println(e);
				System.out.println("===========================================");
				return false;
			}
	}

	public boolean updateTestimonialShow(TestimonialDetails testimonial) {
		
		
		System.out.println("==============================");
		System.out.println("updateTestimonial : BackEnd begin");
		System.out.println("==============================");

			try
			{
				SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
				Session session = sessionFactory.openSession();
				Transaction tx = session.beginTransaction();
				
				TestimonialDetailsDAO testimonialDetailsDAO  = new TestimonialDetailsDAOImpl();
				TestimonialDetails currentTestimonialDetails  = testimonialDetailsDAO.getTestimonialById(testimonial);
				
				if(currentTestimonialDetails!= null)
				{
				    session.update(testimonial);
					
				}
				else
				{
					
					return false;
				}
				tx.commit();
				session.flush();
				session.close();
				System.out.println("==============================");
				System.out.println("updateTestimonial : BackEnd end Successfully");
				System.out.println("==============================");
				return true;
				
			}

			 catch (Exception e) {
				System.out.println("=========================================");
				System.out.println("updateTestimonial : BackEnd end with Error ");
				System.out.println(e);
				System.out.println("===========================================");
				return false;
			}
	}

	public List<TestimonialDetails> getAllTestimonial() 
	{
		
		System.out.println("==============================");
		System.out.println("getAllTestimonial() : BackEnd begin");
		System.out.println("==============================");
		
		try 
		{
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			List<TestimonialDetails> testimonial = session.createQuery("from TestimonialDetails").list();
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==============================");
			System.out.println("getAllTestimonial() : BackEnd end Successfully");
			System.out.println("==============================");
			return testimonial;

		}
		    catch (Exception e) {
		    System.out.println("==============================");
			System.out.println("getAllTestimonial() : BackEnd end with Error ");
			System.out.println(e);
			System.out.println("==============================");
			return null;
		}
	 }

	 public List<TestimonialDetails> getTestimonialByStatus(TestimonialDetails testimonial) {
		 
		System.out.println("=================================");
		System.out.println(" getTestimonialByTitle  : BackEnd Begin ");
		System.out.println("=================================");
		  
		try 
		{
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			String hql = "from TestimonialDetails where TestiMonialStatus ='" + testimonial.getTestiMonialStatus() + "'";

			
			List <TestimonialDetails> testimonialDetails =  session.createQuery(hql).list();
			
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println("=================================");
			System.out.println(" getTestimonialByTitle  : BackEnd END successfully ");
			System.out.println("=================================");
			
			return testimonialDetails ;

			
		}

		catch (Exception e) {
			System.out.println("=================================");
			System.out.println("  getTestimonialByTitle  : BackEnd END with error  ");
			System.out.println(e);
			System.out.println("=================================");
			return null;
		}
	}

	
	public TestimonialDetails getTestimonialById(TestimonialDetails testimonial) 
	{
		
		System.out.println("=================================");
		System.out.println(" getTestimonialById : BackEnd Begin ");
		System.out.println("=================================");
		
		try 
		{
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
	        int currenttestimonial=testimonial.getTestiMonialId();
		   
		    
			String hql = "from TestimonialDetails where TestimonialId ='" + testimonial.getTestiMonialId()+"'" ;
		
			testimonial = (TestimonialDetails) session.createQuery(hql).uniqueResult();
			
		    if(null == 	testimonial)
		    {
		    	System.out.println("==================================");
				System.out.println(currenttestimonial+ " = TestimonialId");
				System.out.println("==================================");
				return null;
		    }
			
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println("=================================");
			System.out.println(" getTestimonialById  : BackEnd END successfully ");
			System.out.println("=================================");
				
			return testimonial;
			
		}

		catch (Exception e)
		{
			System.out.println("=================================");
			System.out.println(" getTestimonialById  : BackEnd END with error  ");
			System.out.println(e);
			System.out.println("=================================");
			return null;
		}
	}
	
	public List<TestimonialDetails> getTestimonialByEmail(TestimonialDetails testimonial){
	
		System.out.println("=================================");
		System.out.println(" getTestimonialByEmail : BackEnd Begin ");
		System.out.println("=================================");
		try 
		{
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
		    
			String Email=testimonial.getUserEmail();
			String hql = "from TestimonialDetails where useremail ='" + Email + "'";
			
			List <TestimonialDetails> testimonialDetails =  session.createQuery(hql).list();
			
			if(testimonialDetails == null)
			{
				return null;
			}
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println("=================================");
			System.out.println(" getTestimonialByEmail  : BackEnd END successfully ");
			System.out.println("=================================");
		
		
		return testimonialDetails;
		}
    catch (Exception e) {
    System.out.println("==============================");
	System.out.println(" getTestimonialByEmail s: BackEnd end with Error ");
	System.out.println(e);
	System.out.println("==============================");
	return null;
}

}

	@Override
	public List<TestimonialDetails> getTestimonialByApproved(TestimonialDetails testimonial) {
		System.out.println("=================================");
		System.out.println(" getTestimonialByApproved  : BackEnd Begin ");
		System.out.println("=================================");
		  
		try 
		{
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			String hql = "from TestimonialDetails where approved ='" + testimonial.getApproved() + "'";

			
			List <TestimonialDetails> testimonialDetails =  session.createQuery(hql).list();
			
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println("=================================");
			System.out.println(" getTestimonialByApproved  : BackEnd END successfully ");
			System.out.println("=================================");
			
			return testimonialDetails ;

			
		}

		catch (Exception e) 
		{
			System.out.println("   ========================================================  ");
			System.out.println("   getTestimonialByApproved  : BackEnd END with error      ");
			System.out.println(e);
			System.out.println("   ========================================================  ");
			return null;
		}
	}

	@Override
	public List<TestimonialDetails> getTestimonialByRating(TestimonialDetails testimonial) {
		// TODO Auto-generated method stub
		return null;
	}
}
