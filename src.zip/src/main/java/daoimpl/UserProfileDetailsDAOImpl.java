package daoimpl;

import java.util.List;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;


import dao.UserProfileDetailsDAO;

import dbconfig.ApplicationContextConfig;

import model.UserProfileDetails;


public class UserProfileDetailsDAOImpl implements UserProfileDetailsDAO{

	    @Autowired
	    private SessionFactory sessionFactory;
		public List<UserProfileDetails> getUserProfileDetails() {

		    System.out.println("==============================");
		    System.out.println(" getAllJobDetails : BackEnd begin");
		    System.out.println("==============================");
		    
		    
		try 
		{

			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			List<UserProfileDetails> profile = session.createQuery("from UserProfileDetails").list();
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==============================");
			System.out.println("getAllProfileDetails : BackEnd end Successfully");
			System.out.println("==============================");
			return profile;

		}
		catch (Exception e) {
		    System.out.println("==============================");
			System.out.println(" getAllProfileDetails : BackEnd end with Error ");
			System.out.println(e);
			System.out.println("==============================");
			return null;
		}
	}

	public boolean saveUserProfileDetails(UserProfileDetails profile) {
		System.out.println("==============================");
		System.out.println("saveUserProfileDetails : BackEnd begin");
		System.out.println("==============================");

		try {
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			
			UserProfileDetailsDAO UserProfileDetailsDAO  = new UserProfileDetailsDAOImpl();
			UserProfileDetails cprofile  = UserProfileDetailsDAO.getProfileById(profile);
		
			
			if(null == cprofile)
			{
				session.save( profile);
			}
			else
			{
				System.out.println("====================================");
				System.out.println( cprofile + "   has allredy  exists ");
				System.out.println("====================================");
				return false;
			}
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==============================");
			System.out.println("saveUserProfileDetails: BackEnd end Successfully");
			System.out.println("==============================");
           return true;
		}

		catch (Exception e) {
			System.out.println("==============================");
			System.out.println("saveUserProfileDetails : BackEnd end with Error ");
			System.out.println(e);
			System.out.println("==============================");
           return false;
		}

	}

	public boolean updateUserProfileDetails(UserProfileDetails profile) {
		
		
		  System.out.println("==============================");
		    System.out.println("updateUserProfileDetails  : BackEnd begin");
		    System.out.println("==============================");
		try {
			
			
   		    SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
		  UserProfileDetailsDAO userProfileDetailsDAO  = new UserProfileDetailsDAOImpl();
		  UserProfileDetails cprofile  = userProfileDetailsDAO.getProfileById(profile);
			
			if(cprofile != null  )
			{
			
			session.update(profile);
				
			System.out.println("=======================");
			System.out.println(" \n================ Update Details SucessFully=====================");
			System.out.println("=======================");
				
			}
			else
			{
			System.out.println("=======================");
			System.out.println( cprofile + " \n================ Details Dose Not Exits=====================");
			System.out.println("=======================");
		    return false;
			}
			
		   tx.commit();
		   session.flush();
		   session.close();
		   System.out.println("==============================");
		   System.out.println("updateUserProfileDetails : BackEnd end Successfully");
		   System.out.println("==============================");
		   return true;
		}

     catch (Exception e) {
  	   System.out.println("==============================");
		   System.out.println("updateUserProfileDetails : BackEnd end with Error ");
		   System.out.println(e);
		   System.out.println("==============================");
		   return false;
		}
				
	}

	public boolean deleteUserProfileDetails(UserProfileDetails profile) {

    	System.out.println("==============================");
	    System.out.println("deleteUserProfileDetails : BackEnd begin");
	    System.out.println("==============================");
	try {
		
		SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		
         UserProfileDetailsDAO userProfileDetailsDAO  = new UserProfileDetailsDAOImpl();
		UserProfileDetails cprofile  = userProfileDetailsDAO.getProfileById(profile);
		
		if(null != cprofile)
		{
			
		session.delete( profile);
		System.out.println("=======================");
		System.out.println(" \n================ Delete Details Sucessfully =====================");
		System.out.println("=======================");
			
		}
		else
		{
		System.out.println("=======================");
		System.out.println(" \n================ Details Dose Not Exits =====================");
		System.out.println("=======================");
		return false;
		}
		
		tx.commit();
		session.flush();
		session.close();
		System.out.println("==============================");
		System.out.println("deleteUserProfileDetails: BackEnd end Successfully");
		System.out.println("==============================");
        return true;
	}

	catch (Exception e) {
		System.out.println("==============================");
		System.out.println("deleteUserProfileDetails : BackEnd end with Error ");
		System.out.println(e);
		System.out.println("==============================");
        return false;
	}
		
		
	}

	public UserProfileDetails getProfileById(UserProfileDetails profile) {
		
		
		System.out.println("=================================");
    	System.out.println(" getUserProfileDetailsById : BackEnd Begin ");
	    System.out.println("=================================");
	
	  try {
		  
	    int Id= profile.getId();
		System.out.println("IN THEE JOB BY ID METHOD : "+profile.getId());
		SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		
		
		UserProfileDetails cprofile = (UserProfileDetails) session.get(UserProfileDetails.class,Id);
	
		System.out.println("AND HERE IS THE RETURN" +cprofile);
		
		tx.commit();
		session.flush();
		session.close();
		
		
		
		
		System.out.println("=================================");
		System.out.println(" getUserProfileDetailsById   : BackEnd END successfully ");
		System.out.println("=================================");
	
		
			if(cprofile == null)
			{
				return null;
			}
		
			
		return cprofile;

		
	}

	catch (Exception e) {
		System.out.println("=================================");
		System.out.println(" getUserProfileDetailsById  : BackEnd END with error  ");
		System.out.println(e);
		System.out.println("=================================");
		return null;
	}
	}

	public List<UserProfileDetails> getProfileByEmailId(UserProfileDetails profile) 
	
	{
		
		System.out.println("=========================================");
		System.out.println(" getUserProfileDetailsByEmail : BackEnd Begin ");
		System.out.println("=========================================");
		
		try {
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			String hql = "from  UserProfileDetails  where userEmail ='" +profile.getUserEmail()+"'";
			
		  List <UserProfileDetails> job1 = (List<UserProfileDetails>) session.createQuery(hql).list();
			System.out.println(job1);
			
		
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println("=====================================================");
			System.out.println(" getUserProfileDetailsByEmail  : BackEnd END successfully ");
			System.out.println("=====================================================");
				
			return job1;

			}

		catch (Exception e) {
			System.out.println("===================================================");
			System.out.println(" getUserProfileDetailsByEmail : BackEnd END with error  ");
			System.out.println(e);
			System.out.println("====================================================");
			return null;
		}
	
	
	
	}

}
