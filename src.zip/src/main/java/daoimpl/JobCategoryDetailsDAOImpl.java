package daoimpl;
import model.JobCategoryDetails;
import model.JobCategoryDetails;
import model.JobCategoryDetails;

import java.util.Date;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import dao.JobCategoryDetailsDAO;
import dbconfig.ApplicationContextConfig;

public class JobCategoryDetailsDAOImpl implements JobCategoryDetailsDAO 
{
	@Autowired
	private SessionFactory sessionFactory;
	
	public List<JobCategoryDetails> getAllJobDetails() 
	{
		    System.out.println("==============================");
		    System.out.println(" getAllJobDetails : BackEnd begin");
		    System.out.println("==============================");
		    
		    
		try 
		{
	
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			List<JobCategoryDetails> job = session.createQuery("from JobCategoryDetails").list();
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==============================");
			System.out.println(" getAllJobDetails : BackEnd end Successfully");
			System.out.println("==============================");
			return job;

		}
		catch (Exception e) {
		    System.out.println("==============================");
			System.out.println(" getAllJobDetails : BackEnd end with Error ");
			System.out.println(e);
			System.out.println("==============================");
			return null;
		}
	}

	public boolean saveJobCategoryDetails(JobCategoryDetails job) {
		   System.out.println("==============================");
		   System.out.println("savekJobDetails : BackEnd begin");
		   System.out.println("==============================");

		try
		   {
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			
			
			//System.out.println("job=" + job.getJob().getName() + "& job =" + job.getJob().getName());
			JobCategoryDetailsDAO jobDetailsDAO  = new JobCategoryDetailsDAOImpl();
			System.out.println("IN THE SAVE METHOD : "+job.getJobCategoryId());
			JobCategoryDetails cjob  = jobDetailsDAO.getJobByID(job);
		
			
			if(null == cjob)
			{
				
			session.save( job);
				
			}
			else
			{
			System.out.println("=======================");
			System.out.println( cjob + "\n================ has allredy  exists=====================");
			System.out.println("=======================");
				return false;
			}
			
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==============================");
			System.out.println("savekJobDetails: BackEnd end Successfully");
			System.out.println("==============================");
            return true;
		}

		    catch (Exception e) {
			System.out.println("==============================");
			System.out.println("savekJobDetails : BackEnd end with Error ");
			System.out.println(e);
			System.out.println("==============================");
            return false;
		}

	}
	public boolean updateJobCategoryDetails(JobCategoryDetails job) {
		
		    System.out.println("==============================");
		    System.out.println("updateJobDetaild : BackEnd begin");
		    System.out.println("==============================");
		try {
			
			
     		SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			//System.out.println("job=" + job.getJob().getName() + "& job =" + job.getJob().getName());
			JobCategoryDetailsDAO jobDetailsDAO  = new JobCategoryDetailsDAOImpl();
		    JobCategoryDetails cjob  = jobDetailsDAO.getJobByID(job);
			
			if(null != cjob)
			{
				
				
				String jobid= cjob.getJobCategoryId();
				job.setJobCategoryId(jobid);
				String DateTime=cjob .getDateTime();
				System.out.println("Update  date ="+DateTime);
				cjob =job ;
				
			session.update( job);
				
			System.out.println("=======================");
			System.out.println(" \n================ Update Details SucessFully=====================");
			System.out.println("=======================");
				
			}
			else
			{
			System.out.println("=======================");
			System.out.println( cjob + " \n================ Details Dose Not Exits=====================");
			System.out.println("=======================");
		    return false;
			}
			
		   tx.commit();
		   session.flush();
		   session.close();
		   System.out.println("==============================");
		   System.out.println("updateJobDetaild: BackEnd end Successfully");
		   System.out.println("==============================");
		   return true;
		}

       catch (Exception e) {
    	   System.out.println("==============================");
		   System.out.println("updateJobDetaild : BackEnd end with Error ");
		   System.out.println(e);
		   System.out.println("==============================");
		   return false;
		}
			

	}

     public boolean deleteJobCategoryDetails(JobCategoryDetails job) {
	    	System.out.println("==============================");
		    System.out.println("deleteJobDetaild : BackEnd begin");
		    System.out.println("==============================");
		try {
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			JobCategoryDetailsDAO jobDetailsDAO  = new JobCategoryDetailsDAOImpl();
			JobCategoryDetails cjob  = jobDetailsDAO.getJobByID(job);
			
			if(null != cjob)
			{
				
			session.delete( job);
			System.out.println("=======================");
			System.out.println(" \n================ Delete Details Sucessfully =====================");
			System.out.println("=======================");
				
			}
			else
			{
			System.out.println("=======================");
			System.out.println(" \n================ Details Dose Not Exits =====================");
			System.out.println("=======================");
			return false;
			}
			
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==============================");
			System.out.println("deleteJobDetaild: BackEnd end Successfully");
			System.out.println("==============================");
            return true;
		}

		catch (Exception e) {
			System.out.println("==============================");
			System.out.println("deleteJobDetaild : BackEnd end with Error ");
			System.out.println(e);
			System.out.println("==============================");
            return false;
		}
			
			
	}

	public JobCategoryDetails getJobByID(JobCategoryDetails job) {


     		System.out.println("=================================");
	    	System.out.println(" getJobDetailsById : BackEnd Begin ");
		    System.out.println("=================================");
		
		try {
		 String JobCategoryId= job.getJobCategoryId();
			System.out.println("IN THEE JOB BY ID METHOD : "+job.getJobCategoryId());
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			
			JobCategoryDetails job1 = (JobCategoryDetails) session.get(JobCategoryDetails.class,JobCategoryId);
		
			System.out.println("AND HERE IS THE RETURN" +job1);
			
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println("=================================");
			System.out.println(" getJobDetailsById   : BackEnd END successfully ");
			System.out.println("=================================");
				
			return job1;

			
		}

		catch (Exception e) {
			System.out.println("=================================");
			System.out.println(" getJobDetailsById  : BackEnd END with error  ");
			System.out.println(e);
			System.out.println("=================================");
			return null;
		}

	}

	public List<JobCategoryDetails>getJobByTitle(JobCategoryDetails job) {
		
		   System.out.println("=================================");
		   System.out.println(" getJobDetailsByTitle : BackEnd Begin ");
		   System.out.println("=================================");
		
		try {
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			String hql = "from JobCategoryDetails where JobTitle ='" +job.getJobTitle()+"'";
			
		  List <JobCategoryDetails> job1 = (List<JobCategoryDetails>) session.createQuery(hql).list();
			System.out.println(job1);
			
		
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println("=================================");
			System.out.println(" getJobDetailsByTitle  : BackEnd END successfully ");
			System.out.println("=================================");
				
			return job1;

			}

		catch (Exception e) {
			System.out.println("=================================");
			System.out.println(" getJobDetailsByTitle : BackEnd END with error  ");
			System.out.println(e);
			System.out.println("=================================");
			return null;
		}


	}

	public List<JobCategoryDetails> getJobTypeId(JobCategoryDetails job) {
		
		System.out.println("=================================");
		System.out.println(" getJobCategoryDetailsById : BackEnd Begin ");
		System.out.println("=================================");
		
		try {
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			String hql = "from  JobCategoryDetails  where JobTypeId ='" +job.getJobTypeId()+"'";
			
		  List <JobCategoryDetails> job1 = (List<JobCategoryDetails>) session.createQuery(hql).list();
			
			if(job1 == null)
			{
				return null;
			}
		  
		
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println("=================================");
			System.out.println(" getJobCategoryDetailsById  : BackEnd END successfully ");
			System.out.println("=================================");
				
			return job1;

			}

		catch (Exception e) {
			System.out.println("=================================");
			System.out.println(" getJobCategoryDetailsById : BackEnd END with error  ");
			System.out.println(e);
			System.out.println("=================================");
			return null;
		}
	}

	
	
}
