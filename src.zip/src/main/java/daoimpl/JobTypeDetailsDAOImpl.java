package daoimpl;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import dao.JobTypeDetailsDAO;
import dbconfig.ApplicationContextConfig;
import model.JobTypeDetails;

public class JobTypeDetailsDAOImpl implements JobTypeDetailsDAO {
	
	
	
	@Autowired
	private SessionFactory sessionFactory;

	public List<JobTypeDetails> getAllJobTypeDetails() 
	{
		System.out.println("==============================");
		System.out.println(" getAllJobTypeDetails : BackEnd begin");
		System.out.println("==============================");
	
		try 
		{
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			List<JobTypeDetails> job = session.createQuery("from JobTypeDetails").list();
	
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==============================");
			System.out.println(" getAllJobTypeDetails : BackEnd end Successfully");
			System.out.println("==============================");
			return job;

		}
		catch (Exception e) 
		{
			
		    System.out.println("==============================");
			System.out.println(" getAllJobTypeDetails : BackEnd end with Error ");
			System.out.println(e);
			System.out.println("==============================");
			return null;
			
		}
	}
	public boolean saveJobTypeDetails(JobTypeDetails job) {
		System.out.println("==============================");
		System.out.println("saveJobTypeDetails : BackEnd begin");
		System.out.println("==============================");

		try {
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			
			JobTypeDetailsDAO jobTypeDetailsDAO  = new JobTypeDetailsDAOImpl();
			System.out.println("IN THE SAVE METHOD : "+job.getJobTypeId());
			JobTypeDetails cjob  = jobTypeDetailsDAO.getJobByTypeId(job);
		
			
			if(null == cjob)
			{
				session.save( job);
			}
			else
			{
				System.out.println("====================================");
				System.out.println( cjob + "   has allredy  exists ");
				System.out.println("====================================");
				return false;
			}
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==============================");
			System.out.println("saveJobTypeDetails: BackEnd end Successfully");
			System.out.println("==============================");
           return true;
		}

		catch (Exception e) {
			System.out.println("==============================");
			System.out.println("saveJobTypeDetails : BackEnd end with Error ");
			System.out.println(e);
			System.out.println("==============================");
           return false;
		}

	}

	public boolean updateJobTypeDetails(JobTypeDetails job) {
		System.out.println("==============================");
		System.out.println("updateJobTypeDetails: BackEnd begin");
		System.out.println("==============================");
		try {
			
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			//System.out.println("job=" + job.getJob().getName() + "& job =" + job.getJob().getName());
			JobTypeDetailsDAO jobTypeDetailsDAO  = new JobTypeDetailsDAOImpl();
			JobTypeDetails cjob  = jobTypeDetailsDAO.getJobByTypeId(job);
		
			String cityid = cjob.getCityId();
			job.setCityId(cityid);
			
			if(null != cjob)
			{
				cjob=job;
				session.update(cjob);
				
				System.out.println(" =======================================");
				System.out.println("  \n Update Details SucessFully         ");
				System.out.println(" =======================================");
				
			}
			else
			{
				 System.out.println("======================================");
				 System.out.println( cjob + " Details Dose Not Exits ");
			     System.out.println("=======================================");
			   return false;
			}
			
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==================================================");
			System.out.println("updateJobTypeDetails: BackEnd end Successfully");
			System.out.println("==================================================");
           return true;
		}

		catch (Exception e) {
			System.out.println("===============================================");
			System.out.println("updateJobTypeDetails: BackEnd end with Error ");
			System.out.println(e);
			System.out.println("================================================");
           return false;
		}
			
	}

	public boolean deleteJobTypeDetails(JobTypeDetails job) {
		System.out.println("==============================");
		System.out.println("deleteJobTypeDetails : BackEnd begin");
		System.out.println("==============================");
		try {
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			JobTypeDetailsDAO jobTypeDetailsDAO  = new JobTypeDetailsDAOImpl();
			JobTypeDetails cjob  = jobTypeDetailsDAO.getJobByTypeId(job);
			
			if(null != cjob)
			{
				
				session.delete( job);
				System.out.println("=======================");
				System.out.println(" \n================ Delete Details Sucessfully =====================");
				System.out.println("=======================");
				
			}
			else
			{
				System.out.println("=======================");
				System.out.println(" \n================ Details Dose Not Exits =====================");
				System.out.println("=======================");
				return false;
			}
			
			tx.commit();
			session.flush();
			session.close();
			System.out.println("==============================");
			System.out.println("deleteJobTypeDetails: BackEnd end Successfully");
			System.out.println("==============================");
           return true;
		}

		catch (Exception e) {
			System.out.println("==============================");
			System.out.println("deleteJobTypeDetails : BackEnd end with Error ");
			System.out.println(e);
			System.out.println("==============================");
           return false;
		}
			
	}

	public JobTypeDetails getJobByTypeId(JobTypeDetails job) {

		System.out.println("=================================");
		System.out.println(" getJobTypeDetailsById : BackEnd Begin ");
		System.out.println("=================================");
		
		try
		{
		
			String JobTypeId = job.getJobTypeId();
			
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			JobTypeDetails jobTypeDetails = (JobTypeDetails) session.get(JobTypeDetails.class,JobTypeId);
			
			if(jobTypeDetails == null)
			{
				System.out.println("==================================================");
				System.out.println(" getProductById  : Data Not Found  ");
				System.out.println("==================================================");
				return null;
			}
			
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println("==================================================");
			System.out.println(" getProductById  : BackEnd END successfully ");
			System.out.println("==================================================");
				
			return jobTypeDetails;
		}

		catch (Exception e) 
		{
			System.out.println("=====================================================");
			System.out.println(" getJobTypeDetailsById  : BackEnd END with error  ");
			System.out.println(e);
			System.out.println("=====================================================");
			return null;
		}
		

	}


	   public List<JobTypeDetails> getJobByType(JobTypeDetails job)
	   {
		System.out.println("=========================================");
		System.out.println(" getJobTypeDetailsBy : BackEnd Begin ");
		System.out.println("=========================================");
		
		try {
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			String hql = "from  JobTypeDetails  where JobType ='" +job.getJobType()+"'";
			
		  List <JobTypeDetails> job1 = (List<JobTypeDetails>) session.createQuery(hql).list();
			System.out.println(job1);
			
		
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println("=====================================================");
			System.out.println(" getJobTypeDetailsBy  : BackEnd END successfully ");
			System.out.println("=====================================================");
				
			return job1;

			}

		catch (Exception e) {
			System.out.println("===================================================");
			System.out.println(" getJobTypeDetailsBy : BackEnd END with error  ");
			System.out.println(e);
			System.out.println("====================================================");
			return null;
		}


	}


}


