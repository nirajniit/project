package daoimpl;

import java.util.List;
import dao.CountryDetailsDAO;
import model.CountryDetails;
import java.beans.Expression;
import java.util.List;
import javax.management.Query;
import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import dbconfig.ApplicationContextConfig;

public class CountryDetailsDAOImpl implements CountryDetailsDAO {

	@Override
	public boolean addCountry(CountryDetails countryDetails) {
		// TODO Auto-generated method stub
		
		System.out.println(" ========================================= ");
		System.out.println(" addCountry : @BackEnd Begin ");
		System.out.println(" ========================================= ");
		
		try
		{
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			
			CountryDetailsDAO countryDetailsDAO = new CountryDetailsDAOImpl();
			CountryDetails countryDetailsCurrent = countryDetailsDAO.getCountrybyId(countryDetails);
			if(null == countryDetailsCurrent)
			{
			     session.save(countryDetails);
			}
			else
			{
				System.out.println(" ========================================= ");
				System.out.println(countryDetails.getCountryId() + " has allredy  exists");
				System.out.println(" ========================================= ");
				
				return false;
				
			}
			
			
			tx.commit();
			
			session.flush();
			session.close();

			
			System.out.println(" ========================================= ");
			System.out.println(" addCountry : @BackEnd End Successfully ");
			System.out.println(" ========================================= ");
			
			
			return true;
		}

		catch (Exception e) {
			System.out.println(" ========================================= ");
			System.out.println(" addCountry : @BackEnd End wiht eror ");
			System.out.println(" ========================================= ");
			
			e.printStackTrace();

			return false;
		}
	
		
	

	}

	@Override
	public boolean deleteCountrybyId(CountryDetails countryDetails) {

try {
	
	System.out.println(" ========================================= ");
	System.out.println("  deleteCountry  : @BackEnd Begin ");
	System.out.println(" ========================================= ");
			
			System.out.println(" user delete process begin111111111111111 ");
			
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			System.out.println(countryDetails );
			CountryDetailsDAO  obj = new CountryDetailsDAOImpl();
			countryDetails = obj.getCountrybyId(countryDetails);
			System.out.println(countryDetails );
			session.delete(countryDetails);
		
			tx.commit();
			session.flush();
			session.close();
			System.out.println(" user delete process Done ");
			
			System.out.println(" ========================================= ");
			System.out.println(" deleteCountry : @BackEnd End Successfully ");
			System.out.println(" ========================================= ");
			return true;
		}

		catch (Exception e) {
			
			System.out.println(" ========================================= ");
			System.out.println(" deleteCountry : @BackEnd End With ERROR ");
			System.out.println(" ========================================= ");
			e.printStackTrace();
			return false;
		}

		

	}

	@Override
	public boolean updateCountry(CountryDetails countryDetails) {
	
		
		try {
					
			System.out.println(" ========================================= ");
			System.out.println("  updateCountry : @BackEnd Begin ");
			System.out.println(" ========================================= ");
					
					SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
					Session session = sessionFactory.openSession();
					Transaction tx = session.beginTransaction();
					System.out.println(countryDetails);
					CountryDetailsDAO  countrydetailsDAO =new CountryDetailsDAOImpl() ;
				CountryDetails currentcountrydetails =  countrydetailsDAO.getCountrybyId(countryDetails);
				System.out.println(currentcountrydetails);
			
				
				if(currentcountrydetails != null)
				{
					currentcountrydetails = countryDetails;
					
					
					System.out.println("================================UPDATION1111 ");
					System.out.println(currentcountrydetails);
					System.out.println("================================UPDATION ");
				    session.update(currentcountrydetails);
				}
				
				else
				{
					System.out.println(" ========================================= ");
					System.out.println(countryDetails.getCountryId() + "  Not Found int the CountryDetails Table ");
					System.out.println(" ========================================= ");
					
					return false;
				}
				tx.commit();
				session.flush();
				session.close();
				System.out.println(" ========================================= ");
				System.out.println(" updateCountry : @BackEnd End Successfully ");
				System.out.println(" ========================================= ");
				

					return true;
				}

				catch (Exception e) {
					System.out.println(" ========================================= ");
					System.out.println(" updateCountry : @BackEnd End with error ");
					System.out.println(" ========================================= ");
					e.printStackTrace();
					return false;
				}

	}

	
	@Override
	public List<CountryDetails> getallCountries() {
		try 
		{
			
			
			System.out.println(" ========================================= ");
			System.out.println("  getallCountries : @BackEnd Begin ");
			System.out.println(" ========================================= ");
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			List<CountryDetails> countryDetails = session.createQuery(" from CountryDetails ").list();
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println(" ========================================= ");
			System.out.println(" getallCountries : @BackEnd End Successfully ");
			System.out.println(" ========================================= ");
			
			return countryDetails;

		}
		catch (Exception e) {
		
			System.out.println(" ========================================= ");
			System.out.println(" getallCountries : @BackEnd End With Error ");
			System.out.println(" ========================================= ");
			return null;
		}

	}
	
	

	@Override
	public CountryDetails getCountrybyName(CountryDetails cd) {
		try {
			System.out.println(" ========================================= ");
			System.out.println("   getCountrybyName  : @BackEnd Begin ");
			System.out.println(" ========================================= ");
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			System.out.println(cd.getCountryName() );
			String hql = "from CountryDetails where CountryName  ='" +cd.getCountryName()+"'" ;

			System.out.println("=========================hql===================");
			System.out.println(hql);
			System.out.println("=========================hql===================");
			
			
			CountryDetails countryDetails = (CountryDetails) session.createQuery(hql).uniqueResult();
			
	
			
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println(" ========================================= ");
			System.out.println(" getCountrybyName : @BackEnd End Successfully ");
			System.out.println(" ========================================= ");
			
			return countryDetails;

			
		}

		catch (Exception e) {
			System.out.println(" ========================================= ");
			System.out.println(" getCountrybyName : @BackEnd End With Error ");
			System.out.println(" ========================================= ");
			return null;
		}
		

	}

	@Override
	public CountryDetails getCountrybyId(CountryDetails cd) 
	{
		
		try 
		{
			System.out.println(" ========================================= ");
			System.out.println("  getCountrybyId  : @BackEnd Begin ");
			System.out.println(" ========================================= ");
			SessionFactory sessionFactory = ApplicationContextConfig.getSessionFactory(ApplicationContextConfig.getDataSource());
			Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			System.out.println(cd.getCountryId() );
			String hql = "from CountryDetails where countryId  = '" + cd.getCountryId() +"'";


			CountryDetails countryDetails = (CountryDetails) session.createQuery(hql).uniqueResult();
			
			tx.commit();
			session.flush();
			session.close();
			
			System.out.println(" ========================================= ");
			System.out.println(" getCountrybyId : @BackEnd End Successfully ");
			System.out.println(" ========================================= ");
			return countryDetails;

			
		}

		catch (Exception e) {
			System.out.println(" ========================================= ");
			System.out.println(" getCountrybyId : @BackEnd End With Error ");
			System.out.println(" ========================================= ");
			return null;
		}

		
	}
	

	
	
}
