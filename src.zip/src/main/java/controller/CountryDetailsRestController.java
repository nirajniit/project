package controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.json.simple.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
//import org.springframework.webflow.engine.model.Model;

import dao.CountryDetailsDAO;
import daoimpl.CountryDetailsDAOImpl;
import model.CountryDetails;

@RestController 
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class CountryDetailsRestController {
	
	
	@RequestMapping(value="/allcountrydetails") 
	public ResponseEntity<List> allCountryDetails()
    {  
		try
		{

		System.out.println("  ===============================  ");
		System.out.println("  allCountryDetails RestAPI   ");
		System.out.println("  ===============================  ");
	   	
    	CountryDetailsDAO countryDetailsDAO = new CountryDetailsDAOImpl();
		List <CountryDetails> countryDetails  =  countryDetailsDAO.getallCountries();
				
		Iterator itr = countryDetails.iterator();
		while(itr.hasNext())
		{
			CountryDetails countryDetailsCurrent = (CountryDetails) itr.next();
			System.out.println(countryDetailsCurrent);
			
		}

		return new ResponseEntity <List>(countryDetails,HttpStatus.OK);
			
		}
		catch(Exception e)
		{
			return new ResponseEntity(e,HttpStatus.OK);
		}
    }
	
	
	
	@RequestMapping(value="/getcountrybyid") 
	public ResponseEntity<List> getCountrybyId(@RequestParam("countryId") String countryId)
    {  
	
		try
		{
			System.out.println("  ===============================  ");
			System.out.println("  getCountryById RestAPI   ");
			System.out.println("  ===============================  ");
			
			CountryDetailsDAO countryDetailsDAO = new CountryDetailsDAOImpl();
			CountryDetails countrydetails=new CountryDetails();
			countrydetails.setCountryId(countryId);
			countrydetails  =countryDetailsDAO.getCountrybyId(countrydetails);
			if(null != countrydetails)
			{
				return new ResponseEntity(countrydetails,HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity(countryId +" Not Found",HttpStatus.OK);
			}	
		
		}
		catch(Exception e)
		{
			return new ResponseEntity(e ,HttpStatus.OK);
		}
		
    }
	
	
	@RequestMapping(value="/addcountry")
	public ResponseEntity<List> addCountry(@RequestParam("countryId") String countryId,@RequestParam("countryName") String countryName)
    {  
	
		try
		{
			System.out.println("  ===============================  ");
			System.out.println("  addcountry RestAPI   ");
			System.out.println("  ===============================  ");
			
			CountryDetails countryDetails = new CountryDetails();
			countryDetails.setCountryId(countryId);
			countryDetails.setCountryName(countryName);
			
			CountryDetailsDAO countryDetailsDAO = new CountryDetailsDAOImpl();
			
			
			CountryDetails currentcountryDetails = countryDetailsDAO.getCountrybyId(countryDetails); 
			
			
			if(currentcountryDetails != null)
			{
					JSONObject jj = new JSONObject();
 		  			jj.put("data",currentcountryDetails.getCountryId() + " has already exists.");
 		  			jj.put("data1","no");
 		  			List ll = new ArrayList();
 		  			ll.add(jj);
 	    			return new ResponseEntity<List>(ll,HttpStatus.OK);
			}
			
			   boolean flag =	countryDetailsDAO.addCountry(countryDetails);	
			
			if(flag == true)
			{
			   
					JSONObject jj = new JSONObject();
		  			jj.put("data",countryDetails.getCountryId() + " has stored successfully in the database.");
		  			jj.put("data1","yes");
		  			List ll = new ArrayList();
		  			ll.add(jj);
	    			return new ResponseEntity<List>(ll,HttpStatus.OK);
			}
			else
			{
				JSONObject jj = new JSONObject();
	  			jj.put("data",countryDetails.getCountryId() + " has not stored successfully in the database. Reason [Counry ID and Name must be unique]");
	  			jj.put("data1","no");
	  			List ll = new ArrayList();
	  			ll.add(jj);
    			return new ResponseEntity<List>(ll,HttpStatus.OK);
			}
			
		}
		catch(Exception e)
		{
			JSONObject jj = new JSONObject();
  			jj.put("data","RUN TIME WEEOR "+e.toString() );
  			List ll = new ArrayList();
  			ll.add(jj);
			return new ResponseEntity<List>(ll,HttpStatus.OK);
		}
	
    }
	
	
	@RequestMapping(value="/deletecountrybyid")
	public ResponseEntity<List> deleteCountrybyId(@RequestParam("countryId") String countryId)
    {  
	
		try
		{
			System.out.println("  ===============================  ");
			System.out.println("  deleteCountrybyId RestAPI   ");
			System.out.println("  ===============================  ");
			
			CountryDetails countryDetails = new CountryDetails();
			countryDetails.setCountryId(countryId);
						
			CountryDetailsDAO countryDetailsDAO = new CountryDetailsDAOImpl();
			   
			boolean flag =	countryDetailsDAO.deleteCountrybyId(countryDetails);
			   
			
			if(flag == true)
			{
				JSONObject jj = new JSONObject();
	  			jj.put("data",countryDetails.getCountryId() + " Deleted from the table.");
	  			jj.put("data1","yes");
	  			List ll = new ArrayList();
	  			ll.add(jj);
    			return new ResponseEntity<List>(ll,HttpStatus.OK);
		
			}
			else
			{
				JSONObject jj = new JSONObject();
	  			jj.put("data",countryDetails.getCountryId() + " has not  deleted from the table , MIGHT BE CITY DETAILS DEPEND ON THE COUNTRY.");
	  			jj.put("data1","no");
	  			List ll = new ArrayList();
	  			ll.add(jj);
    			return new ResponseEntity<List>(ll,HttpStatus.OK);
				
			}
			
		}
		catch(Exception e)
		{
			JSONObject jj = new JSONObject();
  			jj.put("data", "Run Time Error  "+e.toString());
  			List ll = new ArrayList();
  			ll.add(jj);
			return new ResponseEntity<List>(ll,HttpStatus.OK);
		}
	
    }
	
	@RequestMapping(value="/updatecountry")
	public ResponseEntity<List> updateCountry(@RequestParam("countryId") String countryId,@RequestParam("countryName") String countryName)
    {  
	
		try
		{
			System.out.println("  ===============================  ");
			System.out.println("  updatecountry RestAPI   ");
			System.out.println("  ===============================  ");
			
			CountryDetails countryDetails = new CountryDetails();
			countryDetails.setCountryId(countryId);
			countryDetails.setCountryName(countryName);
			
			
						
			CountryDetailsDAO countryDetailsDAO = new CountryDetailsDAOImpl();
			boolean flag =	countryDetailsDAO.updateCountry(countryDetails);
			
			   
			
			if(flag == true)
			{
			   
				JSONObject jj = new JSONObject();
	  			jj.put("data",countryDetails.getCountryId() + " has updated successfully in the database.");
	  			jj.put("data1","yes");
	  			List ll = new ArrayList();
	  			ll.add(jj);
    			return new ResponseEntity<List>(ll,HttpStatus.OK);
			}
			else
			{
				JSONObject jj = new JSONObject();
	  			jj.put("data",countryDetails.getCountryId() + " has  not updated in the database. Might be "+countryDetails.getCountryId() + " not available or "+countryDetails.getCountryName() + "all ready assigned to the other city id");
	  			jj.put("data1","no");
	  			List ll = new ArrayList();
	  			ll.add(jj);
    			return new ResponseEntity<List>(ll,HttpStatus.OK);
				
			}
			
		}
		catch(Exception e)
		{
			return new ResponseEntity(e ,HttpStatus.OK);
		}
	
    }

	

	
	@RequestMapping(value="/getcountrybyname")
	public ResponseEntity<List> getCountrybyName(@RequestParam("countryName") String countryName)
    {  
	
		try
		{
			System.out.println("  ===============================  ");
			System.out.println("  getcountrybyname RestAPI   ");
			System.out.println("  ===============================  ");
			CountryDetails countryDetails = new CountryDetails();
			
			countryDetails.setCountryName(countryName);
			
			
						
			CountryDetailsDAO countryDetailsDAO = new CountryDetailsDAOImpl();
			CountryDetails currentcountryDetails =	countryDetailsDAO.getCountrybyName(countryDetails);
			
			   
			
			if(currentcountryDetails != null)
			{
			   
			   return new ResponseEntity( currentcountryDetails , HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity(currentcountryDetails + " Not Found in the Country Table  ",HttpStatus.OK);
				
			}
			
		}
		catch(Exception e)
		{
			return new ResponseEntity(e ,HttpStatus.OK);
		}
	
    }

	
	
	
	
}
