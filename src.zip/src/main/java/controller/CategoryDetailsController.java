package controller;
import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Blob;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.websocket.server.PathParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

import org.hibernate.engine.jdbc.BlobProxy;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import java.util.Base64;

import dao.CategoryDetailsDAO;
import daoimpl.CategoryDetailsDAOImpl;
import model.CategoryDetails;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class CategoryDetailsController {
	
	
	private static final String UPLOAD_DIRECTORY ="/resources";  
	
	@PostMapping("/addCategoryDetails")
	ResponseEntity<List> addCategoryDetails(@RequestParam(value = "catId") String catId,@RequestParam(value = "catName") String catName,@RequestParam (value="catPrice") String catPrice ,@RequestParam(value="catDscription") String catDscription,@RequestParam(value="countryId") String countryId, @RequestParam(value="cityId") String cityId,@RequestParam(value="productID")  String productID,@RequestParam(value = "byteCatImg") MultipartFile byteCatImg,HttpServletRequest servletRequest, HttpSession session)
	{
		CategoryDetailsDAO categoryDetailsDAO = new CategoryDetailsDAOImpl();
    	
    	System.out.println("================================================");
    	System.out.println(" @RestAPI : addCategoryDetails By POST Request ");
    	System.out.println(" Country ID  "+ countryId);
    	System.out.println(" City ID  "+ cityId);
    	
    	System.out.println("================================================");
        try
        {  
           	byte restbyteCatImg[] =  byteCatImg.getBytes();  
        	String catImg = byteCatImg.getOriginalFilename();
        	String catImgArray[] = catImg.split("\\.");
        	
        	
        	double localcatPrice = Double.parseDouble(catPrice);
        	
       /*
        	for(String str :  catImgArray)
        	{
        		 System.out.println(" File Name PArt " + str);
        	}
        */	
        	
        	
        	
        	List <CategoryDetails> allcategoryDetails =categoryDetailsDAO.getAllCategoryForImage();
        	
        	Iterator item = allcategoryDetails.iterator();
        	Long currentcatId=0L;
        	while(item.hasNext())
        	{
        		CategoryDetails ccc = (CategoryDetails) item.next(); 
        		currentcatId = ccc.getCatId();
        	}
        	
        	
        	catImg=catImgArray[0]+currentcatId+"."+catImgArray[1]; 
            	
        	
    		
        	CategoryDetails categoryDetails = new CategoryDetails();
        	
        	Long LongCatId = Long.parseLong(catId);
        	
        	categoryDetails.setCatId(LongCatId);
        	categoryDetails.setCatName(catName);
        	categoryDetails.setCatImg(catImg);
        	categoryDetails.setCatPrice(localcatPrice);
        	categoryDetails.setCatDscription(catDscription);
        	
        	
        	Long LongProductID = Long.parseLong(productID);
        	categoryDetails.setProductID(LongProductID);
        	categoryDetails.setCountryID(countryId);
        	categoryDetails.setCityID(cityId);
        	
        	
          	// categoryDetails.setByteCatImg(BlobProxy.generateProxy(restbyteCatImg));
        	//categoryDetails.setByteCatImg(BlobProxy.generateProxy(restbyteCatImg));
          	// categoryDetails.setProductID("3");
        	
        	try
        	{
        		
        		String path="D:/thegulfroad27_03_2019/Newmydemo1/Newmydemo/src/assets/images/";
        		
        		
        		//String path="D:/thegulfroad27_03_2019/THE-GULF-ROAD/thegulgrestapi/src/main/resources/images/";
        		// String path=session.getServletContext().getRealPath("/thegulgrestapi/src/main/webapp/resources/uploadfiles");
        		       		
    	          
    	        System.out.println("==========================="); 
    	        System.out.println("==========================="); 
    	        
    	        String fillpath=path+""+catImg;
    	        System.out.println("File Path "+ fillpath);
    	        System.out.println("==========================="); 
    	        System.out.println("==========================="); 
    	        
    	        
    	          
    	        byte barr[]=byteCatImg.getBytes();  
    	        BufferedOutputStream bout=new BufferedOutputStream(  
    	                new FileOutputStream(fillpath));  
    	        bout.write(restbyteCatImg);  
    	        bout.flush();  
    	        bout.close();
    	        //categoryDetails.setCatImg(catImg);
    	        //categoryDetails.setCatImg(catImg);
        		
        	}
        	catch(Exception e)
        	{
        		
        		System.out.println("==========================="); 
    	        System.out.println("==========================="); 
    	        System.out.println("Run time Error "+ e);
    	        System.out.println("==========================="); 
    	        System.out.println("===========================");
    	        JSONObject jj = new JSONObject();
      			jj.put("data","nsuccess");
      			jj.put("data1",e.toString());
      			List ll = new ArrayList();
      			ll.add(jj);
    			return new ResponseEntity<List>(ll,HttpStatus.INTERNAL_SERVER_ERROR);
        		 
        		
        	}
        	
          	boolean falg = categoryDetailsDAO.addCategory(categoryDetails);
           	
           	if(true == falg)
        	{
           		
           		
           		JSONObject jj = new JSONObject();
	  			jj.put("data","success");
	  			jj.put("data1","Data added successfully in the database");
	  			List ll = new ArrayList();
	  			ll.add(jj);
    			return new ResponseEntity<List>(ll,HttpStatus.OK);
           		
                
        	}
        	else
        	{
        		JSONObject jj = new JSONObject();
	  			jj.put("data","nsuccess");
	  			jj.put("data1","Data not added in the database");
	  			List ll = new ArrayList();
	  			ll.add(jj);
    			return new ResponseEntity<List>(ll,HttpStatus.OK);
        	}
        }
        catch(Exception e2)
        {
        	JSONObject jj = new JSONObject();
  			jj.put("data","nsuccess");
  			jj.put("data1",e2.toString());
  			List ll = new ArrayList();
  			ll.add(jj);
			return new ResponseEntity<List>(ll,HttpStatus.INTERNAL_SERVER_ERROR);
        	
        }
	}
	
	
	
	
	@RequestMapping("/getallcategory")
	ResponseEntity <List>  getAllCategory()
	{
		
		System.out.println("==================================   ");
		System.out.println("     GET or POST ");      
		System.out.println("==================================   ");
		try
		{
			CategoryDetailsDAO categoryDetailsDAO = new CategoryDetailsDAOImpl();
			List <CategoryDetails> categoryDetails =categoryDetailsDAO.getAllCategory(); 
			
			System.out.println("Done");
			System.out.println(categoryDetails);
			
			if(null != categoryDetails)
			{
				
				System.out.println("inside if");
				
				
				 List ll = new ArrayList();
				
				for(CategoryDetails c : categoryDetails)
				{
					
					try
					{
					
						System.out.println("===================");
						//System.out.println(c.getByteCatImg());
						JSONObject jj = new JSONObject();
						//Object blob =  c.getByteCatImg().getClass();  
						//String str = blob.toString();
					  System.out.println("-------------"+c.getCatId());

					  jj.put("catId", c.getCatId());
					  jj.put("catName", c.getCatName());
					  jj.put("catDscription", c.getCatDscription());
					  jj.put("catPrice", c.getCatPrice());
					  //jj.put("byteCatImg",str.getBytes());
					  jj.put("catImg",c.getCatImg());
					  jj.put("productID", c.getProductID());
					  jj.put("rrating",c.getRrating());
					  jj.put("approved",c.getApproved());
					  jj.put("countryID",c.getCountryID());
					  jj.put("cityID", c.getCityID());
					  
					  
					  
					  ll.add(jj);
					}
					catch(Exception e)
					{
						
						
					}
				}
				
				System.out.println(" ====================================== " );
				System.out.println(" IN IF  " );
				System.out.println(" ====================================== " );
				
				return new ResponseEntity <List>( ll,HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity <List>(categoryDetails ,HttpStatus.OK);
			}
		
		}
		catch(Exception e)
		{
			return new ResponseEntity( e + " Run TError  ",HttpStatus.OK);
		}
	}
	
	
	@RequestMapping("/deleteCategory")
	ResponseEntity <List> deleteCategoryRest (@RequestParam(value = "catId") String catId)
	{
		
		System.out.println("================================");
		System.out.println("======deleteCategory : RestApi =");
		System.out.println("======catID  = " + catId);
		System.out.println("================================");
		
			
			CategoryDetailsDAO categoryDetailsDAO = new CategoryDetailsDAOImpl();
			CategoryDetails categoryDetails = new CategoryDetails();
			Long LongCatId = Long.parseLong(catId);
			categoryDetails.setCatId(LongCatId);
			
			boolean flag = categoryDetailsDAO.deleteCategory(categoryDetails);
			if(flag == true)
			{
				List ll = new ArrayList();
				JSONObject jj = new JSONObject();
				jj.put("data","succes");
				ll.add(jj);
				return new ResponseEntity <List>( ll,HttpStatus.OK);
			}
			else
			{
				List ll = new ArrayList();
				JSONObject jj = new JSONObject();
				jj.put("data","nsucces");
				jj.put("data1","data not deleted might be data is not available in the database ");
				ll.add(jj);
				return new ResponseEntity <List>( ll,HttpStatus.OK);
			}
	}
	
	
	@PostMapping("/updateCategoryDetails")
	//ResponseEntity <List> updateCategoryDetails( @RequestParam(value = "catId") String catId , @RequestParam(value = "catName") String catName , @RequestParam (value="catPrice") String catPrice , @RequestParam(value="catDscription") String catDscription , @RequestParam(value="productID")  String productID , @RequestParam(value="rrating")  String rrating,@RequestParam(value="approved")  String approved,@RequestParam(value = "byteCatImg") MultipartFile byteCatImg , HttpServletRequest servletRequest ,  HttpSession session)
	ResponseEntity <List> updateCategoryDetails( @RequestParam(value = "catId") String catId , @RequestParam(value = "catName") String catName , @RequestParam (value="catPrice") String catPrice , @RequestParam(value="catDscription") String catDscription , @RequestParam(value="productID")  String productID , @RequestParam(value="rrating")  String rrating,@RequestParam(value="approved")  String approved , @RequestParam(value="countryId")  String countryId,@RequestParam(value="cityId")  String cityId,@RequestParam(value = "byteCatImg") MultipartFile byteCatImg, HttpServletRequest servletRequest ,  HttpSession session)
	{
   		
    	System.out.println("================================================");
    	System.out.println(" @RestAPI : updateCategoryDetails By POST Request ");
    	
    	try
    	{
    		
    		byte restbyteCatImg[] =  byteCatImg.getBytes();  
			String catImg = byteCatImg.getOriginalFilename();
    	    String catImgArray[] = catImg.split("\\.");
    	    String catImage = catImgArray[0]+catId+"."+catImgArray[1];
    	    System.out.println("cat image name "+ catImage);
    	    
    	    CategoryDetailsDAO categoryDetailsDAO = new CategoryDetailsDAOImpl();
    		CategoryDetails categoryDetails = new CategoryDetails();
    		categoryDetails.setCatId(Long.parseLong(catId));
    		
    		CategoryDetails curentcategory = categoryDetailsDAO.getCategoryById(categoryDetails);
    		

    		System.out.println("================================================");
    		System.out.println("CAT ID "+ catId);
    		System.out.println("catName "+ catName);
    		System.out.println("catPrice "+ catPrice);
    		System.out.println("catDscription "+ catDscription);
    		System.out.println("productID "+ productID);
    		System.out.println("Rating "+ rrating);
    		System.out.println("Approved "+ approved);
    		System.out.println("byteCatImg "+ byteCatImg);
    		System.out.println("countryId "+ countryId);
    		System.out.println("cityId" + countryId);
    		System.out.println("==================================================");
 		
    		curentcategory.setCatId(Long.parseLong(catId));
    		curentcategory.setCatName(catName);
    		curentcategory.setCatImg(catImage);
    		curentcategory.setCatPrice(Double.parseDouble(catPrice));
    		curentcategory.setCatDscription(catDscription);
    		curentcategory.setProductID(Long.parseLong(productID));
    		curentcategory.setRrating(rrating);
    		curentcategory.setApproved(approved);
    		curentcategory.setCountryID(countryId);
    		curentcategory.setCityID(cityId);
    		
    		try
        	{
        		
        		String path="D:/thegulfroad27_03_2019/Newmydemo1/Newmydemo/src/assets/images/";
        		//String path="D:/thegulfroad27_03_2019/THE-GULF-ROAD/thegulgrestapi/src/main/resources/images/";
        		// String path=session.getServletContext().getRealPath("/thegulgrestapi/src/main/webapp/resources/uploadfiles");
        		  		
       	    
        	    System.out.println("==========================="); 
    	        System.out.println("==========================="); 
    	        String fillpath=path+""+catImage;
    	        System.out.println("File Path "+ fillpath);
    	        System.out.println("==========================="); 
    	        System.out.println("==========================="); 
    	         	        
    	          
    	        byte barr[]=byteCatImg.getBytes();  
    	        BufferedOutputStream bout=new BufferedOutputStream(  
    	                new FileOutputStream(fillpath));  
    	        bout.write(restbyteCatImg);  
    	        bout.flush();  
    	        bout.close();
    	    
        		
        	}
        	catch(Exception e)
        	{
        		
        		
    	
    	        JSONObject jj = new JSONObject();
      			jj.put("data","nsuccess");
      			jj.put("data1",e.toString());
      			List ll = new ArrayList();
      			ll.add(jj);
    			return new ResponseEntity<List>(ll,HttpStatus.INTERNAL_SERVER_ERROR);
        	}
           	boolean falg = categoryDetailsDAO.updateCategory(curentcategory);
          	if(true == falg)
        	{
           	          		
           		JSONObject jj = new JSONObject();
	  			jj.put("data","success");
	  			jj.put("data1","Data updated successfully in the database");
	  			List ll = new ArrayList();
	  			ll.add(jj);
    			return new ResponseEntity<List>(ll,HttpStatus.OK);
                
        	}
        	else
        	{
        		JSONObject jj = new JSONObject();
	  			jj.put("data","nsuccess");
	  			jj.put("data1","Data not updated in the database");
	  			List ll = new ArrayList();
	  			ll.add(jj);
    			return new ResponseEntity<List>(ll,HttpStatus.OK);
        	}
    		 
    	    
    	}
    	catch(Exception e)
    	{
    		
    		System.out.println(" Error "+ e);
    		
    	}
    	   	
    	
		System.out.println("================================================");
		System.out.println("CAT ID "+ catId);
		System.out.println("catName "+ catName);
		System.out.println("catPrice "+ catPrice);
		System.out.println("catDscription "+ catDscription);
		System.out.println("productID "+ productID);
		System.out.println("Rating "+ rrating);
		System.out.println("Approved "+ approved);
		System.out.println("byteCatImg "+ byteCatImg);
		System.out.println("countryId "+ countryId);
		System.out.println("cityId" + countryId);
		System.out.println("==================================================");

	
           	
         
            CategoryDetailsDAO categoryDetailsDAO = new CategoryDetailsDAOImpl();
    		CategoryDetails categoryDetails = new CategoryDetails();
        	Long LongCatId = Long.parseLong(catId);
        	categoryDetails.setCatId(LongCatId);
        	  	
        	
        	
        	try
        	{
        		
        		boolean flag = false;
        		
        		Long LongCatId1 = Long.parseLong(catId);
        		categoryDetails.setCatId(LongCatId1);
        		CategoryDetails curentcategory = categoryDetailsDAO.getCategoryById(categoryDetails);
        		
        		
        		curentcategory.setCatId(Long.parseLong(catId));
        		curentcategory.setCatName(catName);
        		
        		curentcategory.setCatPrice(Double.parseDouble(catPrice));
        		curentcategory.setCatDscription(catDscription);
        		curentcategory.setProductID(Long.parseLong(productID));
        		curentcategory.setRrating(rrating);
        		curentcategory.setApproved(approved);
        		curentcategory.setCountryID(countryId);
        		curentcategory.setCityID(cityId);
        		        		
        		flag = categoryDetailsDAO.updateCategory(curentcategory);
        		
        		if(true == flag)
            	{
               	          		
               		JSONObject jj = new JSONObject();
    	  			jj.put("data","success");
    	  			jj.put("data1","Data updated successfully in the database");
    	  			List ll = new ArrayList();
    	  			ll.add(jj);
        			return new ResponseEntity<List>(ll,HttpStatus.OK);
                    
            	}
            	else
            	{
            		
            		JSONObject jj = new JSONObject();
    	  			jj.put("data","nsuccess");
    	  			jj.put("data1","Data not updated in the database");
    	  			List ll = new ArrayList();
    	  			ll.add(jj);
        			return new ResponseEntity<List>(ll,HttpStatus.OK);
            	}
        	
           	
        }
        catch(Exception e2)
        {
        	
        	JSONObject jj = new JSONObject();
  			jj.put("data","nsuccess");
  			jj.put("data1",e2.toString());
  			List ll = new ArrayList();
  			ll.add(jj);
			return new ResponseEntity<List>(ll,HttpStatus.OK);
        }
    	
    	
	}
	
	
	@RequestMapping("/getproductbyapproved")
	ResponseEntity<List> getProductByapproved(@RequestParam (value="approved") String approved)
	{	try
		{
			CategoryDetailsDAO categoryDetailsDAO = new CategoryDetailsDAOImpl(); 
			CategoryDetails cat = new CategoryDetails();
			
			cat.setApproved(approved);
			List <CategoryDetails> categoryDetails = categoryDetailsDAO.getCategoryProcutApproved(cat);
			
			if(categoryDetails != null)
			{
						return new ResponseEntity(categoryDetails,HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity("data not found",HttpStatus.OK);
			}	
		}
		catch(Exception eee)
		{
			return new ResponseEntity("data not found",HttpStatus.INTERNAL_SERVER_ERROR);
			
		}
	}
	
	
	@RequestMapping("/getproductbyCountryId")
	ResponseEntity<List> getProductbyCountryId(@RequestParam (value="countryId") String countryId)
	{	try
		{
			CategoryDetailsDAO categoryDetailsDAO = new CategoryDetailsDAOImpl(); 
			CategoryDetails cat = new CategoryDetails();
			
			cat.setCountryID(countryId);
			List <CategoryDetails> categoryDetails = categoryDetailsDAO.getCategoryProcutCountryId(cat);
			
			if(categoryDetails != null)
			{
						return new ResponseEntity(categoryDetails,HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity("data not found",HttpStatus.OK);
			}	
		}
		catch(Exception eee)
		{
			return new ResponseEntity("data not found",HttpStatus.INTERNAL_SERVER_ERROR);
			
		}
	}
	
	
	
	
	@RequestMapping("/getproductbyapprovedandcountryid")
	ResponseEntity<List> getProductbyApprovedandcountryid(@RequestParam (value="approved") String approved,@RequestParam (value="countryId") String countryId)
	{	try
		{
			CategoryDetailsDAO categoryDetailsDAO = new CategoryDetailsDAOImpl(); 
			CategoryDetails cat = new CategoryDetails();
			
			cat.setApproved(approved);
			cat.setCountryID(countryId);
			
			List <CategoryDetails> categoryDetails = categoryDetailsDAO.getCategoryProcutApprovedandCountryID(cat);
			
			if(categoryDetails != null)
			{
						return new ResponseEntity(categoryDetails,HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity("data not found",HttpStatus.OK);
			}	
		}
		catch(Exception eee)
		{
			return new ResponseEntity("data not found",HttpStatus.INTERNAL_SERVER_ERROR);
			
		}
	}
	
	
	
	
	
	
	
	
	@RequestMapping("/getcategorybyprice")
	ResponseEntity<List> getCategoryByPriceRest(@RequestParam (value="catPrice") String catPrice)
	{	try
		{
			CategoryDetailsDAO categoryDetailsDAO = new CategoryDetailsDAOImpl(); 
			CategoryDetails cat = new CategoryDetails();
			double catp = Double.parseDouble(catPrice);
			cat.setCatPrice(catp);
			List <CategoryDetails> categoryDetails = categoryDetailsDAO.getCategoryByPrice(cat);   
			if(categoryDetails != null)
			{
						return new ResponseEntity(categoryDetails,HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity("data not found",HttpStatus.OK);
			}	
		}
		catch(Exception eee)
		{
			return new ResponseEntity("data not found",HttpStatus.INTERNAL_SERVER_ERROR);
			
		}
	}
	
	
	@RequestMapping("/getCategoryByName")ResponseEntity<List>
	getCategoryByNameRest(@RequestParam (value="catName") String catName)
	{	try
		{
			CategoryDetailsDAO categoryDetailsDAO = new CategoryDetailsDAOImpl(); 
			CategoryDetails cat = new CategoryDetails();
			cat.setCatName(catName);
			List <CategoryDetails> categoryDetails = categoryDetailsDAO.getCategoryByName(cat);
			
			if(categoryDetails != null)
			{
						return new ResponseEntity(categoryDetails,HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity("data not found",HttpStatus.OK);
			}	
		}
		catch(Exception eee)
		{
			return new ResponseEntity("data not found",HttpStatus.INTERNAL_SERVER_ERROR);
			
		}
	}
	
	@PostMapping("/getCategoryById")
	ResponseEntity<List> getCategoryByIdRest(@RequestParam (value="catId") String catId)
	{	try
		{
			CategoryDetailsDAO categoryDetailsDAO = new CategoryDetailsDAOImpl(); 
			CategoryDetails cat = new CategoryDetails();
			
			Long LongCatId = Long.parseLong(catId);
			
			cat.setCatId(LongCatId);
		    CategoryDetails categoryDetails  =  categoryDetailsDAO.getCategoryById(cat);
			
			if(categoryDetails != null)
			{
						return new ResponseEntity(categoryDetails,HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity("data not found",HttpStatus.OK);
			}	
		}
		catch(Exception eee)
		{
			return new ResponseEntity("data not found",HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@PostMapping("/getCategoryProcutById")
	ResponseEntity<List> getCategoryProcutByIdRest(@RequestParam (value="productID") String productID)
	{	try
		{
			CategoryDetailsDAO categoryDetailsDAO = new CategoryDetailsDAOImpl(); 
			CategoryDetails cat = new CategoryDetails();
			Long LongProductID = Long.getLong(productID);
			cat.setProductID(LongProductID);
		    List <CategoryDetails> categoryDetails  =  categoryDetailsDAO.getCategoryProcutById(cat);
			if(categoryDetails != null)
			{
						return new ResponseEntity(categoryDetails,HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity("data not found",HttpStatus.OK);
			}	
		}
		catch(Exception eee)
		{
			return new ResponseEntity("data not found",HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	
	
	
	
	
	
	

}
