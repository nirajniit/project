package controller;

import dao.EmailSenderDAO;
import daoimpl.EmailSenderDAOImpl;
import model.EmailSender;

public class Mailer {
	
	public boolean sendMail(String userEmail,String  userName,String userMobile )
	{
		
	

		
		EmailSender mailer = new EmailSender();
		
		
		String code="\r\n" + 
				"<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>\r\n" + 
				"<html xmlns='http://www.w3.org/1999/xhtml'>\r\n" + 
				"<head>\r\n" + 
				"<meta name='viewport' content='width=device-width, initial-scale=1.0' />\r\n" + 
				"<meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />\r\n" + 
				"<title>Gulf Road</title>\r\n" + 
				"<link href='https://fonts.googleapis.com/css?family=lato' rel='stylesheet' />\r\n" + 
				"<style type='text/css'>\r\n" + 
				"body {\r\n" + 
				"	font-family: 'Arial';\r\n" + 
				"	font-size: 17px;\r\n" + 
				"}\r\n" + 
				".centered {\r\n" + 
				"    position: absolute;\r\n" + 
				"    top: 110px;\r\n" + 
				"    left: 42%;\r\n" + 
				"    color: #fff;\r\n" + 
				"    font-family:'futura Std Book',sans-serif;\r\n" + 
				"    font-size:30px;\r\n" + 
				"    font-weight:normal;\r\n" + 
				"}\r\n" + 
				".cwh {\r\n" + 
				"    text-align: center;\r\n" +				
				"    color: #fff !important;\r\n" + 
				"    font-family:'futura Std Book',sans-serif;\r\n" + 
				"    font-size:30px;\r\n" + 
				"    font-weight:normal;\r\n" + 
				"}\r\n" + 
				
				"@media only screen and (max-width: 600px) {\r\n" + 
				".wrapper_600 {\r\n" + 
				"	width: 100%;\r\n" + 
				"	padding: 0px!important;\r\n" + 
				"}\r\n" + 
				"\r\n" + 
				"}\r\n" + 
				"</style>\r\n" + 
				"</head>\r\n" + 
				"\r\n" + 
				"<body style='margin:0; padding:0'>\r\n" + 
				"<div style='margin:0px auto'>\r\n" + 
				"  <table width='100%' cellspacing='0' cellpadding='0' border='0'>\r\n" + 
				"	<tr>\r\n" + 
				"	  <td align='center'>\r\n" + 
				"		 <table class='wrapper_600' cellspacing='0' cellpadding='0' border='0' bgcolor='#ffffff'>\r\n" + 
				"		  <tr>\r\n" + 
				"			<td align='center' >\r\n" + 
				"			<table class='body_content' style='max-width:600px;' width='100%' cellspacing='0' cellpadding='0' border='0' bgcolor='#FFFFFF'>\r\n" + 
				"				<tr>\r\n" + 
				"					<td align='center' valign='bottom' style='line-height:0px;'>\r\n" +
				"							<img src='http://www.thegulfroad.com/assets/images/emailer/mt1.jpg' alt='banner image' title='banner' border='0' style='max-width:600px;'/>\r\n" + 
				"							\r\n" + 
				"					</td>\r\n" + 
				"				</tr>\r\n" + 


"				<tr>\r\n" + 
"					<td align='center' valign='bottom' style='line-height:0px;background: #ff6b6b !important;'>\r\n" + 
"							<h2 class='cwh' style='color:#fff !important;text-transform:capitalize !important;'>Dear "+userName+"</h2>\r\n" +
"							\r\n" +  
"					</td>\r\n" + 
"				</tr>\r\n" + 

"				<tr>\r\n" + 
"					<td align='center' valign='bottom' style='line-height:0px;'>\r\n" + 
"						<a href='#' target='_blank'>\r\n" +  
"							<img src='http://www.thegulfroad.com/assets/images/emailer/mt2.jpg' alt='banner image' title='banner' border='0' style='max-width:600px;'/>\r\n" + 
"							\r\n" + 
"						</a>\r\n" + 
"					</td>\r\n" + 
"				</tr>\r\n" + 



				"		    	<tr>\r\n" + 
				"				    <td style='padding:10px 20px 0px 20px;background-color:#ffffff;' align='left'>\r\n" + 
				"						<p style='font-family:'Arial',sans-serif;font-size:22px;font-weight:normal;color:#464646;'>Welcome to The Gulf Road, the Middle East�s fastest growing platform for finding home for rent, furniture and cars and many more.</p>\r\n" + 
				"					</td>\r\n" + 
				"				</tr>  \r\n" + 
				"				<tr>\r\n" + 
				"				    <td style='padding:0px 20px 10px 20px;background-color:#ffffff;' align='left'>\r\n" + 
				"						<p style='font-family:'Arial',sans-serif;font-size:13px;font-weight:normal;color:#464646;'>You are lucky one to get on board before the prelaunch of the platform. We are happy to get partnered with you and will ensure that you get the exclusive deals which will make you stand out from the list of other customers.</p>\r\n" + 
				"					</td>\r\n" + 
				"				</tr>\r\n" + 
				"				<tr>\r\n" + 
				"				    <td style='padding:0px 20px 10px 20px;background-color:#ffffff;' align='left'>\r\n" + 
				"						<img src='http://www.thegulfroad.com/assets/images/emailer/mail.png'>&nbsp;&nbsp; <strong>Email Address: </strong>  "+userEmail+"\r\n" + 
				"					</td>\r\n" + 
				"				</tr>\r\n" + 
				"				<tr>\r\n" + 
				"				    <td style='padding:0px 20px 10px 20px;background-color:#ffffff;' align='left'>\r\n" + 
				"						<img src='http://www.thegulfroad.com/assets/images/emailer/phone.png'>&nbsp;&nbsp; <strong>Phone Number: </strong>"+userMobile+"\r\n" + 
				"					</td>\r\n" + 
				"				</tr>\r\n" + 
				"                <tr>\r\n" + 
				"				    <td style='padding:0px 20px 10px 20px;background-color:#ffffff;' align='left'>\r\n" + 
				"						<p style='font-family:'Arial',sans-serif;font-size:13px;font-weight:normal;color:#464646;'>All your correspondence will be through the above email address and phone number.</p>\r\n" + 
				"					</td>\r\n" + 
				"				</tr>	\r\n" + 
				"                <tr>\r\n" + 
				"				    <td style='padding:0px 20px 10px 20px;background-color:#ffffff;' align='left'>\r\n" + 
				"						<p style='font-family:'Arial',sans-serif;font-size:13px;font-weight:600;color:#464646;'>Please write back to us for anything desired.</p>\r\n" + 
				"					</td>\r\n" + 
				"				</tr>\r\n" + 
				"                <tr style='background-color:#f3f3f3;'>\r\n" + 
				"				    <td style='padding:0px 20px 10px 20px;' align='left'>\r\n" + 
				"					    <h3 style='color:#000000;'>ABOUT US</h3>\r\n" + 
				"						<p style='font-family:'Arial',sans-serif;font-size:13px;font-weight:normal;color:#464646;'>The Gulf Road is the leading classifieds and booking website for users in the Gulf Region. Taking care, the needs of everyone for everything.</p>\r\n" + 
				"					</td>\r\n" + 
				"				</tr>\r\n" + 
				"               \r\n" + 
				"                <table style='max-width:600px;' width='100%' cellspacing='0' cellpadding='0' border='0' bgcolor='#FFFFFF'>\r\n" + 
				"				<tr>\r\n" + 
				"                     <td style='padding:0px 0px 10px 20px;background-color:#ffffff;' align='left'>\r\n" + 
				" 					    <p style='font-family:'Arial';font-size:22px;color:#4d4644;'>Regards,<br/>The Gulf Road Team</p>\r\n" + 
				"					 </td>\r\n" + 
				"					 <td style='padding:0px 0px 10px 0px;background-color:#ffffff;' align='right'>\r\n" + 
				"						<a href='http://www.thegulfroad.com' target='_blank'>\r\n" + 
				"							<img src='http://www.thegulfroad.com/assets/images/emailer/booknow.png' alt='book image' title='book' border='0'/>\r\n" + 
				"						</a>\r\n" + 
				"					 </td>\r\n" + 
				"                </tr>				\r\n" + 
				"			    </table>\r\n" + 
				"				<tr>\r\n" + 
				"					<td align='center' valign='bottom' style='line-height:0px;'>\r\n" + 
				"						<a href='#' target='_blank'>\r\n" + 
				"							<img src='http://www.thegulfroad.com/assets/images/emailer/footer.png' alt='footer image' title='footer' border='0' style='max-width:600px;'/>\r\n" + 
				"						</a>\r\n" + 
				"					</td>\r\n" + 
				"				</tr>\r\n" + 
				"             </table>\r\n" + 
				"		    </td>\r\n" + 
				"		  </tr>\r\n" + 
				"		 </table>\r\n" + 
				"		  \r\n" + 
				"	   </td>\r\n" + 
				"	</tr>\r\n" + 
				"  </table>\r\n" + 
				"</div>\r\n" + 
				"</body>\r\n" + 
				"</html>";		
		
		
		
		
		
		
		//mailer.setEmailSender("krishnachaturvedi93@gmail.com");
		//mailer.setEmailSenderPassword("zagoghnoebkgxkyx");
		
		
		mailer.setEmailSender("care@thegulfroad.com");
		mailer.setEmailSenderPassword("kczqzijhdaqvjrxt");
		
		
		//mailer.setEmailSenderPassword("1@Omsairam");
		
		// mailer.setEmailSender("info@thegulfroad.com");
		// mailer.setEmailSenderPassword("Perfect@123");
		
		
		
		mailer.setEmailReceiver(userEmail);
		mailer.setEmailSubject("Account Signup  ");
		mailer.setEmailMessage(code);
		

		EmailSenderDAO emailSenderDAO = new EmailSenderDAOImpl();
		boolean ff = emailSenderDAO.sendEmail(mailer);
		
		
		
		if(ff==true)
		{
			return true;
			
		}
		else
		{
			return false;
			
		}
				
		
		
		
		
	}
	
}
