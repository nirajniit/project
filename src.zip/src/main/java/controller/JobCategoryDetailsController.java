package controller;

import org.springframework.web.bind.annotation.RestController;

import dao.JobCategoryDetailsDAO;
import daoimpl.JobCategoryDetailsDAOImpl;
import model.JobCategoryDetails;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.http.ResponseEntity;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.http.HttpStatus;




@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class JobCategoryDetailsController {
	
	@RequestMapping("/saveJobCategoryDetails")
	public ResponseEntity saveJobCategoryDetailsRest(@RequestParam(value="jobCategoryId") String jobCategoryId,@RequestParam(value="jobCategoryType") String jobCategoryType,@RequestParam(value="salary") String salary,@RequestParam(value="jobTitle") String jobTitle, @RequestParam(value="description") String description, @RequestParam(value="qualification") String qualification,@RequestParam(value="status") String status,@RequestParam(value="jobTypeId") String jobTypeId)
	{
	
		try
		{
		
			JobCategoryDetailsDAO jobDetailsDAO=new JobCategoryDetailsDAOImpl();
			JobCategoryDetails jobDetails=new JobCategoryDetails();
			jobDetails.setJobCategoryId(jobCategoryId);
			jobDetails.setJobCategoryType(jobCategoryType);
			jobDetails.setJobTitle(jobTitle);
			jobDetails.setSalary(salary);
			jobDetails.setDescription(description);
			Date d = new Date();
			jobDetails.setDateTime(d.toString());
			jobDetails.setStatus(status);;
			jobDetails.setQualification(qualification);
			jobDetails.setJobTypeId(jobTypeId);
			boolean flag=jobDetailsDAO.saveJobCategoryDetails(jobDetails);
	
		
			if(flag == true)
			{
	    
		
	    	return  new ResponseEntity(jobDetails + " added successfully in the database ",HttpStatus.OK) ;
			}
			else
			{
	    	
				return  new ResponseEntity(jobDetails + " added not  successfully in the database ",HttpStatus.OK) ;
			}
		}
		catch(Exception e)
		{
			return  new ResponseEntity(e + " added not  successfully in the database ",HttpStatus.OK) ;
			
		}
	}
	
	

	@RequestMapping("/getAllJobCategoryDetails")
	public ResponseEntity getAllJobCategoryDetailsRest()
	{
		try
		{
			JobCategoryDetailsDAO jobDetailsDAO = new JobCategoryDetailsDAOImpl();
			List<JobCategoryDetails>  allJobCategoryDetails =jobDetailsDAO.getAllJobDetails();
			if(allJobCategoryDetails != null)
			{
				return new ResponseEntity (allJobCategoryDetails,HttpStatus.OK);
				
			}
			else
			{
				return new ResponseEntity ("data not found ",HttpStatus.OK);
			}
		}
		catch(Exception e)
		{
			
			return new ResponseEntity(e,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}

	
	
	
	@RequestMapping("/updateJobCategoryDetails")
	public ResponseEntity updateJobCategoryDetailsRest(@RequestParam(value="jobCategoryId") String jobCategoryId,@RequestParam(value="jobCategoryType") String jobCategoryType,@RequestParam(value="salary") String salary,@RequestParam(value="jobTitle") String jobTitle, @RequestParam(value="description") String description, @RequestParam(value="qualification") String qualification,@RequestParam(value="status") String status,@RequestParam(value="jobTypeId") String jobTypeId)
	{
	
		try
		{
		
			JobCategoryDetailsDAO jobDetailsDAO=new JobCategoryDetailsDAOImpl();
			JobCategoryDetails jobDetails=new JobCategoryDetails();
			jobDetails.setJobCategoryId(jobCategoryId);
			jobDetails.setJobCategoryType(jobCategoryType);
			jobDetails.setJobTitle(jobTitle);
			jobDetails.setSalary(salary);
			jobDetails.setDescription(description);
			Date d = new Date();
			jobDetails.setDateTime(d.toString());
			jobDetails.setStatus(status);
			jobDetails.setQualification(qualification);
			jobDetails.setJobTypeId(jobTypeId);
			boolean flag = jobDetailsDAO.updateJobCategoryDetails(jobDetails);
	
		
			if(flag == true)
			{
	    
		
	    	return  new ResponseEntity(jobDetails + " updated successfully in the database ",HttpStatus.OK) ;
			}
			else
			{
	    	
				return  new ResponseEntity(jobDetails + " updated not  successfully in the database ",HttpStatus.OK) ;
			}
		}
		catch(Exception e)
		{
			return  new ResponseEntity(e + " updated not  successfully in the database ",HttpStatus.OK) ;
			
		}
	}


	@RequestMapping("/deleteJobCategoryDetails")
	public ResponseEntity deleteJobCategoryDetailsRest(@RequestParam(value="jobCategoryId") String jobCategoryId)
	{
		try
		{
			JobCategoryDetailsDAO jobDetailsDAO=new JobCategoryDetailsDAOImpl();
			JobCategoryDetails jobDetails=new JobCategoryDetails();
			jobDetails.setJobCategoryId(jobCategoryId);
			boolean flag = jobDetailsDAO.deleteJobCategoryDetails(jobDetails);
			if(flag == true)
			{
	    	    return  new ResponseEntity(jobDetails + "  deleted successfully in the database ",HttpStatus.OK) ;
			}
			else
			{
	    	    return  new ResponseEntity(jobDetails + "  not deleted  successfully in the database ",HttpStatus.OK) ;
			}
		}
		catch(Exception e)
		{
			return  new ResponseEntity(e + " deleted not  successfully in the database ",HttpStatus.OK) ;
			
		}
	}

	
	
	
	
	@RequestMapping("/getJobCategoryByID")
	public ResponseEntity getJobCategoryByIDRest(@RequestParam(value="jobCategoryId") String jobCategoryId)
	{
		try
		{
			JobCategoryDetailsDAO jobDetailsDAO=new JobCategoryDetailsDAOImpl();
			JobCategoryDetails jobDetails=new JobCategoryDetails();
			jobDetails.setJobCategoryId(jobCategoryId);
			jobDetails = jobDetailsDAO.getJobByID(jobDetails);
			
			if(jobDetails != null)
			{
	    	    return  new ResponseEntity(jobDetails,HttpStatus.OK) ;
			}
			else
			{
	    	    return  new ResponseEntity(jobDetails + "  not found in the database ",HttpStatus.OK) ;
			}
		}
		catch(Exception e)
		{
			return  new ResponseEntity(e + " data not found in the database ",HttpStatus.OK) ;
			
			
		}
	}
	
	
	
	@RequestMapping("/getJobCategoryByTitle")
	public ResponseEntity getJobCategoryByTitleRest(@RequestParam(value="jobTitle") String jobTitle)
	{
		try
		{
			JobCategoryDetailsDAO jobDetailsDAO=new JobCategoryDetailsDAOImpl();
			JobCategoryDetails jobDetails=new JobCategoryDetails();
			jobDetails.setJobTitle(jobTitle);
			List <JobCategoryDetails>  jobTitleDetails  = jobDetailsDAO.getJobByTitle(jobDetails);
			
			if(jobTitleDetails != null)
			{
	    	    return  new ResponseEntity(jobTitleDetails,HttpStatus.OK) ;
			}
			else
			{
	    	    return  new ResponseEntity(jobDetails + "  not found in the database ",HttpStatus.OK) ;
			}
		}
		catch(Exception e)
		{
			return  new ResponseEntity(e  + " data not found in the database ",HttpStatus.OK) ;
			
		}
	}
	

	@RequestMapping("/getJobCategoryTypeId")
	public ResponseEntity getJobCategoryTypeIdRest(@RequestParam(value="jobTypeId") String jobTypeId)
	{
		try
		{
			JobCategoryDetailsDAO jobDetailsDAO=new JobCategoryDetailsDAOImpl();
			JobCategoryDetails jobDetails=new JobCategoryDetails();
			jobDetails.setJobTypeId(jobTypeId);
			List <JobCategoryDetails>  jobByTypeDetails  = jobDetailsDAO.getJobTypeId(jobDetails);
			
			if(jobByTypeDetails != null)
			{
	    	    return  new ResponseEntity(jobByTypeDetails,HttpStatus.OK) ;
			}
			else
			{
	    	    return  new ResponseEntity(jobDetails + "  not found in the database ",HttpStatus.OK) ;
			}
		}
		catch(Exception e)
		{
			return  new ResponseEntity(e  + " data not found in the database ",HttpStatus.INTERNAL_SERVER_ERROR) ;
			
		}
	}

	
	
	

	
	
}
