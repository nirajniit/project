package controller;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.json.simple.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import dao.TestimonialDetailsDAO;
import daoimpl.TestimonialDetailsDAOImpl;
import model.TestimonialDetails;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class TestimonialDetailsController
{
	
	
	@RequestMapping("/getalltestimonialdetails")
	ResponseEntity<List> getAllTestiMonialDetails()
	{
		TestimonialDetailsDAO testimonialDetailsDAO = new TestimonialDetailsDAOImpl();
		List <TestimonialDetails>  allTestimonial =testimonialDetailsDAO.getAllTestimonial();
		return new ResponseEntity<List>(allTestimonial,HttpStatus.OK);
	}
	
	
	@RequestMapping("/getalltestimonialdetailsbyapproved")
	ResponseEntity<List> getAllTestiMonialDetailsapproved(@RequestParam (value="approved") String approved)
	{
		TestimonialDetailsDAO testimonialDetailsDAO = new TestimonialDetailsDAOImpl();
		TestimonialDetails testimonialDetails = new TestimonialDetails();
		testimonialDetails.setApproved("Y");
		List <TestimonialDetails>  allTestimonial =testimonialDetailsDAO.getTestimonialByApproved(testimonialDetails);
		return new ResponseEntity<List>(allTestimonial,HttpStatus.OK);
	}
	
	
	
	
	@RequestMapping("/addtestimonialdetails")
	ResponseEntity<List> addTestiMonialDetails(TestimonialDetails testimonialDetails)
	{
		
			try
			{
				
					System.out.println("==============addtestimonialdetails Rest Api Controller ===================");
					
					System.out.println(" "+testimonialDetails.getTestiMonialId());
					System.out.println(" "+testimonialDetails.getTestiMonial());
					System.out.println(" "+testimonialDetails.getTestiMonialStatus());
					System.out.println(" "+testimonialDetails.getTestiMonialOrganization());
					System.out.println(" "+testimonialDetails.getTestiMonialDateTime());
					System.out.println("==============addtestimonialdetails Rest Api Controller ===================");
					
				
					TestimonialDetailsDAO testimonialDetailsDAO = new TestimonialDetailsDAOImpl();
					boolean flag = testimonialDetailsDAO.addTestimonial(testimonialDetails);
					if(flag == true)
					{
			
						JSONObject jj = new JSONObject();
						jj.put("data","success");
						List ll = new ArrayList();
						ll.add(jj);
 	    				return new ResponseEntity<List>(ll,HttpStatus.OK);
					}
					else
					{
						JSONObject jj = new JSONObject();
						jj.put("data","nsuccess");
						List ll = new ArrayList();
						ll.add(jj);
						return new ResponseEntity<List>(ll,HttpStatus.OK);
					}
		
			}
			catch(Exception e)
			{
				System.out.println(" ================================= ");
	 	    	System.out.println(" Rest Controller :  Runtime error  ");
	 	    	System.out.println(" ================================= ");
	 	    	JSONObject jj = new JSONObject();
	 	    	jj.put("data",e.toString());
	 	    	List ll = new ArrayList();
	 	    	ll.add(jj);
	 	    	return new ResponseEntity<List>(ll,HttpStatus.OK);
			}
	}
	
	
	@RequestMapping("/updatetestimonialdetails")
	ResponseEntity<List>updateTestiMonialDetails(TestimonialDetails testimonialDetails)
	{
		
		TestimonialDetailsDAO testimonialDetailsDAO = new TestimonialDetailsDAOImpl();
		TestimonialDetails currentTestimonial = testimonialDetailsDAO.getTestimonialById(testimonialDetails);
			
		currentTestimonial.setApproved(testimonialDetails.getApproved());
		
			
			try
			{
					System.out.println("==============updatetestimonialdetails Rest Api Controller ===================");
					System.out.println(" "+testimonialDetails.getTestiMonialId());
					System.out.println(" "+testimonialDetails.getTestiMonial());
					System.out.println(" "+testimonialDetails.getTestiMonialStatus());
					System.out.println(" "+testimonialDetails.getTestiMonialOrganization());
					System.out.println(" "+testimonialDetails.getTestiMonialDateTime());
					System.out.println(" "+testimonialDetails.getApproved());
					System.out.println(" "+testimonialDetails.getRrating());
					
								
					
					
					System.out.println("==============updatetestimonialdetails Rest Api Controller ===================");
					
				
					
					boolean flag = testimonialDetailsDAO.updateTestimonial(currentTestimonial);
					if(flag == true)
					{
			
						JSONObject jj = new JSONObject();
						jj.put("data","success");
						List ll = new ArrayList();
						ll.add(jj);
 	    				return new ResponseEntity<List>(ll,HttpStatus.OK);
					}
					else
					{
						JSONObject jj = new JSONObject();
						jj.put("data","nsuccess");
						List ll = new ArrayList();
						ll.add(jj);
						return new ResponseEntity<List>(ll,HttpStatus.OK);
					}
		
			}
			catch(Exception e)
			{
				System.out.println(" ================================= ");
	 	    	System.out.println(" Rest Controller :  Runtime error  ");
	 	    	System.out.println(" ================================= ");
	 	    	JSONObject jj = new JSONObject();
	 	    	jj.put("data",e.toString());
	 	    	List ll = new ArrayList();
	 	    	ll.add(jj);
	 	    	return new ResponseEntity<List>(ll,HttpStatus.OK);
			}


	
	
	}
		

	@RequestMapping("/deletetestimonialdetails")
	ResponseEntity<List>deleteTestiMonialDetails(TestimonialDetails testimonialDetails)
	{
			try
			{		
				
					TestimonialDetailsDAO testimonialDetailsDAO = new TestimonialDetailsDAOImpl();
					boolean flag = testimonialDetailsDAO.deleteTestimonial(testimonialDetails);
					
					if(flag == true)
					{
			
						JSONObject jj = new JSONObject();
						jj.put("data","success");
						List ll = new ArrayList();
						ll.add(jj);
 	    				return new ResponseEntity<List>(ll,HttpStatus.OK);
					}
					else
					{
						JSONObject jj = new JSONObject();
						jj.put("data","nsuccess");
						List ll = new ArrayList();
						ll.add(jj);
						return new ResponseEntity<List>(ll,HttpStatus.OK);
					}
			}
			catch(Exception e)
			{
				System.out.println(" ================================= ");
	 	    	System.out.println(" Rest Controller :  Runtime error  ");
	 	    	System.out.println(" ================================= ");
	 	    	JSONObject jj = new JSONObject();
	 	    	jj.put("data",e.toString());
	 	    	List ll = new ArrayList();
	 	    	ll.add(jj);
	 	    	return new ResponseEntity<List>(ll,HttpStatus.OK);
			}
	
	}

}
