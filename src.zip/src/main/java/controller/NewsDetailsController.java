package controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import dao.NewsDetailsDAO;
import daoimpl.NewsDetailsDAOImpl;

import model.NewsDetails;





@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class NewsDetailsController {
	
	
	@RequestMapping("/updateNewsDetails")
	ResponseEntity <List> updateCategoryDetails( @RequestParam(value = "newsId") String newsId , @RequestParam(value = "approved") String approved , HttpServletRequest servletRequest ,  HttpSession session)
	{
		System.out.println(" News id " + newsId);
		System.out.println(" Approved " + approved);
		
		
		
		NewsDetailsDAO newsDetailsDAO  = new NewsDetailsDAOImpl();
		NewsDetails newsDetails = new NewsDetails();
		
		int nid = Integer.parseInt(newsId);
		newsDetails.setNewsId(nid);
		NewsDetails currentNewsDetails =newsDetailsDAO.getNewsById(newsDetails);
		
		
		
		System.out.println(currentNewsDetails);
		currentNewsDetails.setApproved(approved);
		
		boolean flag =	newsDetailsDAO.updateNews(currentNewsDetails);
		return null;
	}
	
	
	
	
	@RequestMapping(value="allnewsdetails")
	public ResponseEntity<List> allNewsDetailsApi()
	{
		NewsDetailsDAO newsDetailsDAO = new NewsDetailsDAOImpl();
		List <NewsDetails>  allNews = newsDetailsDAO.getAllNews();
		List ll = new ArrayList();
		for(NewsDetails c : allNews)
		{
					System.out.println("===================");
					//System.out.println(c.getNewsImage());
					
					try
					{
			
				JSONObject jj = new JSONObject();
				
					//Object blob =  c.getNewsImage().getClass();  
					//String str = blob.toString();
				   System.out.println("-------------"+c.getNewsId());

				
				  jj.put("newsId", c.getNewsId());
				  jj.put("newsTitle", c.getNewsTitle());
				  jj.put("newsAuthor", c.getNewsAuthor());
				  jj.put("newsContent",c.getNewsContent());
				  jj.put("newsDate", c.getNewsDate());
				  //jj.put("newsImage", str.getBytes());
				  jj.put("newsImagenamne", c.getNewsImagenamne());
				  jj.put("userEmail", c.getUserEmail());
				  jj.put("rrating",c.getRrating() );
				  jj.put("approved",c.getApproved());
				  ll.add(jj);
	  
					}
					catch(Exception e)
					{
				
						
					}
				  
			}
			
			System.out.println(" ====================================== " );
			System.out.println(" IN IF  " );
			System.out.println(" ====================================== " );
			
			return new ResponseEntity <List>( ll,HttpStatus.OK);
		
	}
	
	@RequestMapping(value="allnewsdetailsbyapproved")
	public ResponseEntity<List> allNewsDetailsByApproved(@RequestParam (value="approved") String approved)
	{
		NewsDetailsDAO newsDetailsDAO = new NewsDetailsDAOImpl();
		
		NewsDetails news = new NewsDetails();
		news.setApproved(approved);
		List <NewsDetails>  allNews = newsDetailsDAO.getNewsByApproved(news);
		List ll = new ArrayList();
		for(NewsDetails c : allNews)
		{
					System.out.println("===================");
					//System.out.println(c.getNewsImage());
					
					try
					{
			
				JSONObject jj = new JSONObject();
				
					//Object blob =  c.getNewsImage().getClass();  
					//String str = blob.toString();
				   System.out.println("-------------"+c.getNewsId());

				
				  jj.put("newsId", c.getNewsId());
				  jj.put("newsTitle", c.getNewsTitle());
				  jj.put("newsAuthor", c.getNewsAuthor());
				  jj.put("newsContent",c.getNewsContent());
				  jj.put("newsDate", c.getNewsDate());
				  //jj.put("newsImage", str.getBytes());
				  jj.put("newsImagenamne", c.getNewsImagenamne());
				  jj.put("userEmail", c.getUserEmail());
				  jj.put("rrating",c.getRrating() );
				  jj.put("approved",c.getApproved());
				  ll.add(jj);
				  
					}
					catch(Exception e)
					{
						
						
					}
				  
			}
			
			System.out.println(" ====================================== " );
			System.out.println(" IN IF  " );
			System.out.println(" ====================================== " );
			
			return new ResponseEntity <List>( ll,HttpStatus.OK);
		
	}
	
	
}
