package controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.simple.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import dao.CategoryDetailsDAO;
import dao.SubcategoryDetailsDAO;
import daoimpl.CategoryDetailsDAOImpl;
import daoimpl.SubcategoryDetailsDAOImpl;
import model.CategoryDetails;
import model.SubcategoryDetails;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")

public class SubcategoryDetailsController 
{

	@RequestMapping("/getallsubcategory")
	ResponseEntity <List>  getAllSubcategory()
	{
		
		
		System.out.println("==================================   ");
		System.out.println("     GET or POST : getallsubcategory ");      
		System.out.println("==================================   ");

		
		try
		{
		
		SubcategoryDetailsDAO subcategoryDetailsDAO = new SubcategoryDetailsDAOImpl();
		List <SubcategoryDetails> subcategory=subcategoryDetailsDAO.getAllSubcategoryDetails();
				
		
		return new ResponseEntity (subcategory,HttpStatus.OK);
		}
		catch(Exception e)
		{
			List ll = new ArrayList();
			JSONObject jj = new JSONObject();
			jj.put("error",e.toString());
			ll.add(jj);
			return new ResponseEntity <List> (ll,HttpStatus.INTERNAL_SERVER_ERROR);
			
		}
	}


	
	@RequestMapping("/getsubcategorybymaincatid")
	ResponseEntity <List>  getsubcategorybymaincatid(@RequestParam(value="productID") String productID)
	{
		
		
		System.out.println("==================================   ");
		System.out.println("     GET or POST : getallsubcategory ");      
		System.out.println("==================================   ");

		
		try
		{
		
			
			SubcategoryDetails ss = new SubcategoryDetails();
			ss.setProductID(Long.parseLong(productID));
			
			
		SubcategoryDetailsDAO subcategoryDetailsDAO = new SubcategoryDetailsDAOImpl();
		List <SubcategoryDetails> subcategory=subcategoryDetailsDAO.getSubcategoryDetailsByMainCatId(ss);
		
				
		
		return new ResponseEntity (subcategory,HttpStatus.OK);
		}
		catch(Exception e)
		{
			List ll = new ArrayList();
			JSONObject jj = new JSONObject();
			jj.put("error",e.toString());
			ll.add(jj);
			return new ResponseEntity <List> (ll,HttpStatus.INTERNAL_SERVER_ERROR);
			
		}
	}

	
	
	
	
	
	
	/*
		private Long subCategoryId;
		private String subCategoryName;
		private String dateTime;
		private Long catId;
		private Long productID;
	
	*/
	
	
	@RequestMapping("/addsubcategory")
	ResponseEntity <List>  addSubcategory(@RequestParam(value="subCategoryId") String subCategoryId,@RequestParam(value="subCategoryName") String subCategoryName, @RequestParam(value="catId") String catId,@RequestParam(value="productID") String productID)
	{
		
		
		System.out.println(" ==================================   ");
		System.out.println("  GET or POST : getallsubcategory  ");      
		System.out.println(" ==================================   ");

		System.out.println(" subCategoryId "+ subCategoryId);
		System.out.println(" subCategoryName "+ subCategoryName);
		System.out.println(" catId "+ catId);
		System.out.println(" productID "+ productID);
		
		
	
		
		try
		{
		

		SubcategoryDetailsDAO subcategoryDetailsDAO = new SubcategoryDetailsDAOImpl();
	    SubcategoryDetails  subcategoryDetails = new SubcategoryDetails();
		
	    Long longsubCategoryId = Long.parseLong(subCategoryId);   
	    Long longcatId = Long.parseLong(catId);
	    Long longsetProductID = Long.parseLong(productID);
	    
	    
	    subcategoryDetails.setSubCategoryId(longsubCategoryId);
	    subcategoryDetails.setCatId(longcatId);
	    subcategoryDetails.setProductID(longsetProductID);
	    subcategoryDetails.setSubCategoryName(subCategoryName);
	    Date myDate = new Date();
		    SimpleDateFormat dmyFormat = new SimpleDateFormat("dd-MM-yyyy");
		    String date = dmyFormat.format(myDate); 
		    subcategoryDetails.setDateTime(date);
		    
		   boolean flag =	subcategoryDetailsDAO.addSubcategoryDetails(subcategoryDetails);
		
		
		
		   if(flag == true)
		   {
		
			List ll = new ArrayList();
			JSONObject jj = new JSONObject();
			jj.put("data","success");
			jj.put("data1","data addedd success");
			ll.add(jj);
			return new ResponseEntity <List> (ll,HttpStatus.OK);
		   }
		   else
		   {
			   List ll = new ArrayList();
				JSONObject jj = new JSONObject();
				jj.put("data","nsuccess");
				jj.put("data1","data not added ");
				ll.add(jj);
				return new ResponseEntity <List> (ll,HttpStatus.OK);
		   }
		}
		catch(Exception e)
		{
			
			List ll = new ArrayList();
			JSONObject jj = new JSONObject();
			jj.put("data","nsuccess");
			jj.put("data1",e.toString());
			ll.add(jj);
			return new ResponseEntity <List> (ll,HttpStatus.OK);
			
		}
		   
		
	}

		
	@RequestMapping("/updatesubcategory")
	ResponseEntity <List>  updateSubcategory(@RequestParam(value="subCategoryId") String subCategoryId,@RequestParam(value="subCategoryName") String subCategoryName, @RequestParam(value="catId") String catId,@RequestParam(value="productID") String productID)
	{
		
		
		System.out.println(" ==================================   ");
		System.out.println("  GET or POST : updatesubcategory  ");      
		System.out.println(" ==================================   ");

		System.out.println(" subCategoryId "+ subCategoryId);
		System.out.println(" subCategoryName "+ subCategoryName);
		System.out.println(" catId "+ catId);
		System.out.println(" productID "+ productID);
		try
		{
		
			SubcategoryDetailsDAO subcategoryDetailsDAO = new SubcategoryDetailsDAOImpl();
			SubcategoryDetails  subcategoryDetails = new SubcategoryDetails();
		
			Long longsubCategoryId = Long.parseLong(subCategoryId);   
			Long longcatId = Long.parseLong(catId);
			Long longsetProductID = Long.parseLong(productID);
	    
	    
			subcategoryDetails.setSubCategoryId(longsubCategoryId);
			subcategoryDetails.setCatId(longcatId);
			subcategoryDetails.setProductID(longsetProductID);
			subcategoryDetails.setSubCategoryName(subCategoryName);
			Date myDate = new Date();
			SimpleDateFormat dmyFormat = new SimpleDateFormat("dd-MM-yyyy");
			String date = dmyFormat.format(myDate); 
			subcategoryDetails.setDateTime(date);
		    
			boolean flag =	subcategoryDetailsDAO.updateSubcategoryDetails(subcategoryDetails);
		   
		   if(flag == true)
		   {
		
			List ll = new ArrayList();
			JSONObject jj = new JSONObject();
			jj.put("data","success");
			jj.put("data1","data updated success");
			ll.add(jj);
			return new ResponseEntity <List> (ll,HttpStatus.OK);
		   }
		   else
		   {
			   List ll = new ArrayList();
				JSONObject jj = new JSONObject();
				jj.put("data","nsuccess");
				jj.put("data1","data not updated ");
				ll.add(jj);
				return new ResponseEntity <List> (ll,HttpStatus.OK);
		   }
		}
		catch(Exception e)
		{
			
			List ll = new ArrayList();
			JSONObject jj = new JSONObject();
			jj.put("data","nsuccess");
			jj.put("data1",e.toString());
			ll.add(jj);
			return new ResponseEntity <List> (ll,HttpStatus.OK);
			
		}
		   
		
	}
	
	
	
	
	
	
	@RequestMapping("/deletesubcategory")
	ResponseEntity <List>  deleteSubcategory(@RequestParam(value="subCategoryId") String subCategoryId)
	{

		System.out.println(" ==================================     ");
		System.out.println("  GET or POST : deletesubcategory  		");      
		System.out.println(" ==================================     ");

		SubcategoryDetailsDAO subcategoryDetailsDAO = new SubcategoryDetailsDAOImpl();
	    SubcategoryDetails  subcategoryDetails = new SubcategoryDetails();
	
	    Long longsubCategoryId = Long.parseLong(subCategoryId);
	    subcategoryDetails.setSubCategoryId(longsubCategoryId);
	
	    boolean flag  =subcategoryDetailsDAO.deleteSubcategoryDetails(subcategoryDetails);
		
	    if(flag == true)
	    {

	    	List ll = new ArrayList();
	    	JSONObject jj = new JSONObject();
	    	jj.put("data","success");
	    	jj.put("data1","data deleted success");
	    	ll.add(jj);
	    	return new ResponseEntity <List> (ll,HttpStatus.OK);
	    }
	    else
	    {
	    	List ll = new ArrayList();
	    	JSONObject jj = new JSONObject();
	    	jj.put("data","nsuccess");
	    	jj.put("data1","data not deleted ");
	    	ll.add(jj);
	    	return new ResponseEntity <List> (ll,HttpStatus.OK);
	    }
   }
	

}
