package controller;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import dao.ProductDetailsDAO;
import daoimpl.ProductDetailsDAOImpl;
import model.ProductDetails;


@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ProductDetailsController {
	
	@RequestMapping("/addProduct")
	public ResponseEntity addProductRest(@RequestParam(value="productID") String productID,@RequestParam(value="productType") String productType, @RequestParam(value="cityId") String cityId)
	{
		System.out.println(" nnnnnnnnnnnn nnnnnnnnnnnnnnnn nnnnnnnnnnnnnnnnn " );
		
		try
		{
			
			Long longProductID = Long.parseLong(productID);
			ProductDetailsDAO productDetailsDAO = new ProductDetailsDAOImpl();
			ProductDetails productDetails = new ProductDetails();
		
			productDetails.setProductID(longProductID);
			productDetails.setProductType(productType);
			productDetails.setCityId(cityId);
		
		   	boolean falg = productDetailsDAO.addProduct(productDetails);
        	
        	if(falg == true)
        	{
        		JSONObject jj = new JSONObject();
	 	    	jj.put("data","success");
	 	    	List ll = new ArrayList();
	 	    	ll.add(jj);
	 	       	return new ResponseEntity<List>(ll,HttpStatus.OK);

        	}
        	else
        	{
        	  	JSONObject jj = new JSONObject();
	 	    	jj.put("data","nsuccess");
	 	    	List ll = new ArrayList();
	 	    	ll.add(jj);
	 	    
	 	       	return new ResponseEntity<List>(ll,HttpStatus.OK);

        	}
        		
		}
		catch(Exception e)
		{
		
		  	JSONObject jj = new JSONObject();

 	    	jj.put("data",e.toString());
 	    	List ll = new ArrayList();
 	    	ll.add(jj);
 	    
 	       	return new ResponseEntity<List>(ll,HttpStatus.OK);


		}
	}
	
	@RequestMapping("/deleteProduct")
	public ResponseEntity deleteProductRest(@RequestParam(value="productID") String productID)
	{
	
		try
		{
			ProductDetailsDAO productDetailsDAO = new ProductDetailsDAOImpl();
			ProductDetails productDetails = new ProductDetails();
		
			Long longProductID = Long.parseLong(productID);
			
			productDetails.setProductID(longProductID);
		
		   	boolean falg = productDetailsDAO.deleteProduct(productDetails);
		   	
        	
        	if(falg == true)
        	{
        		JSONObject jj = new JSONObject();
	 	    	jj.put("data","success");
	 	    	List ll = new ArrayList();
	 	    	ll.add(jj);
	 	       	return new ResponseEntity<List>(ll,HttpStatus.OK);

        	}
        	else
        	{
        		JSONObject jj = new JSONObject();
	 	    	jj.put("data","nsuccess");
	 	    	List ll = new ArrayList();
	 	    	ll.add(jj);
	 	       	return new ResponseEntity<List>(ll,HttpStatus.OK);

        	}
        		
		}
		catch(Exception e)
		{
		
			JSONObject jj = new JSONObject();
 	    	jj.put("data",e.toString());
 	    	List ll = new ArrayList();
 	    	ll.add(jj);
 	       	return new ResponseEntity<List>(ll,HttpStatus.OK);

		}
	}

	
	

	@RequestMapping("/updateProduct")
	public ResponseEntity updateProductRest(@RequestParam(value="productID") String productID,@RequestParam(value="productType") String productType, @RequestParam(value="cityId") String cityId)
	{
		try
		{
			ProductDetailsDAO productDetailsDAO = new ProductDetailsDAOImpl();
			ProductDetails productDetails = new ProductDetails();
			Long longProductID = Long.parseLong(productID);
			productDetails.setProductID(longProductID);
			productDetails.setProductType(productType);
			productDetails.setCityId(cityId);
		
		   	boolean falg = productDetailsDAO.updateProduct(productDetails);
        	
        	if(falg == true)
        	{
        		JSONObject jj = new JSONObject();
	 	    	jj.put("data","success");
	 	    	List ll = new ArrayList();
	 	    	ll.add(jj);
	 	       	return new ResponseEntity<List>(ll,HttpStatus.OK);

        	}
        	else
        	{
        		JSONObject jj = new JSONObject();
	 	    	jj.put("data","nsuccess");
	 	    	List ll = new ArrayList();
	 	    	ll.add(jj);
	 	       	return new ResponseEntity<List>(ll,HttpStatus.OK);

        	}
        		
		}
		catch(Exception e)
		{
		
			JSONObject jj = new JSONObject();
 	    	jj.put("data",e.toString());
 	    	List ll = new ArrayList();
 	    	ll.add(jj);
 	       	return new ResponseEntity<List>(ll,HttpStatus.OK);

		}
	}
	
	
	
	@RequestMapping("/getAllProduct")
	public ResponseEntity getAllProductRest()
	{

		try
		{
				ProductDetailsDAO productDetailsDAO = new ProductDetailsDAOImpl();
				List <ProductDetails> productDetails = productDetailsDAO.getAllProduct();
				
				if(productDetails != null)
				{
					return new ResponseEntity(productDetails,HttpStatus.OK);
				}
				else
				{
					return new ResponseEntity("Product Not Found",HttpStatus.OK);
					
				}
		}
		catch(Exception e)
		{
			    return new ResponseEntity(e,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	

	@RequestMapping("/getproductbycityid")
	public ResponseEntity getproductbycityid(@RequestParam (value="cityid") String cityid)
	{

		try
		{
				ProductDetailsDAO productDetailsDAO = new ProductDetailsDAOImpl();
				ProductDetails prd = new ProductDetails();
				prd.setCityId(cityid);
				
				List <ProductDetails> productDetails = productDetailsDAO.getProductByCityId(prd);
				
				if(productDetails != null)
				{
					return new ResponseEntity(productDetails,HttpStatus.OK);
				}
				else
				{
					JSONObject jj = new JSONObject();
		 	    	jj.put("data","nsuccess");
		 	    	List ll = new ArrayList();
		 	    	ll.add(jj);
		 	       	return new ResponseEntity<List>(ll,HttpStatus.OK);

					
				}
		}
		catch(Exception e)
		{
			JSONObject jj = new JSONObject();
 	    	jj.put("data",e.toString());
 	    	List ll = new ArrayList();
 	    	ll.add(jj);
 	       	return new ResponseEntity<List>(ll,HttpStatus.OK);

		}
	}
	
	
	
	
	
	
	
	
	
	
	
	@RequestMapping("/getProductByType")
	public ResponseEntity getProductByNameRest(@RequestParam (value="productType") String productType)
	{

		try
		{
				ProductDetailsDAO productDetailsDAO = new ProductDetailsDAOImpl();
				ProductDetails prd = new ProductDetails();
				prd.setProductType(productType);
				
				List <ProductDetails> productDetails = productDetailsDAO.getProductByName(prd);
				
				if(productDetails != null)
				{
					return new ResponseEntity(productDetails,HttpStatus.OK);
				}
				else
				{
					JSONObject jj = new JSONObject();
		 	    	jj.put("data","nsuccess");
		 	    	List ll = new ArrayList();
		 	    	ll.add(jj);
		 	       	return new ResponseEntity<List>(ll,HttpStatus.OK);

					
				}
		}
		catch(Exception e)
		{
			JSONObject jj = new JSONObject();
 	    	jj.put("data",e.toString());
 	    	List ll = new ArrayList();
 	    	ll.add(jj);
 	       	return new ResponseEntity<List>(ll,HttpStatus.OK);

		}
	}

	
@RequestMapping("/getProductById")
public ResponseEntity getProductByIdRest(@RequestParam (value="productID") String productID)
	{

		try
		{
			ProductDetailsDAO productDetailsDAO = new ProductDetailsDAOImpl();
			ProductDetails productDetails = new ProductDetails();
			
			
			Long longProductID = Long.parseLong(productID);
			productDetails.setProductID(longProductID);
			
					
			productDetails= productDetailsDAO.getProductById(productDetails);
			
			
			
			if(productDetails != null)
			{
				return new ResponseEntity(productDetails,HttpStatus.OK);
			}
			else
			{
				JSONObject jj = new JSONObject();
	 	    	jj.put("data","nsuccess");
	 	    	List ll = new ArrayList();
	 	    	ll.add(jj);
	 	       	return new ResponseEntity<List>(ll,HttpStatus.OK);

				
			}
		}
		catch(Exception e)
		{
			JSONObject jj = new JSONObject();
 	    	jj.put("data",e.toString());
 	    	List ll = new ArrayList();
 	    	ll.add(jj);
 	       	return new ResponseEntity<List>(ll,HttpStatus.OK);

		}		
	}
	
	
	
	

}
