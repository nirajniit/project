package controller;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.Consumes;

import org.hibernate.engine.jdbc.BlobProxy;
import org.json.simple.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import dao.UserDetailsDAO;
import dao.UserProfileDetailsDAO;
import daoimpl.UserDetailsDAOImpl;
import daoimpl.UserProfileDetailsDAOImpl;
import model.UserDetails;
import model.UserProfileDetails;

@RestController 
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class UserProfileDetailsController {
	
	
	
	 @RequestMapping(value = "/alluserprofile")
		public ResponseEntity<List> getAllUserProfile() 
	    {
	    	
	    	System.out.println("================================================");
	    	System.out.println(" @RestAPI : getAllUserProfile By POST or GET Request ");
	    	System.out.println("================================================");

	    	UserProfileDetailsDAO userProfileDetailsTestDAO = new UserProfileDetailsDAOImpl();
	    	
	    	List<UserProfileDetails>  allProfileDetails =userProfileDetailsTestDAO.getUserProfileDetails();
	    	
	    	
	      	return new ResponseEntity(allProfileDetails,HttpStatus.OK);
	  			
	    }

	 

	 @RequestMapping(value = "/deleteuserprofile")
		public ResponseEntity<List> deleteUserProfile(@RequestParam(value ="id") int id) 
	    {
	    	
	    	System.out.println("================================================");
	    	System.out.println(" @RestAPI : delegteUserProfile By POST or GET Request ");
	    	System.out.println("================================================");

	    	try
	    	{
	   	 UserProfileDetailsDAO userPorfileDetailsDAO=new UserProfileDetailsDAOImpl();
	   	UserProfileDetails userProfileDetails=new UserProfileDetails();
	   	userProfileDetails.setId(id);
	     boolean	flag=userPorfileDetailsDAO.deleteUserProfileDetails(userProfileDetails);
	    
	     
	     	if(flag == true)
	     	{
	     		JSONObject jj = new JSONObject();
	  			jj.put("data",userProfileDetails.getId()+ " has been deleted successfully from the database ");
	  			jj.put("data1","yes");
	  			List ll = new ArrayList();
	  			ll.add(jj);
    			return new ResponseEntity<List>(ll,HttpStatus.OK);
	     	}
	     	else
	     	{
	    		JSONObject jj = new JSONObject();
	  			jj.put("data",userProfileDetails.getId()+ " has been not deleted  from the database ");
	  			jj.put("data1","no");
	  			List ll = new ArrayList();
	  			ll.add(jj);
    			return new ResponseEntity<List>(ll,HttpStatus.OK);
	     		
	     	}
	     
	     
	    	}
	    	catch(Exception e)
	    	{
	    		JSONObject jj = new JSONObject();
	  			jj.put("data",e.toString());
	  			List ll = new ArrayList();
	  			ll.add(jj);
    			return new ResponseEntity<List>(ll,HttpStatus.OK);
	    
	    	}	
	    }


	 
	 
	 
	 @RequestMapping(value = "/getuserprofilebyid")
		public ResponseEntity<List> getUserProfileByid(@RequestParam(value ="id") int id) 
	    {
	    	
	    	System.out.println("================================================");
	    	System.out.println(" @RestAPI : getUserProfilebyid By POST or GET Request ");
	    	System.out.println("================================================");

	    	
	    	try
	    	{
	    				UserProfileDetailsDAO userPorfileDetailsDAO=new UserProfileDetailsDAOImpl();
	    				UserProfileDetails userProfileDetails=new UserProfileDetails();
	    				userProfileDetails.setId(id);
	    				userProfileDetails=userPorfileDetailsDAO.getProfileById(userProfileDetails);
	    
	     
	    				if(userProfileDetails != null)
	    				{
	    					JSONObject jj = new JSONObject();
	    					jj.put("data",userProfileDetails.getId()+ " has been deleted successfully from the database ");
	    					jj.put("data1","yes");
	    					List ll = new ArrayList();
	    					ll.add(jj);
	    					return new ResponseEntity(userProfileDetails,HttpStatus.OK);
	    				}
	    				else
	    				{
	    					JSONObject jj = new JSONObject();
	    					jj.put("data",id+ " has been not found  in the database ");
	    					jj.put("data1","no");
	    					List ll = new ArrayList();
	    					ll.add(jj);
	    					return new ResponseEntity<List>(ll,HttpStatus.OK);
	    					
	    				}
	     
	     
	    	}
	    	catch(Exception e)
	    	{
	    		JSONObject jj = new JSONObject();
	  			jj.put("data",e.toString());
	  			List ll = new ArrayList();
	  			ll.add(jj);
 			return new ResponseEntity<List>(ll,HttpStatus.OK);
	    
	    	}	
	    }
	 

	 @RequestMapping(value = "/getuserprofilebyemailid")
		public ResponseEntity<List> getUserProfileByUserEmail(@RequestParam(value ="userEmail") String userEmail) 
	    {
	    	
	    	System.out.println("================================================");
	    	System.out.println(" @RestAPI : getUserProfilebyemailid By POST or GET Request ");
	    	System.out.println("================================================");
	    	try
	    	{
	    				UserProfileDetailsDAO userPorfileDetailsDAO=new UserProfileDetailsDAOImpl();
	    				UserProfileDetails userProfileDetails=new UserProfileDetails();
	    				userProfileDetails.setUserEmail(userEmail);
	    				List <UserProfileDetails> alluserbyemail =userPorfileDetailsDAO.getProfileByEmailId(userProfileDetails);
	    
    
	    				if(alluserbyemail != null)
	    				{
	    					JSONObject jj = new JSONObject();
	    					jj.put("data",userProfileDetails.getId()+ " has been deleted successfully from the database ");
	    					jj.put("data1","yes");
	    					List ll = new ArrayList();
	    					ll.add(jj);
	    					return new ResponseEntity(alluserbyemail,HttpStatus.OK);
	    				}
	    				else
	    				{
	    					JSONObject jj = new JSONObject();
	    					jj.put("data",userEmail+ " has been not found  in the database ");
	    					jj.put("data1","no");
	    					List ll = new ArrayList();
	    					ll.add(jj);
	    					return new ResponseEntity<List>(ll,HttpStatus.OK);
	    					
	    				}
	    				
	     
	     
	    	}
	    	catch(Exception e)
	    	{
	    		JSONObject jj = new JSONObject();
	  			jj.put("data",e.toString());
	  			List ll = new ArrayList();
	  			ll.add(jj);
			return new ResponseEntity<List>(ll,HttpStatus.OK);
	    
	    	}	
	    }

	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	   
	   @RequestMapping(value = "/adduserprofile")
	    public ResponseEntity<List> addUserDetailsPostRaw(
	    		@RequestParam(value ="userName") String userName,
	    		@RequestParam(value ="nationality") String nationality,
	    		@RequestParam(value ="Dob") String Dob,
	    		@RequestParam(value ="careerLevel") String careerLevel,
	    		@RequestParam(value ="currentLoction") String currentLoction,
	    		@RequestParam(value ="currentPosition") String currentPosition,
	    		@RequestParam(value ="currentCompany") String currentCompany,
	    		
	       		@RequestParam(value ="salaryExpectaions") String salaryExpectaions,
	    		@RequestParam(value ="commitment") String commitment,
	    		@RequestParam(value ="noticePeriod") String noticePeriod,
	    		@RequestParam(value ="visaStatus") String visaStatus,
	    		@RequestParam(value ="hidePhoto") String hidePhoto,
	    		@RequestParam(value = "profileImg") MultipartFile profileImg,
	    		@RequestParam(value ="dateTime") String dateTime,
	    		@RequestParam(value = "chooseFile") MultipartFile chooseFile,
	    		@RequestParam(value ="education") String education,
	 
	    		
	    		@RequestParam(value ="yourCVsummary") String yourCVsummary,
	    		@RequestParam(value ="iHavegot1") String iHavegot1,
	    		@RequestParam(value ="experienceIn1") String experienceIn1,
	    		@RequestParam(value ="iHavegot2") String iHavegot2,
	    		@RequestParam(value ="experienceIn2") String experienceIn2,
	    		
	    		@RequestParam(value ="iHavegot3") String iHavegot3,
	    		@RequestParam(value ="experienceIn3") String experienceIn3,
	    		@RequestParam(value ="iHavegot4") String iHavegot4,
	    		@RequestParam(value ="experienceIn4") String experienceIn4,
	    		@RequestParam(value ="iHavegot5") String iHavegot5,
	    		@RequestParam(value ="experienceIn5") String experienceIn5,
	    		@RequestParam(value ="checkBox1") String checkBox1,
	    		@RequestParam(value ="checkBox2") String checkBox2,
	    		@RequestParam(value ="userEmail") String  userEmail,
	    
	    		
	    				
	    		HttpServletRequest servletRequest, HttpSession session) throws Exception
	    
	    {
		   System.out.println("===========================================");
		   System.out.println("===========add userprofile REST API ================");
		   System.out.println("===========================================");
		   
		   
		   		UserProfileDetails userprofile = new UserProfileDetails();
		   		
		   		userprofile.setUserName(userName);
		   		userprofile.setNationality(nationality);
		   		userprofile.setDob(Dob);
		   		userprofile.setCareerLevel(careerLevel);
		   		userprofile.setCurrentLoction(currentLoction);
		   		userprofile.setCurrentPosition(currentPosition);
		   		userprofile.setCurrentCompany(currentCompany);
		   		userprofile.setSalaryExpectaions(salaryExpectaions);
		   		userprofile.setCommitment(commitment);
		   		userprofile.setNoticePeriod(noticePeriod);
		   		userprofile.setVisaStatus(visaStatus);
		   		userprofile.setHidePhoto(hidePhoto);
		   		
		   		byte restbyteprofileImg[] =  profileImg.getBytes();  
		   		userprofile.setProfileImg(BlobProxy.generateProxy(restbyteprofileImg));
		   		
		   		
		   		// get the last id 
		   		int id=0;
		   		UserProfileDetailsDAO Usermultimediadao = new UserProfileDetailsDAOImpl();
                List<UserProfileDetails>list=Usermultimediadao.getUserProfileDetails();
				Iterator item = list.iterator();
				while(item.hasNext()){
					UserProfileDetails Usermultimedia =(UserProfileDetails)item.next();
						id=Usermultimedia.getId();
						System.out.println("id = "+id);
				}
		   		
		   		
		   		// for Profile File 
		   		
	        	String profileImage = profileImg.getOriginalFilename();
	        	String profileImageArray[] = profileImage.split("\\.");
	        	
	        	profileImage = profileImageArray[0]+id+"."+profileImageArray[1]; 
		   		
	        	try
	        	{
	        		
	        		String path="C:/FrontEnd/gulfroad/gulfroad/src/assets/images/profileimage/";
	        		// String path=session.getServletContext().getRealPath("/thegulgrestapi/src/main/webapp/resources/uploadfiles");
	        		 
	    	        System.out.println("==========================="); 
	    	        System.out.println("==========================="); 
	    	        
	    	        String fillpath=path+""+profileImage;
	    	        System.out.println(fillpath);
	    	        System.out.println("==========================="); 
	    	        System.out.println("==========================="); 
	    	        
	    	        
	    	          
	    	        byte barr[] = profileImg.getBytes();  
	    	          
	    	        BufferedOutputStream bout=new BufferedOutputStream(  
	    	                 new FileOutputStream(fillpath));  
	    	        bout.write(barr);  
	    	        bout.flush();  
	    	        bout.close();
	    	       userprofile.setProfileImgName(profileImage);
	        		
	        	}
	        	catch(Exception e)
	        	{
	        		
	        		System.out.println("==========================="); 
	    	        System.out.println("==========================="); 
	    	        System.out.println("Run time Error "+ e);
	    	        System.out.println("==========================="); 
	    	        System.out.println("==========================="); 
	        		 
	        		
	        	}
	        	
	        	// for Profile File end
	        	
	        	
		   		
		   		userprofile.setDateTime(dateTime);
		   		
		
		   		byte restbyteproChooseFile[] =  chooseFile.getBytes();  
		   		userprofile.setChooseFile(BlobProxy.generateProxy(restbyteproChooseFile));
		
		   		

	        	String profileCV = chooseFile.getOriginalFilename();
	        	String profileCVArray[] = profileCV.split("\\.");
	        	
	        	profileCV = profileCVArray[0]+id+"."+profileCVArray[1]; 
		   		
	        	try
	        	{
	        		
	        		String path="C:/FrontEnd/gulfroad/gulfroad/src/assets/images/profilecv/";
	        		// String path=session.getServletContext().getRealPath("/thegulgrestapi/src/main/webapp/resources/uploadfiles");
	        		 
	    	        System.out.println("==========================="); 
	    	        System.out.println("==========================="); 
	    	        
	    	        String fillpath=path+""+profileCV;
	    	        System.out.println(fillpath);
	    	        System.out.println("==========================="); 
	    	        System.out.println("==========================="); 
	    	        
	    	        
	    	          
	    	        byte barr[] = chooseFile.getBytes();  
	    	          
	    	        BufferedOutputStream bout=new BufferedOutputStream(  
	    	                 new FileOutputStream(fillpath));  
	    	        bout.write(barr);  
	    	        bout.flush();  
	    	        bout.close();
	    	       userprofile.setCvFileName(profileCV);
	        		
	        	}
	        	catch(Exception e)
	        	{
	        		
	        		System.out.println("==========================="); 
	    	        System.out.println("==========================="); 
	    	        System.out.println("Run time Error "+ e);
	    	        System.out.println("==========================="); 
	    	        System.out.println("==========================="); 
	        		 
	        		
	        	}
	    
		   		
		   		
		   			
		   		
		   		
		   		
		   		
		   		userprofile.setEducation(education);
		   		userprofile.setYourCVsummary(yourCVsummary);

		   	
		   		userprofile.setiHavegot1(iHavegot1);
		   		userprofile.setExperienceIn1(experienceIn1);
		   	
		   		userprofile.setiHavegot2(iHavegot2);
		   		userprofile.setExperienceIn2(experienceIn2);
		   		
		   		
		   		
		   		
		   		
		   		userprofile.setiHavegot3(iHavegot3);
		   		userprofile.setExperienceIn3(experienceIn3);
		   		
		   	
		   		
		   		userprofile.setiHavegot4(iHavegot4);
		   		userprofile.setExperienceIn4(experienceIn4);
		   		
		   		
		   		userprofile.setiHavegot5(iHavegot5);
		   		userprofile.setExperienceIn5(experienceIn5);
		   		
		   		userprofile.setCheckBox1(checkBox1);
		   		userprofile.setCheckBox2(checkBox2);
		   		userprofile.setUserEmail(userEmail);
		   		
		   		
		   		
		   		
		   		UserProfileDetailsDAO dao = new UserProfileDetailsDAOImpl();
		   		
		   		boolean flag = dao.saveUserProfileDetails(userprofile);
		   		
		   		
		   		
		   		
		   		
		   		
		   		
		   		
	
		   	System.out.println(userprofile);
		   	
		   
	    	return new ResponseEntity(flag,HttpStatus.OK);
		   	
		}
	  
	  

	   
	   
	   @RequestMapping(value = "/updateuserprofile")
	    public ResponseEntity<List> updateUserDetailsPostRaw(
	    		@RequestParam(value ="id") int id,
	    		@RequestParam(value ="userName") String userName,
	    		@RequestParam(value ="nationality") String nationality,
	    		@RequestParam(value ="Dob") String Dob,
	    		@RequestParam(value ="careerLevel") String careerLevel,
	    		@RequestParam(value ="currentLoction") String currentLoction,
	    		@RequestParam(value ="currentPosition") String currentPosition,
	    		@RequestParam(value ="currentCompany") String currentCompany,
	    		
	       		@RequestParam(value ="salaryExpectaions") String salaryExpectaions,
	    		@RequestParam(value ="commitment") String commitment,
	    		@RequestParam(value ="noticePeriod") String noticePeriod,
	    		@RequestParam(value ="visaStatus") String visaStatus,
	    		@RequestParam(value ="hidePhoto") String hidePhoto,
	    		@RequestParam(value = "profileImg") MultipartFile profileImg,
	    		@RequestParam(value ="dateTime") String dateTime,
	    		@RequestParam(value = "chooseFile") MultipartFile chooseFile,
	    		@RequestParam(value ="education") String education,
	 
	    		
	    		@RequestParam(value ="yourCVsummary") String yourCVsummary,
	    		@RequestParam(value ="iHavegot1") String iHavegot1,
	    		@RequestParam(value ="experienceIn1") String experienceIn1,
	    		@RequestParam(value ="iHavegot2") String iHavegot2,
	    		@RequestParam(value ="experienceIn2") String experienceIn2,
	    		
	    		@RequestParam(value ="iHavegot3") String iHavegot3,
	    		@RequestParam(value ="experienceIn3") String experienceIn3,
	    		@RequestParam(value ="iHavegot4") String iHavegot4,
	    		@RequestParam(value ="experienceIn4") String experienceIn4,
	    		@RequestParam(value ="iHavegot5") String iHavegot5,
	    		@RequestParam(value ="experienceIn5") String experienceIn5,
	    		@RequestParam(value ="checkBox1") String checkBox1,
	    		@RequestParam(value ="checkBox2") String checkBox2,
	    		@RequestParam(value ="userEmail") String  userEmail,
	    
	    		
	    				
	    		HttpServletRequest servletRequest, HttpSession session) throws Exception
	    
	    {
		 
		   System.out.println("===========================================");
		   System.out.println("===========UPDATE  userprofile REST API ================");
		   System.out.println("===========================================");
		   
		   
		   
		   		UserProfileDetails userprofile = new UserProfileDetails();
		   		userprofile.setId(id);
		   		userprofile.setUserName(userName);
		   		userprofile.setNationality(nationality);
		   		userprofile.setDob(Dob);
		   		userprofile.setCareerLevel(careerLevel);
		   		userprofile.setCurrentLoction(currentLoction);
		   		userprofile.setCurrentPosition(currentPosition);
		   		userprofile.setCurrentCompany(currentCompany);
		   		userprofile.setSalaryExpectaions(salaryExpectaions);
		   		userprofile.setCommitment(commitment);
		   		userprofile.setNoticePeriod(noticePeriod);
		   		userprofile.setVisaStatus(visaStatus);
		   		userprofile.setHidePhoto(hidePhoto);
		   		
		   		byte restbyteprofileImg[] =  profileImg.getBytes();  
		   		userprofile.setProfileImg(BlobProxy.generateProxy(restbyteprofileImg));
		   		
		   		/*
		   		// get the last id 
		   		int id=0;
		   		UserProfileDetailsDAO Usermultimediadao = new UserProfileDetailsDAOImpl();
               List<UserProfileDetails>list=Usermultimediadao.getUserProfileDetails();
				Iterator item = list.iterator();
				while(item.hasNext()){
					UserProfileDetails Usermultimedia =(UserProfileDetails)item.next();
						id=Usermultimedia.getId();
						System.out.println("id = "+id);
				}
		   		*/
		   		
		   		// for Profile File 
		   		
	        	String profileImage = profileImg.getOriginalFilename();
	        	String profileImageArray[] = profileImage.split("\\.");
	        	
	        	profileImage = profileImageArray[0]+id+"."+profileImageArray[1]; 
		   		
	        	try
	        	{
	        		
	        		String path="C:/FrontEnd/gulfroad/gulfroad/src/assets/images/profileimage/";
	        		// String path=session.getServletContext().getRealPath("/thegulgrestapi/src/main/webapp/resources/uploadfiles");
	        		 
	    	        System.out.println("==========================="); 
	    	        System.out.println("==========================="); 
	    	        
	    	        String fillpath=path+""+profileImage;
	    	        System.out.println(fillpath);
	    	        System.out.println("==========================="); 
	    	        System.out.println("==========================="); 
	    	        
	    	        
	    	          
	    	        byte barr[] = profileImg.getBytes();  
	    	          
	    	        BufferedOutputStream bout=new BufferedOutputStream(  
	    	                 new FileOutputStream(fillpath));  
	    	        bout.write(barr);  
	    	        bout.flush();  
	    	        bout.close();
	    	       userprofile.setProfileImgName(profileImage);
	        		
	        	}
	        	catch(Exception e)
	        	{
	        		
	        		System.out.println("==========================="); 
	    	        System.out.println("==========================="); 
	    	        System.out.println("Run time Error "+ e);
	    	        System.out.println("==========================="); 
	    	        System.out.println("==========================="); 
	        		 
	        		
	        	}
	        	
	        	// for Profile File end
	        	
	        	
		   		
		   		userprofile.setDateTime(dateTime);
		   		
		
		   		byte restbyteproChooseFile[] =  chooseFile.getBytes();  
		   		userprofile.setChooseFile(BlobProxy.generateProxy(restbyteproChooseFile));
		
		   		

	        	String profileCV = chooseFile.getOriginalFilename();
	        	String profileCVArray[] = profileCV.split("\\.");
	        	
	        	profileCV = profileCVArray[0]+id+"."+profileCVArray[1]; 
		   		
	        	try
	        	{
	        		
	        		String path="C:/FrontEnd/gulfroad/gulfroad/src/assets/images/profilecv/";
	        		// String path=session.getServletContext().getRealPath("/thegulgrestapi/src/main/webapp/resources/uploadfiles");
	        		 
	    	        System.out.println("==========================="); 
	    	        System.out.println("==========================="); 
	    	        
	    	        String fillpath=path+""+profileCV;
	    	        System.out.println(fillpath);
	    	        System.out.println("==========================="); 
	    	        System.out.println("==========================="); 
	    	        
	    	        
	    	          
	    	        byte barr[] = chooseFile.getBytes();  
	    	          
	    	        BufferedOutputStream bout=new BufferedOutputStream(  
	    	                 new FileOutputStream(fillpath));  
	    	        bout.write(barr);  
	    	        bout.flush();  
	    	        bout.close();
	    	       userprofile.setCvFileName(profileCV);
	        		
	        	}
	        	catch(Exception e)
	        	{
	        		
	        		System.out.println("==========================="); 
	    	        System.out.println("==========================="); 
	    	        System.out.println("Run time Error "+ e);
	    	        System.out.println("==========================="); 
	    	        System.out.println("==========================="); 
	        		 
	        		
	        	}
	    
		   		
		   		userprofile.setEducation(education);
		   		userprofile.setYourCVsummary(yourCVsummary);

		   	
		   		userprofile.setiHavegot1(iHavegot1);
		   		userprofile.setExperienceIn1(experienceIn1);
		   	
		   		userprofile.setiHavegot2(iHavegot2);
		   		userprofile.setExperienceIn2(experienceIn2);
		   		
		   		
		   		
		   		
		   		
		   		userprofile.setiHavegot3(iHavegot3);
		   		userprofile.setExperienceIn3(experienceIn3);
		   		
		   	
		   		
		   		userprofile.setiHavegot4(iHavegot4);
		   		userprofile.setExperienceIn4(experienceIn4);
		   		
		   		
		   		userprofile.setiHavegot5(iHavegot5);
		   		userprofile.setExperienceIn5(experienceIn5);
		   		
		   		userprofile.setCheckBox1(checkBox1);
		   		userprofile.setCheckBox2(checkBox2);
		   		userprofile.setUserEmail(userEmail);
		   		
		   		
		   		
		   		
		   		
		   		
		   		UserProfileDetailsDAO dao = new UserProfileDetailsDAOImpl();
		   		
		   		boolean flag = dao.updateUserProfileDetails(userprofile);
		   		
		   
		   	System.out.println(userprofile);
		   	
		   
	    	return new ResponseEntity(flag,HttpStatus.OK);
		   	
		}
	  

	   


	

}
