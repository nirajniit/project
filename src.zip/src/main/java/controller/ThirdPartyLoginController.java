package controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken.Payload;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;


import dao.UserProfileDetailsDAO;
import daoimpl.UserProfileDetailsDAOImpl;
import model.UserProfileDetails;

@RestController 
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ThirdPartyLoginController {
	
	    @RequestMapping(value = "/thirdpartyloginapi")
		public ResponseEntity<List> thirdPartyLogin( ) 
	    {
	    	
	    		
	    	
	    	System.out.println("========================================================");
	    	System.out.println(" @RestAPI : thirdpartyloginapi By POST or GET Request ");
	    	System.out.println("=========================================================");

	    	
	    	
	      	return new ResponseEntity("done",HttpStatus.OK);
	  			
	    }


}
