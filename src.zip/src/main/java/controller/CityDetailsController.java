package controller;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import dao.CityDetailsDAO;
import daoimpl.CityDetailsDAOImpl;
import model.CityDetails;


@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class CityDetailsController
{
	@RequestMapping("/allcitydetails")public ResponseEntity <List> getAllCities()
	{
		System.out.println("================================");
		System.out.println("== allcitydetails : RestApi ====");
		System.out.println("================================");
		
		try
		{
		CityDetailsDAO cityDetailsDAO = new CityDetailsDAOImpl(); 
		List <CityDetails> cityDetails  =   cityDetailsDAO.getAllCities();
			if(null != cityDetails)
			{
				return new ResponseEntity(cityDetails, HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity(" City Not Found or some other reason", HttpStatus.OK);
			}
		}
		catch(Exception e)
		{
			return new ResponseEntity(e, HttpStatus.OK);
			
		}
	}

	
	@RequestMapping("/getcitybyid")ResponseEntity  <List>  getCityById(@RequestParam(value="cityId") String cityId )
	{
		System.out.println("================================");
		System.out.println("== getcitybyid : RestApi ====");
		System.out.println("================================");
	
		try
		{
			CityDetails cityDetails= new CityDetails();
			cityDetails.setCityId(cityId);
			
			
			
		CityDetailsDAO cityDetailsDAO = new CityDetailsDAOImpl(); 
		CityDetails currentcityDetails  =   cityDetailsDAO.getCityById(cityDetails);
		
			if(null != currentcityDetails)
			{
				return new ResponseEntity(currentcityDetails, HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity(" City Not Found or some other reason", HttpStatus.OK);
			}
		}
		catch(Exception e)
		{
			return new ResponseEntity(e, HttpStatus.OK);
			
		}
	}
	
	
	
	@RequestMapping("/getcitybycountryid")ResponseEntity  <List>  getCityBycountryid(@RequestParam(value="countryId") String countryId )
	{
		System.out.println("================================");
		System.out.println("== getcitybyid : RestApi ====");
		System.out.println("================================");
	
		try
		{
			CityDetails cityDetails= new CityDetails();
			cityDetails.setCountryId(countryId);
			
			
			
		CityDetailsDAO cityDetailsDAO = new CityDetailsDAOImpl(); 
		List <CityDetails> currentcityDetails  =   cityDetailsDAO.getAllCitiesByCountryID(cityDetails);
		
			if(null != currentcityDetails)
			{
				return new ResponseEntity(currentcityDetails, HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity(" City Not Found or some other reason", HttpStatus.OK);
			}
		}
		catch(Exception e)
		{
			return new ResponseEntity(e, HttpStatus.OK);
			
		}
	}
	
	
	
	
	
	
	
	@RequestMapping("/addcity")public ResponseEntity <List> addCity(@RequestParam(value="cityId") String cityId,@RequestParam(value="cityName")String cityName, @RequestParam (value="countryId") String countryId  )
	{
		System.out.println("================================");
		System.out.println("== addcity : RestApi ====");
		System.out.println("================================");
	
		try
		{
			CityDetails cityDetails = new CityDetails();
			cityDetails.setCityId(cityId);
			cityDetails.setCityName(cityName);
			cityDetails.setCountryId(countryId);
			CityDetailsDAO cityDetailsDAO = new CityDetailsDAOImpl();
		
			boolean flag = cityDetailsDAO.addCity(cityDetails);
			if( true == flag)
			{
				    JSONObject jj = new JSONObject();
		  			jj.put("data",cityDetails.getCityName() + " has added successfully in the database ");
		  			jj.put("data1","yes");
		  			List ll = new ArrayList();
		  			ll.add(jj);
	    			return new ResponseEntity<List>(ll,HttpStatus.OK);
			}
			else
			{
			    JSONObject jj = new JSONObject();
	  			jj.put("data",cityDetails.getCityName() + "  : or  "+cityDetails.getCityId() + " has not added  in the database : Might be allready exists. or country id is not available in the country table");
	  			jj.put("data1","no");
	  			List ll = new ArrayList();
	  			ll.add(jj);
    			return new ResponseEntity<List>(ll,HttpStatus.OK);
			}
		
		}
		catch(Exception e)
		{
     		    JSONObject jj = new JSONObject();
	  			jj.put("data",e.toString());
	  			List ll = new ArrayList();
	  			ll.add(jj);
    			return new ResponseEntity<List>(ll,HttpStatus.OK);
		}
	}
	
	@RequestMapping("/deletecitybyid")public ResponseEntity <List> deleteCity(@RequestParam (value="cityId") String cityId)  
	{
		System.out.println("================================");
		System.out.println("== deleteCity : RestApi ====");
		System.out.println("================================");
		
		try
		{
		
		CityDetails cityDetails = new CityDetails ();
		cityDetails.setCityId(cityId);
		CityDetailsDAO  cityDetailsDAO  = new CityDetailsDAOImpl();   
		
		boolean flag = cityDetailsDAO.deleteCity(cityDetails);
		
		if( true == flag)
		{
			JSONObject jj = new JSONObject();
  			jj.put("data",cityDetails.getCityId() + " has deleted successfully from the database ");
  			jj.put("data1","yes");
  			List ll = new ArrayList();
  			ll.add(jj);
			return new ResponseEntity<List>(ll,HttpStatus.OK);
		}
		else
		{
			JSONObject jj = new JSONObject();
  			jj.put("data",cityDetails.getCityId() + " has not deleted from the database might be city is not available or Product details depend on it !!!");
  			jj.put("data1","no");
  			List ll = new ArrayList();
  			ll.add(jj);
			return new ResponseEntity<List>(ll,HttpStatus.OK);
		}
		
  	}
	catch(Exception  e)
	{
			JSONObject jj = new JSONObject();
			jj.put("data",e.toString());
			List ll = new ArrayList();
			ll.add(jj);
		return new ResponseEntity<List>(ll,HttpStatus.OK);
	}
		
}
	

	
	@RequestMapping("/updatecity")
	public ResponseEntity <List> updateCity(@RequestParam(value="cityId") String cityId,@RequestParam(value="cityName") String cityName)
	{
		System.out.println("================================");
		System.out.println("== addcity : RestApi ====");
		System.out.println("================================");
		try
		{
			CityDetails cityDetails = new CityDetails();
			cityDetails.setCityId(cityId);
			cityDetails.setCityName(cityName);
			
			CityDetailsDAO cityDetailsDAO = new CityDetailsDAOImpl();
			
			boolean flag = cityDetailsDAO.updateCity(cityDetails);

			if( true == flag)
			{
				JSONObject jj = new JSONObject();
	  			jj.put("data",cityDetails.getCityName() + " has updated successfully in the database ");
	  			jj.put("data1","yes");
	  			List ll = new ArrayList();
	  			ll.add(jj);
    			return new ResponseEntity<List>(ll,HttpStatus.OK);
				
			}
			else
			{
				
				JSONObject jj = new JSONObject();
	  			jj.put("data",cityDetails.getCityName() + " has not updated  in the database. Might be "+cityDetails.getCityId() +" not available or "+ cityDetails.getCityName() + " all ready assigned to the other city id");
	  			jj.put("data1","no");
	  			List ll = new ArrayList();
	  			ll.add(jj);
    			return new ResponseEntity<List>(ll,HttpStatus.OK);
				
			}
		
		}
		catch(Exception e)
		{
			JSONObject jj = new JSONObject();
  			jj.put("data",e.toString());
  			List ll = new ArrayList();
  			ll.add(jj);
			return new ResponseEntity<List>(ll,HttpStatus.OK);
			
		}
	}

	
	
	
	
}
