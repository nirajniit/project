package controller;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import dao.ProductImageDetailsDAO;
import daoimpl.ProductImageDetailsDAOImpl;
import model.ProductImageDetails;


@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ProductImageDetailsController {
	
	
	@RequestMapping("/getallProductImageDetails")
	ResponseEntity <List>  getAllProductImageDetails()
	{
		
		
		
		
		
		System.out.println("==================================   ");
		System.out.println("     GET or POST : getAllProductImageDetails ");      
		System.out.println("==================================   ");
		try
		{
			ProductImageDetailsDAO productImageDetailsDAO = new ProductImageDetailsDAOImpl();
			List <ProductImageDetails> productImageDetails =productImageDetailsDAO.allProductImageDetails();
			
			
			System.out.println("Done");
			System.out.println(productImageDetails);
			
			if(null != productImageDetails)
			{
				
				 List ll = new ArrayList();
				
				for(ProductImageDetails c : productImageDetails)
				{
					
					try
					{
					
						System.out.println("===================");
						
						JSONObject jj = new JSONObject();
						
					  System.out.println("-------------"+c.getCatId());
					  jj.put("productImageId", c.getProductImageId());
					  jj.put("catId", c.getCatId());

					  
					  Object blob =  c.getByteCatImg1().getClass();  
					  String str = blob.toString();
					  jj.put("byteCatImg1",str.getBytes());
					  
					  
					  ll.add(jj);
					}
					catch(Exception e)
					{
		
						
						
					}
				}
				
				System.out.println(" ====================================== " );
				System.out.println(" IN IF  " );
				System.out.println(" ====================================== " );
				
				return new ResponseEntity <List>( ll,HttpStatus.OK);
			}
			else
			{
				
				
				return new ResponseEntity ("sdf" ,HttpStatus.OK);
			}
		
		}
		catch(Exception e)
		{
			return new ResponseEntity( e + " Run TError  ",HttpStatus.OK);
		}
	}


}
