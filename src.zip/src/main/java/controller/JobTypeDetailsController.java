package controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import dao.JobTypeDetailsDAO;
import daoimpl.JobTypeDetailsDAOImpl;
import model.JobTypeDetails;


@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class JobTypeDetailsController 
{
	@RequestMapping("/saveJobTypeDetails")
	public ResponseEntity saveJobTypeDetailsRest(@RequestParam(value="jobTypeId") String   jobTypeId , @RequestParam(value="jobType") String   jobType,@RequestParam(value="cityId") String   cityId)
	{
		try
		{
			JobTypeDetailsDAO jobTypeDetailsDAO=new JobTypeDetailsDAOImpl();
			JobTypeDetails jobTypeDetails  = new JobTypeDetails();
			
			jobTypeDetails.setJobTypeId(jobTypeId);
			jobTypeDetails.setJobType(jobType);
			jobTypeDetails.setCityId(cityId);
     		
			boolean flag = jobTypeDetailsDAO.saveJobTypeDetails(jobTypeDetails);
			if( flag == true)
			{
				return new ResponseEntity(jobTypeDetails + " Data added to the database ",HttpStatus.OK) ;
			}
			else
			{
				return new ResponseEntity(jobTypeDetails+"Data not added to the database ",HttpStatus.OK) ;
			}

		}
		catch(Exception e)
		{
			return new ResponseEntity(e,HttpStatus.INTERNAL_SERVER_ERROR) ;
		}
    }
	
	
	@RequestMapping("/getAllJobTypeDetails")
	public ResponseEntity getAllJobTypeDetailsRest()
	{
			try
			{
				JobTypeDetailsDAO jobTypeDetailsDAO = new JobTypeDetailsDAOImpl();
				List <JobTypeDetails> jobTypeDetails  = jobTypeDetailsDAO.getAllJobTypeDetails();
				if(jobTypeDetails != null)
				{
						return new ResponseEntity(jobTypeDetails, HttpStatus.OK);
				}
				else
				{
					return new ResponseEntity("data not found", HttpStatus.OK);
				}
			}
			catch(Exception e)
			{
				return new ResponseEntity(e, HttpStatus.OK);
			}
	}
	
	@RequestMapping("/updateJobTypeDetails")
	public ResponseEntity updateJobTypeDetailsRest(@RequestParam(value="jobTypeId") String   jobTypeId , @RequestParam(value="jobType") String   jobType,@RequestParam(value="cityId") String   cityId)
	{
		try
		{
			JobTypeDetailsDAO jobTypeDetailsDAO=new JobTypeDetailsDAOImpl();
			JobTypeDetails jobTypeDetails  = new JobTypeDetails();
			
			jobTypeDetails.setJobTypeId(jobTypeId);
			jobTypeDetails.setJobType(jobType);
			jobTypeDetails.setCityId(cityId);
     		
			boolean flag = jobTypeDetailsDAO.updateJobTypeDetails(jobTypeDetails);
			
			if( flag == true)
			{
				return new ResponseEntity(jobTypeDetails + " Data updated to the database ",HttpStatus.OK) ;
			}
			else
			{
				return new ResponseEntity(jobTypeDetails + " Data not updated to the database ",HttpStatus.OK) ;
			}

		}
		catch(Exception e)
		{
			return new ResponseEntity(e,HttpStatus.INTERNAL_SERVER_ERROR) ;
		}
    }


	
	@RequestMapping("/deleteJobTypeDetails")
	public ResponseEntity deleteJobTypeDetailsRest(@RequestParam(value="jobTypeId") String   jobTypeId)
	{
		try
		{
			JobTypeDetailsDAO jobTypeDetailsDAO=new JobTypeDetailsDAOImpl();
			JobTypeDetails jobTypeDetails  = new JobTypeDetails();
			jobTypeDetails.setJobTypeId(jobTypeId);
			boolean flag = jobTypeDetailsDAO.deleteJobTypeDetails(jobTypeDetails);
			if( flag == true)
			{
				return new ResponseEntity(jobTypeDetails + " Data deleted to the database ",HttpStatus.OK) ;
			}
			else
			{
				return new ResponseEntity(jobTypeDetails + " Data not deleted to the database ",HttpStatus.OK) ;
			}

		}
		catch(Exception e)
		{
			return new ResponseEntity(e,HttpStatus.INTERNAL_SERVER_ERROR) ;
		}
    }


	@RequestMapping("/getJobByTypeId")
	public ResponseEntity getJobByTypeIdRest(@RequestParam(value="jobTypeId") String   jobTypeId)
	{
		try
		{
			JobTypeDetailsDAO jobTypeDetailsDAO=new JobTypeDetailsDAOImpl();
			JobTypeDetails jobTypeDetails  = new JobTypeDetails();
			jobTypeDetails.setJobTypeId(jobTypeId);
			jobTypeDetails = jobTypeDetailsDAO.getJobByTypeId(jobTypeDetails);
			if( jobTypeDetails != null)
			{
				return new ResponseEntity(jobTypeDetails,HttpStatus.OK) ;
			}
			else
			{
				return new ResponseEntity( " Data not found in the database ",HttpStatus.OK) ;
			}
		}
		catch(Exception e)
		{
			return new ResponseEntity(e,HttpStatus.INTERNAL_SERVER_ERROR) ;
		}
    }
	
	

	@RequestMapping("/getJobByType")
	public ResponseEntity getJobByTypeRest(@RequestParam(value="jobType") String   jobType)
	{
		try
		{
			JobTypeDetailsDAO jobTypeDetailsDAO=new JobTypeDetailsDAOImpl();
			JobTypeDetails jobTypeDetails  = new JobTypeDetails();
			jobTypeDetails.setJobType(jobType);
			List <JobTypeDetails> currentjobTypeDetails = jobTypeDetailsDAO.getJobByType(jobTypeDetails);
			
			if( currentjobTypeDetails != null)
			{
				return new ResponseEntity(currentjobTypeDetails,HttpStatus.OK) ;
			}
			else
			{
				return new ResponseEntity( " Data not found in the database ",HttpStatus.OK) ;
			}
		}
		catch(Exception e)
		{
			return new ResponseEntity(e,HttpStatus.INTERNAL_SERVER_ERROR) ;
		}
    }
	
	
	
	
	
	
}
