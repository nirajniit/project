package controller;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.http.HttpServletRequest;
import org.hibernate.Hibernate;
import org.json.simple.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import dao.BlogDAO;
import dao.UserDetailsDAO;
import daoimpl.BlogDAOImpl;
import daoimpl.UserDetailsDAOImpl;
import model.Blog;
import model.UserDetails;

import java.util.*;
@RestController 
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class HomeController {

	 @RequestMapping(value="/")  
	    public String home()
	    {  
	    	System.out.println(" Middleware Controller is running");
	        return "home";
	    }  
		    
	    @RequestMapping(value = "/alluser")
		public ResponseEntity<List> getAllUser() 
	    {
	    	
	    	System.out.println("================================================");
	    	System.out.println(" @RestAPI : getAllUser By POST or GET Request ");
	    	System.out.println("================================================");

	    	UserDetailsDAO userDetailsDAO = new UserDetailsDAOImpl();
			List <UserDetails> userList = userDetailsDAO.getAllUserDetails();
			return new ResponseEntity(userList,HttpStatus.OK);
	    }
	 
	    
	    @PostMapping(value = "/getuserbyuseremail")
		public ResponseEntity<List> getuserbyuseremail(@RequestParam("userEmail") String userEmail ) 
	    {
	    	
	    	System.out.println("================================================ ");
	    	System.out.println(" @RestAPI : getuserbyuseremail By POST           ");
	    	System.out.println("================================================ ");

	    	UserDetails userDetails = new UserDetails();
	    	userDetails.setUserEmail(userEmail);
	    	UserDetailsDAO userDetailsDAO = new UserDetailsDAOImpl();
			UserDetails userList = userDetailsDAO.getUserDetailsByEmail(userDetails);
		
			
			return new ResponseEntity(userList,HttpStatus.OK);
		}
	    
	    
	 
	 @RequestMapping(value="/admin")  
	 public String privateHome()
	 {  
	        return "privatePage";  
	 }

	 /*
	   @RequestMapping(value = "/adduserraw",consumes = "APPLICATION_JSON_VALUE",produces = "APPLICATION_JSON_VALUE")
	   public ResponseEntity<List> addUserDetailsPostRaw(@RequestBody UserDetails userDetails)
	    {
		 
	    	System.out.println("================================================");
	    	System.out.println(" @RestAPI : addUserDetails By POST Request ");
	    	System.out.println("================================================");
	    	System.out.println("================================================");
	    	System.out.println("================================================");
	    	System.out.println("Updated 11111111111");
	    	System.out.println(userDetails.getUserEmail());
	    	System.out.println(userDetails.getUserName());
	    	System.out.println(userDetails.getUserPassword());
	    	System.out.println(userDetails.getUserAddress());
	    	
	    	
	    	System.out.println("================================================");
	    	System.out.println("================================================");
	    	System.out.println("================================================");
	    	
	 	    UserDetailsDAO userDetailsDAO = new UserDetailsDAOImpl(); 
	 	    boolean flag = userDetailsDAO.addUserDetails(userDetails);
	 	    
	 	    if(flag == true)
	 	    {
		    	return new ResponseEntity(userDetails,HttpStatus.OK);
	 	    }
	 	    else
	 	    {
				return new ResponseEntity(userDetails.getUserEmail() + " has already exists",HttpStatus.OK);
			 
	 	    }
	}
	  
	  
	*/  
	 
	 @RequestMapping(value = "/adduserraw", method = RequestMethod.POST,consumes = {"application/json"})
	   public ResponseEntity updateDisplay(@RequestBody UserDetails userDetails){

	      System.out.print(userDetails);
	      System.out.println("================================================");
	    	System.out.println(" @RestAPI : addUserDetails By POST Request ");
	    	System.out.println("================================================");
	    	System.out.println("================================================");
	    	System.out.println("================================================");
	    	System.out.println("Updated 11111111111");
	    	System.out.println(userDetails.getUserEmail());
	    	System.out.println(userDetails.getUserName());
	    	System.out.println(userDetails.getUserPassword());
	    	System.out.println(userDetails.getUserAddress());
	    	
	    	
	    	
	    	
	    	
	    	System.out.println("================================================");
	    	System.out.println("================================================");
	    	System.out.println("================================================");
	    	
	    	
	    	
	    	
	    
	    	/*
	    	System.out.println(userEmail);
	    	System.out.println(userPassword);
	 	    UserDetails userDetails = new UserDetails();
	 	   
	 	   userDetails.setUserEmail(userEmail);
	 	   userDetails.setUserPassword(userPassword);
	 	   userDetails.setUserName(userName);
	 	   userDetails.setUserMobile(userMobile);
	 	   userDetails.setUserAddress(userAddress);
	 	   */
	    	
	    	
	    	
	 	    UserDetailsDAO userDetailsDAO = new UserDetailsDAOImpl(); 
	 	    boolean flag = userDetailsDAO.addUserDetails(userDetails);
	 	    
	 	    if(flag == true)
	 	    {
		    	return new ResponseEntity("data added successfully",HttpStatus.OK);
	 	    }
	 	    else
	 	    {
				return new ResponseEntity(userDetails.getUserEmail() + " has already exists",HttpStatus.OK);
			 
	 	    }
	   }
	 
	  
	 
	 
	 @PostMapping(value = "/adduser")
	//	public ResponseEntity<List> addUserDetailsPost(@RequestParam("userEmail") String userEmail,@RequestParam("userPassword") String userPassword,@RequestParam("userName") String userName,@RequestParam("userMobile") String userMobile,@RequestParam("userAddress") String userAddress, Model m) 
		public ResponseEntity<List> addUserDetailsPost(UserDetails userDetails)
	    {
		 try
		 {
		 
	    	System.out.println("================================================");
	    	System.out.println(" @RestAPI : addUserDetails By POST niraj  ddd  Request ");
	    	System.out.println("================================================");
	    	System.out.println("================================================");
	    	System.out.println("================================================");
	    	System.out.println(" 11111111111");
	    	System.out.println(userDetails.getUserEmail().trim());
	    	System.out.println(userDetails.getUserName().trim());
	    	System.out.println(userDetails.getUserPassword().trim());
	    	System.out.println(userDetails.getUserAddress().trim());
	    	
	    	
	    	
	    	
	    	
	 	    UserDetailsDAO userDetailsDAO = new UserDetailsDAOImpl(); 
	 	   
	 	   boolean flag=false;
	 	   
	 	    
	 	    
	 	    UserDetails curruserDetails =  new UserDetails();
	 	    System.out.println(" incoming email "+ userDetails.getUserEmail());
	 	    
	 	   curruserDetails.setUserEmail(userDetails.getUserEmail());
	 	   
	 	  curruserDetails = userDetailsDAO.getUserDetailsByEmail(curruserDetails);
	 	 System.out.println(" incoming email "+ userDetails.getUserEmail());
	 	  
	 	  

	 	  
	 	  if(curruserDetails != null)
	 	  {
	 		  	JSONObject jj = new JSONObject();
	 		  	
	 	    	jj.put("data","nsuccess");
	 	    	List ll = new ArrayList();
	 	    	ll.add(jj);
	 	    	
	 	    	System.out.println(" ================================= ");
	 	    	System.out.println(" Rest Controller :  Email already in the database ");
	 	    	System.out.println(" ================================= ");
	 	    	
				return new ResponseEntity<List>(ll,HttpStatus.OK);
  		  
	 	  }
	 	  
	 	  
	 	  boolean fff=false;
	 	 System.out.println("   ===========================   ");
	 	   System.out.println("   ======ww222222222222222222222222222222222222222222=====================   ");
	 	   System.out.println("   ===========================   ");
	 	   
	 	  
	 	  Mailer mail  = new Mailer();
	 	     fff = mail.sendMail(userDetails.getUserEmail(),userDetails.getUserName(),userDetails.getUserMobile());
	 	     
	 	
	 	     
	 	     
	 	    System.out.println("   ===========================   ");
	 	    
	 	    
	 	   System.out.println("   Mailer Confirmation    "+ fff); 
	 	   System.out.println("   ======eeeeeeeeeeeee=====================   ");
	 	   System.out.println("   ===========================   ");
	 	     
	 	    if(fff == true)
	 	    {
	 	    			flag = userDetailsDAO.addUserDetails(userDetails);
	 	    			System.out.println(" ================================= ");
	 	    	    	System.out.println(" Valid   Email   flag  " + flag);
	 	    	    	System.out.println(" ================================= ");
	 	    	    	JSONObject jj = new JSONObject();

	 		 	    	jj.put("data","success");
	 		 	    	List ll = new ArrayList();
	 		 	    	ll.add(jj);
	 		 	    
	 		 	       	return new ResponseEntity<List>(ll,HttpStatus.OK);

	 	    }
	 	    else
	 	    {
	 	    	 flag= false;
	 	    	 JSONObject jj = new JSONObject();
	 	    	 jj.put("data","invalidmail");
	 	        List ll = new ArrayList();
	 	    	ll.add(jj);

	 	    	
				return new ResponseEntity<List>(ll,HttpStatus.OK);
			 
	 	    }
	 	  
		 }
		 catch(Exception e)
		 {
				System.out.println(" ================================= ");
	 	    	System.out.println(" Rest Controller :  Runtime error  ");
	 	    	System.out.println(" ================================= ");
			 return new ResponseEntity( e,HttpStatus.INTERNAL_SERVER_ERROR);
			 
		 }
	}
	 
    @PostMapping(value = "/deleteuser")
	public ResponseEntity<List> deleteUserDetails(@RequestParam("userEmail") String userEmail,Model m) 
	{
	    try
	    {
    	
	    	System.out.println("================================================");
	    	System.out.println(" @RestAPI : deleteuser By POST Request  ");
	    	System.out.println("================================================");

	    	UserDetails  userDetails = new UserDetails();
	    	userDetails.setUserEmail(userEmail);
	    	
	    	UserDetailsDAO userDetailsDAO  = new  UserDetailsDAOImpl();
	    	boolean flag  =  userDetailsDAO.deleteUserDetails(userDetails);
	    	
	    	if(flag != false)
	    	{

	    		JSONObject jj = new JSONObject();
	 	    	jj.put("data",userDetails.getUserEmail()+" has  deleted successfully");
	 	    	jj.put("data1","deleted");
	 	    	List ll = new ArrayList();
	 	    	ll.add(jj);

	 	    	
				return new ResponseEntity<List>(ll,HttpStatus.OK);
      	    	
	    	}
	    	else
	    	{
	    		JSONObject jj = new JSONObject();
	 	    	jj.put("data",userDetails.getUserEmail() + " has  not deleted successfully - Might be other details depend on it ");
	 	    	jj.put("data1","notdeleted");
	 	    	List ll = new ArrayList();
	 	    	ll.add(jj);
	 	    	
				return new ResponseEntity<List>(ll,HttpStatus.OK);
	    	}

	    }
	    catch(Exception e)
	    {
	    	JSONObject jj = new JSONObject();
 	    	jj.put("data",e.toString());
 	    	List ll = new ArrayList();
 	    	ll.add(jj);

 	    	
			return new ResponseEntity<List>(ll,HttpStatus.INTERNAL_SERVER_ERROR);

	    	
	    	
	    }
	}


     @PostMapping(value = "/updateuser")
	// public ResponseEntity<List> updateUserDetails(@RequestParam("userEmail") String userEmail,@RequestParam("userPassword") String userPassword,@RequestParam("userName") String userName,@RequestParam("userMobile") String userMobile,@RequestParam("userAddress") String userAddress)
     public ResponseEntity<List> updateUserDetailsPost(UserDetails userDetails)
	 {
	    	//UserDetails  userDetails = new UserDetails();
	   
    	 try
    	 {
	    	System.out.println("================================================");
	    	System.out.println(" @RestAPI : deleteuser By POST Request ");
	    	System.out.println("================================================");

	    	/*
	    		userDetails.setUserEmail(userEmail);
	    		userDetails.setUserPassword(userPassword);
	    		userDetails.setUserName(userName);
	    		userDetails.setUserMobile(userMobile);
	    		userDetails.setUserAddress(userAddress);
	    	*/
	    	
	    	
	    	UserDetailsDAO userDetailsDAO  = new  UserDetailsDAOImpl();
	   		boolean flag = userDetailsDAO.updateUserDetails(userDetails);
	    	
	    	if(flag == true)
	    	{
	    		JSONObject jj = new JSONObject();

	 	    	jj.put("data",userDetails.getUserEmail()+" has updated successfully ");
	 	    	List ll = new ArrayList();
	 	    	ll.add(jj);
	    		return new ResponseEntity <List> (ll,HttpStatus.OK);
	    	}
	    	else
	    	{
	    		JSONObject jj = new JSONObject();

	 	    	jj.put("data",userDetails.getUserEmail()+" not has updated successfully ");
	 	    	List ll = new ArrayList();
	 	    	ll.add(jj);

	    		return new ResponseEntity<List>(ll,HttpStatus.ALREADY_REPORTED);
	    	}
	    		    	
    	 }
    	 catch(Exception e)
    	 {
    		 JSONObject jj = new JSONObject();
  	    	jj.put("data",e.toString());
  	    	List ll = new ArrayList();
  	    	ll.add(jj);

  	    	
 			return new ResponseEntity<List>(ll,HttpStatus.INTERNAL_SERVER_ERROR);
	    	
    	 }
	}
	 @RequestMapping(value = "/validateuser")
		public ResponseEntity<List> validateUserDetails(@RequestParam("userEmail") String userEmail , @RequestParam("userPassword") String userPassword) {
	    	
	    	System.out.println("================================================");
	    	System.out.println(" @RestAPI : validateuser By POST Request ");
	    	System.out.println("================================================");
	    
	    	
	    	UserDetails user = new UserDetails();
	    	user.setUserEmail(userEmail.trim());
	    	user.setUserPassword(userPassword.trim());
	    	
	    	
	    	System.out.println(user);
	    	
	    	
	    	UserDetailsDAO userDetailsDAO  = new  UserDetailsDAOImpl();
	    	UserDetails userdetails = userDetailsDAO.validateUserDetails(user);
	    	
	    	
	    	if(userdetails != null)
	    	{
	    			System.out.println(" Valid user ");
	    			
	    		
	    		
	    	}
	    	else
	    	{
	    		
	    		System.out.println("Not  Valid user ");
	    	}
	    	
	    	
	    	return new ResponseEntity("Wiat : Developer is working  on It :  validateuser ",HttpStatus.OK);
		}
}






