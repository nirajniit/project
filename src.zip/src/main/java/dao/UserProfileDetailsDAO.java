package dao;

import java.util.List;

import model.UserProfileDetails;

public interface UserProfileDetailsDAO {
	

	public List<UserProfileDetails> getUserProfileDetails();
	public boolean saveUserProfileDetails(UserProfileDetails profile);
	public boolean updateUserProfileDetails(UserProfileDetails profile);
	public boolean deleteUserProfileDetails(UserProfileDetails profile);
	public UserProfileDetails getProfileById(UserProfileDetails profile);
	public List<UserProfileDetails>getProfileByEmailId(UserProfileDetails profile);

}
