package dao;

import java.util.List;

import model.Blog;


public interface BlogDAO 
	{
		public List<Blog> getAllBlog();
		public boolean save(Blog blog );
		public boolean update(Blog blog);
		public boolean delete(Blog blog);
		public Blog getBlogByID(int id);
		public List<Blog> getBlogByName(String name);
	}


