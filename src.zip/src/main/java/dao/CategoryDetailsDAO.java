package dao;

import java.util.List;

import model.CategoryDetails;
import model.ProductDetails;

public interface CategoryDetailsDAO {
	
	
	public boolean addCategory(CategoryDetails cat);
	public boolean deleteCategory(CategoryDetails cat);
	public boolean updateCategory(CategoryDetails cat);
	public List <CategoryDetails> getAllCategory();
	public List <CategoryDetails> getCategoryByPrice(CategoryDetails cat);	
	public List <CategoryDetails> getCategoryByName(CategoryDetails cat);
	public CategoryDetails getCategoryById(CategoryDetails cat);
	public List <CategoryDetails> getCategoryProcutById(CategoryDetails cat);
	
	public List <CategoryDetails> getCategoryProcutApproved(CategoryDetails cat);
	public List <CategoryDetails> getCategoryProcutApprovedandCountryID(CategoryDetails cat);
	public List <CategoryDetails> getCategoryProcutRating(CategoryDetails cat);
	
	public List <CategoryDetails> getCategoryProcutCountryId(CategoryDetails cat);
	
	public List <CategoryDetails> getAllCategoryForImage();
	
}
