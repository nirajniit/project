package dao;

import java.util.List;

import model.SubcategoryDetails;

public interface SubcategoryDetailsDAO {

	
	public boolean addSubcategoryDetails(SubcategoryDetails subcategory);
	public boolean deleteSubcategoryDetails(SubcategoryDetails subcategory);
	public boolean updateSubcategoryDetails(SubcategoryDetails subcategory);	
	public List <SubcategoryDetails> getAllSubcategoryDetails();	
	public SubcategoryDetails getSubcategoryDetailsById(SubcategoryDetails subcategory);
	public List <SubcategoryDetails> getSubcategoryDetailsByMainCatId (SubcategoryDetails subcategory);
	
	
}
