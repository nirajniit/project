package dao;
import java.util.List;
import model.UserDetails;
public interface UserDetailsDAO {
	
	public boolean addUserDetails(UserDetails user);
	public boolean deleteUserDetails(UserDetails user);
	public boolean updateUserDetails(UserDetails user);
	public List<UserDetails> getAllUserDetails();
	public UserDetails getUserDetailsByEmail(UserDetails user);
	public UserDetails validateUserDetails (UserDetails user);
	
	public UserDetails setActive(UserDetails user);
	public UserDetails setBlock(UserDetails user);
	public UserDetails setStatus(UserDetails user);
	public UserDetails setRole(UserDetails user);
	
	
}
