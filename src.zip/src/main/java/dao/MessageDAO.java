package dao;

import java.util.List;

import model.Message;

public interface MessageDAO 
{

	public boolean addMessage(Message message);
	public boolean deleteMessageFrom(Message message);
	public boolean deleteMessageTo(Message message);
	public List <Message> getAllMessage();
	public List <Message>getAllMessageFrom(Message message);
	public List <Message> getAllMessageTo(Message message);

	
}
