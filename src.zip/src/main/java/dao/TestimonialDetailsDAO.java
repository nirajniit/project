package dao;

import java.util.List;

import model.TestimonialDetails;

public interface TestimonialDetailsDAO {
	
	
	public boolean addTestimonial(TestimonialDetails testimonial);
	public boolean deleteTestimonial(TestimonialDetails testimonial);
	public boolean updateTestimonial(TestimonialDetails testimonial);
	public boolean updateTestimonialShow(TestimonialDetails testimonial);
	public List<TestimonialDetails> getTestimonialByEmail(TestimonialDetails testimonial);
	public List <TestimonialDetails> getAllTestimonial();
    public List <TestimonialDetails> getTestimonialByStatus (TestimonialDetails testimonial);
	public TestimonialDetails getTestimonialById(TestimonialDetails testimonial);
	
	
	public List<TestimonialDetails> getTestimonialByApproved(TestimonialDetails testimonial);
	public List<TestimonialDetails> getTestimonialByRating(TestimonialDetails testimonial);

}
