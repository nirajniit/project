package dao;

import model.EmailSender;

public interface EmailSenderDAO {

	public boolean sendEmail(EmailSender emailSender);
	public boolean resetPassword(EmailSender emailSender);
	public boolean forgotEmail(EmailSender emailSender);
	
	
}
