package dao;

import java.util.List;

import model.CityDetails;
import model.CountryDetails;

public interface CityDetailsDAO {
	

	public boolean addCity(CityDetails citydetail);
	public boolean deleteCity(CityDetails citydetail);
	public boolean updateCity(CityDetails citydetail);
	public List <CityDetails> getAllCities();
	public CityDetails getCityById(CityDetails citydetail);
	public CityDetails getCityByName(CityDetails citydetail);
	public List <CityDetails> getAllCitiesByCountryID(CityDetails citydetail);
	
}
