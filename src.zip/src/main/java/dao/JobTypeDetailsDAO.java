package dao;

import java.util.List;

import model.JobTypeDetails;

public interface JobTypeDetailsDAO {

	public List<JobTypeDetails> getAllJobTypeDetails();
	public boolean saveJobTypeDetails(JobTypeDetails job);
	public boolean updateJobTypeDetails(JobTypeDetails job);
	public boolean deleteJobTypeDetails(JobTypeDetails job);
	public JobTypeDetails getJobByTypeId(JobTypeDetails job);
	public List<JobTypeDetails> getJobByType(JobTypeDetails job);
}
