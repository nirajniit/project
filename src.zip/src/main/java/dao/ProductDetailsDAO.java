package dao;

import java.util.List;

import model.ProductDetails;

public interface ProductDetailsDAO {
	
	public boolean addProduct(ProductDetails prd);
	public boolean deleteProduct(ProductDetails prd);
	public boolean updateProduct(ProductDetails prd);
	public List <ProductDetails> getAllProduct();
	
	public List <ProductDetails> getProductByName(ProductDetails prd);
	public List <ProductDetails> getProductByCityId(ProductDetails prd);
	
	public ProductDetails getProductById(ProductDetails prd);
	
	
}
