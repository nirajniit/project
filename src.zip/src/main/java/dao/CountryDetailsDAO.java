package dao;

import java.util.List;

import model.CountryDetails;

public interface CountryDetailsDAO {
	
	public boolean addCountry(CountryDetails countryDetails);
	
	public boolean deleteCountrybyId(CountryDetails countryDetails);
	public boolean updateCountry(CountryDetails countryDetails);
	public List <CountryDetails> getallCountries();
	public CountryDetails getCountrybyName(CountryDetails countryDetails);
	public CountryDetails getCountrybyId(CountryDetails countryDetails);

}
