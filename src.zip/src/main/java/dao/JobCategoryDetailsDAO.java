package dao;

import java.util.List;

import model.JobCategoryDetails;
import model.JobTypeDetails;

public interface JobCategoryDetailsDAO 
{
	public List<JobCategoryDetails> getAllJobDetails();
	public boolean saveJobCategoryDetails(JobCategoryDetails job);
	public boolean updateJobCategoryDetails(JobCategoryDetails job);
	public boolean deleteJobCategoryDetails(JobCategoryDetails job);
	public JobCategoryDetails getJobByID(JobCategoryDetails job);
	public List<JobCategoryDetails> getJobByTitle(JobCategoryDetails job);
	public List<JobCategoryDetails>getJobTypeId(JobCategoryDetails job);
	
  }
