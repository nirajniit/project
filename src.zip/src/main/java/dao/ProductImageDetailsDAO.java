package dao;
import java.util.List;

import model.ProductImageDetails;

public interface ProductImageDetailsDAO {
	public boolean addProductImageDetails(ProductImageDetails productImageDetails);
	public boolean deleteProductImageDetails(ProductImageDetails productImageDetails);
	public boolean updateProductImageDetails(ProductImageDetails productImageDetails);
	public List <ProductImageDetails> allProductImageDetails();
	public ProductImageDetails getProductImageDetailsByproductImageId(ProductImageDetails productImageDetails);
	public List <ProductImageDetails> getProductImageDetailsBycatID(ProductImageDetails productImageDetails);
	
}
