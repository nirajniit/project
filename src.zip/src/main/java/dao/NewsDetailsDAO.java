package dao;

import java.util.List;

import model.NewsDetails;

public interface NewsDetailsDAO {
	
	public boolean addNews(NewsDetails news);
	public boolean deleteNews(NewsDetails news);
	public boolean updateNews(NewsDetails news);
	public List <NewsDetails> getAllNews();
    public List <NewsDetails> getNewsByTitle(NewsDetails news);
	public NewsDetails getNewsById(NewsDetails news);
	public List <NewsDetails> getNewsByApproved(NewsDetails news);
	public List <NewsDetails> getNewsByRating(NewsDetails news);
	
}
