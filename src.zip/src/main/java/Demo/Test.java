package Demo;

import dao.EmailSenderDAO;
import daoimpl.EmailSenderDAOImpl;
import model.EmailSender;

public class Test {

	public static void main(String[] args) {
		System.out.println("hi 1111111111111111");
				
	}

}
