package model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table
public class CityDetails {

	@Id
	private String cityId;
	
	@Column(unique = true)
	private String cityName;
	private String countryId;
	
	

	/*@OneToMany(cascade = CascadeType.MERGE,fetch=FetchType.EAGER,mappedBy="cityId")
	//@JoinColumn(name="cityId")
	
	List <ProductDetails> productdetails;
	public List<ProductDetails> getProductdetails() {
		return productdetails;
	}
	public void setProductdetails(List<ProductDetails> productdetails) {
		this.productdetails = productdetails;
	}*/

	

	@OneToMany(cascade = CascadeType.MERGE, fetch=FetchType.EAGER, mappedBy="cityId")
	List <JobTypeDetails> jobTypeDetails;
	public List<JobTypeDetails> getJobTypeDetails() {
		return jobTypeDetails;
	}
	public void setJobTypeDetails(List<JobTypeDetails> jobTypeDetails) {
		this.jobTypeDetails = jobTypeDetails;
	}
	
	
	
	
	
	public String getCountryId() {
		return countryId;
	}
	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}


	
	
	
	public String getCityId() {
		return cityId;
	}
	public void setCityId(String cityId) {
		this.cityId = cityId;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String city_name) {
		
		this.cityName = city_name;
		
	}

	
	public String toString()
	{
		return     " \n City Id  " +  cityId + " City Name   " +  cityName;
		 
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
