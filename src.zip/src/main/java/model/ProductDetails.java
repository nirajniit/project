package model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table
public class ProductDetails {

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "productID", updatable = false, nullable = false)
	private Long productID;
	 
	private String productType;
	private String cityId;
	private String rrating;
	public String getRrating() {
		return rrating;
	}
	public void setRrating(String rrating) {
		this.rrating = rrating;
	}
	public String getApproved() {
		return approved;
	}
	public void setApproved(String approved) {
		this.approved = approved;
	}

	private String approved;
	
	
	
	
	@OneToMany(cascade = CascadeType.MERGE,fetch=FetchType.EAGER,mappedBy="productID")
	//@JoinColumn(name="productID") 
	List <SubcategoryDetails> subcategoryDetails;
	
	public List<SubcategoryDetails> getSubcategoryDetails() {
		return subcategoryDetails;
	}
	public void setSubcategoryDetails(List<SubcategoryDetails> subcategoryDetails) {
		this.subcategoryDetails = subcategoryDetails;
	}
	
	
	
	
	
	

	@OneToMany(cascade = CascadeType.MERGE,fetch=FetchType.EAGER,mappedBy="productID")
	//@JoinColumn(name="productID") 
	List <CategoryDetails> categorydetails;
	
	public Long getProductID() {
		return productID;
	}
	public void setProductID(Long productID) {
		this.productID = productID;
	}
	public String getCityId() {
		return cityId;
	}
	public void setCityId(String cityId) {
		this.cityId = cityId;
	}
	public List<CategoryDetails> getCategorydetails() {
		return categorydetails;
	}
	public void setCategorydetails(List<CategoryDetails> categorydetails) {
		this.categorydetails = categorydetails;
	}

	public String getProductType() {
		return productType;
	}


	public void setProductType(String productType) {
		this.productType = productType;
	}

	

	public String toString()
	{
		return "  \n ProductID : " + productID + " \n ProductName : " + productType + " City Id " + cityId ;
		
	}
	
}
