package model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table
public class SubcategoryDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "subCategoryId", updatable = false, nullable = false)
	private Long subCategoryId;
	
	private String subCategoryName;
	private String dateTime;
	private Long catId;
	private Long productID;
	

	
	
	



	public Long getProductID() {
		return productID;
	}



	public void setProductID(Long productID) {
		this.productID = productID;
	}



	public Long getCatId() {
		return catId;
	}



	public void setCatId(Long catId) {
		this.catId = catId;
	}



	public Long getSubCategoryId() {
		return subCategoryId;
	}



	public void setSubCategoryId(Long subCategoryId) {
		this.subCategoryId = subCategoryId;
	}


	public String getSubCategoryName() {
		return subCategoryName;
	}

	public void setSubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public String toString()
	{
		return " SubCategoryId = " + subCategoryId + " \n subcategoryName = " + subCategoryName + "\n DateTime = " + dateTime;
	}
	
}
