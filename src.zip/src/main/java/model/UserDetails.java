package model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.FetchMode;
import org.hibernate.annotations.Fetch;

@Entity  
@Table   
public class UserDetails 
{
	@Id 
	private String userEmail;
	private String userPassword;
	private String userName;
	private String userMobile;
	private String userAddress;
	private String userRole;
	private String userStatus;
	private String userActive;
	private String userBlock;
	
	@OneToMany(fetch=FetchType.EAGER,mappedBy="userEmail")
	private List<Blog> blogs;  
	
	public List<Blog> getBlogs() {
		return blogs;
	}
	public void setBlogs(List<Blog> blogs) {
		this.blogs = blogs;
	}
	@OneToMany(fetch=FetchType.EAGER,mappedBy="userEmail")
	private List<NewsDetails> newsDetails;
	
	public List<NewsDetails> getNewsDetails() {
		return newsDetails;
	}
	public void setNewsDetails(List<NewsDetails> newsDetails) {
		this.newsDetails = newsDetails;
	}
	@OneToMany(fetch=FetchType.EAGER,mappedBy="userEmail")
	private List<TestimonialDetails> testimonialDetails;
	
	public List<TestimonialDetails> getTestimonialDetails() {
		return testimonialDetails;
	}
	public void setTestimonialDetails(List<TestimonialDetails> testimonialDetails) {
		this.testimonialDetails = testimonialDetails;
	}
	
	
	public String getUserActive() {
		return userActive;
	}
	public void setUserActive(String userActive) {
		this.userActive = userActive;
	}
	public String getUserBlock() {
		return userBlock;
	}
	public void setUserBlock(String userBlock) {
		this.userBlock = userBlock;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserMobile() {
		return userMobile;
	}
	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}
	public String getUserAddress() {
		return userAddress;
	}
	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public String getUserStatus() {
		return userStatus;
	}
	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}
	
	public String toString()
	{
		
		return  " \n userEmail  " + userEmail+ " \n  userPassword " + userPassword + " \n userName "
		+ userName + "  \n  userMobile " + userMobile + " \n  userAddress  " + userAddress + " \n  userRole " + userRole
		+ " \n userStatus " + userStatus + " \n  userActive " + userActive + " userBlock " + userBlock+ " \n "+ this.blogs ;
		 
		
	}
	
	
	

}
