package model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;
import javax.persistence.Table;

@Entity
@Table
public class CountryDetails {

	
	@Id
	private String countryId;
	@Column(unique = true)
	private String countryName;
	
	@OneToMany(cascade = CascadeType.MERGE,fetch=FetchType.EAGER,mappedBy="countryId")
	//@JoinColumn(name="countryId") 
	
	List <CityDetails> citydetails;
	public List<CityDetails> getCitydetails() {
		return citydetails;
	}
	public void setCitydetails(List<CityDetails> citydetails) {
		this.citydetails = citydetails;
	}
	
	public String getCountryId() {
		return countryId;
	}

	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	
	public String toString()
	{
		
		return      " Country ID "+ countryId + " Country Name " + countryName;
		 
	}
	
}
