package model;


import java.sql.Blob;
import java.util.Base64;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table

public class CategoryDetails {

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "catId", updatable = false, nullable = false)
	private Long catId;
	private String catName;
	private String catImg;
	private double catPrice;
	private String catDscription;
	private Long productID;
	private String rrating;
	private String approved;
	private String countryID;
	private String creditBY;
	private String cityID;
	
	
	
	
	public String getCreditBY() {
		return creditBY;
	}




	public void setCreditBY(String creditBY) {
		this.creditBY = creditBY;
	}




	public String getCountryID() {
		return countryID;
	}




	public void setCountryID(String countryID) {
		this.countryID = countryID;
	}




	public String getCityID() {
		return cityID;
	}




	public void setCityID(String cityID) {
		this.cityID = cityID;
	}






	
	
	
	public String getRrating() {
		return rrating;
	}




	public void setRrating(String rrating) {
		this.rrating = rrating;
	}




	public String getApproved() {
		return approved;
	}




	public void setApproved(String approved) {
		this.approved = approved;
	}






	
	

	//@JsonIgnoreProperties(value = "CategoryDetails")
	/*@JsonIgnore
	 
	private Blob byteCatImg;
	
	
	 
    public Blob getByteCatImg() {
		return byteCatImg;
		
	}

	 


	public void setByteCatImg(Blob byteCatImg) {
		this.byteCatImg = byteCatImg;
	}

*/




	public Long getCatId() {
		return catId;
	}






	public void setCatId(Long catId) {
		this.catId = catId;
	}






	public String getCatName() {
		return catName;
	}






	public void setCatName(String catName) {
		this.catName = catName;
	}






	public String getCatImg() {
		return catImg;
	}






	public void setCatImg(String catImg) {
		this.catImg = catImg;
	}






	public double getCatPrice() {
		return catPrice;
	}






	public void setCatPrice(double catPrice) {
		this.catPrice = catPrice;
	}






	public String getCatDscription() {
		return catDscription;
	}






	public void setCatDscription(String catDscription) {
		this.catDscription = catDscription;
	}


	public Long getProductID() {
		return productID;
	}






	public void setProductID(Long productID) {
		this.productID = productID;
	}



	
	

	public String toString()
	{
		
		return "\n Category ID : "+ catId +"  \n Category Name  :  "+  catName +  " \n Category Image " + catImg + " \n Category Price : " + catPrice + " \n Category Dscription : " + catDscription+ " \n Country ID : " + countryID+" \n City ID : " + cityID + " \n Credit By : " + creditBY + " \n Category Approved : " + approved + " \n Category Rating : " + rrating + " \n productID " + productID; 	 
	}


	
	
}
