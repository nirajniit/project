package model;

import java.sql.Blob;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table
public class ProductImageDetails 
{
		
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	//@Column(name = "productImageId", updatable = false, nullable = false)
	
	private Long productImageId;
	private Long catId;
	
	@JsonIgnore
	private Blob byteCatImg1;
	
	@JsonIgnore
	private Blob byteCatImg2;
	
	@JsonIgnore
	private Blob byteCatImg3;
	
	@JsonIgnore
	private Blob byteCatImg4;
	
	
	@JsonIgnore
	private Blob byteCatImg5;
	
	private String imageVideoUrl;
	
	
	public Long getProductImageId() {
		return productImageId;
	}

	public void setProductImageId(Long productImageId) {
		this.productImageId = productImageId;
	}

	public Long getCatId() {
		return catId;
	}

	public void setCatId(Long catId) {
		this.catId = catId;
	}

	public Blob getByteCatImg1() {
		return byteCatImg1;
	}

	public void setByteCatImg1(Blob byteCatImg1) {
		this.byteCatImg1 = byteCatImg1;
	}

	public Blob getByteCatImg2() {
		return byteCatImg2;
	}

	public void setByteCatImg2(Blob byteCatImg2) {
		this.byteCatImg2 = byteCatImg2;
	}

	public Blob getByteCatImg3() {
		return byteCatImg3;
	}

	public void setByteCatImg3(Blob byteCatImg3) {
		this.byteCatImg3 = byteCatImg3;
	}

	public Blob getByteCatImg4() 
	{
		return byteCatImg4;
	}

	public void setByteCatImg4(Blob byteCatImg4) {
		this.byteCatImg4 = byteCatImg4;
	}

	public Blob getByteCatImg5() {
		return byteCatImg5;
	}

	public void setByteCatImg5(Blob byteCatImg5) {
		this.byteCatImg5 = byteCatImg5;
	}

	public String getImageVideoUrl() {
		return imageVideoUrl;
	}

	public void setImageVideoUrl(String imageVideoUrl) {
		this.imageVideoUrl = imageVideoUrl;
	}
	
	public String toString()
	{
	  return " productImageId  " + this.getProductImageId() + " catId " + this.getCatId() +  " byteCatImg1 "+ this.getByteCatImg1() + " byteCatImg2 "+ this.getByteCatImg2() + " byteCatImg3 " + this.getByteCatImg3() + " byteCatImg4 " + this.getByteCatImg4() + " byteCatImg5 "+ byteCatImg5 + " imageVideoUrl "+ this.getImageVideoUrl();
	}
	
	
}
