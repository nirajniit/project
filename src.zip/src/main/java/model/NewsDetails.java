package model;

import java.sql.Blob;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table
public class NewsDetails {

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int newsId;
	private String newsTitle;
    private String newsContent;
	private String newsAuthor;
	private String newsDate;
	
	
	//@JsonIgnore
	//private Blob newsImage;
	private String newsImagenamne;
	private String approved;
	
	
	public String getApproved() {
		return approved;
	}



	public void setApproved(String approved) {
		this.approved = approved;
	}



	public String getRrating() {
		return rrating;
	}



	public void setRrating(String rrating) {
		this.rrating = rrating;
	}

	private String rrating;
	
	
	
    public String getNewsImagenamne() {
		return newsImagenamne;
	}



	public void setNewsImagenamne(String newsImagenamne) {
		this.newsImagenamne = newsImagenamne;
	}

	private String userEmail;
       
   

   public int getNewsId() {
		return newsId;
	}



	public void setNewsId(int newsId) {
		this.newsId = newsId;
	}



	public String getNewsTitle() {
		return newsTitle;
	}



	public void setNewsTitle(String newsTitle) {
		this.newsTitle = newsTitle;
	}



	public String getNewsContent() {
		return newsContent;
	}



	public void setNewsContent(String newsContent) {
		this.newsContent = newsContent;
	}



	public String getNewsAuthor() {
		return newsAuthor;
	}



	public void setNewsAuthor(String newsAuthor) {
		this.newsAuthor = newsAuthor;
	}



	public String getNewsDate() {
		return newsDate;
	}



	public void setNewsDate(String newsDate) {
		this.newsDate = newsDate;
	}


/*
	public Blob getNewsImage() {
		return newsImage;
	}
	public void setNewsImage(Blob newsImage) {
		this.newsImage = newsImage;
	}
	*/
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

public String toString() {
		
		return  " NewsID =" + newsId + "\n New Title=" + newsTitle + "\n Cantent Type= " + newsContent  + "\n Author" + newsAuthor + "\n Date" +newsDate+"\n Email="+userEmail;
     	}
   }
