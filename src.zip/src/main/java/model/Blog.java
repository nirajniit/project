package model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.stereotype.Component;

@Entity
@Table

public class Blog 
{
	
	@Id
	@GeneratedValue (strategy = GenerationType.AUTO)
	private int blogID;
	public int getBlogID() {
		return blogID;
	}



	public void setBlogID(int blogID) {
		this.blogID = blogID;
	}



	public String getBlogName() {
		return blogName;
	}



	public void setBlogName(String blogName) {
		this.blogName = blogName;
	}



	public String getBlogComment() {
		return blogComment;
	}



	public void setBlogComment(String blogComment) {
		this.blogComment = blogComment;
	}



	public Date getBlogCreatedDate() {
		return blogCreatedDate;
	}



	public void setBlogCreatedDate(Date blogCreatedDate) {
		this.blogCreatedDate = blogCreatedDate;
	}



	public String getBlogStatus() {
		return blogStatus;
	}



	public void setBlogStatus(String blogStatus) {
		this.blogStatus = blogStatus;
	}



	public int getBlogLikes() {
		return blogLikes;
	}



	public void setBlogLikes(int blogLikes) {
		this.blogLikes = blogLikes;
	}



	public String getUserEmail() {
		return userEmail;
	}



	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}



	private String blogName;
	private String blogComment;
	private Date blogCreatedDate;
	private String blogStatus;
	private int blogLikes;
	private String userEmail;
	


	public String toString()
	{
		
		
	
return " blogid  \t " + blogID + "   Blog name  \t "+  blogName  + " \t blogComment \t " + blogComment  + "\t blogStatus \t"+blogStatus+"\t blogLikes + "+blogLikes +"\t "+ userEmail;
		
		
	}	
}

