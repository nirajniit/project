package model;
import java.sql.Date;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table
    public class JobCategoryDetails {
	@Id
	private String jobCategoryId;
	public String getJobCategoryId() {
		return jobCategoryId;
	}

	public void setJobCategoryId(String jobCategoryId) {
		this.jobCategoryId = jobCategoryId;
	}

	public String getJobCategoryType() {
		return jobCategoryType;
	}

	public void setJobCategoryType(String jobCategoryType) {
		this.jobCategoryType = jobCategoryType;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getJobTypeId() {
		return jobTypeId;
	}

	public void setJobTypeId(String jobTypeId) {
		this.jobTypeId = jobTypeId;
	}

	private String jobCategoryType;
	private String jobTitle;
	private String salary;
	private String description;
	private String dateTime;
	private String status;
	private String qualification;
    private String jobTypeId;
    
   public String toString()
	{
	return "\n Id="+ jobCategoryId +"\ntitle="+  jobTitle+"\n JobType Id="+ jobTypeId + "\nJobCategoryType"+jobCategoryType+"\nSalary"+ salary+"\ndescription= "+ description +"\n dateTime="+dateTime+"\nqualification="+qualification+"\nStatus="+status;
	}
	

}
