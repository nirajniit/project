package model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table
public class JobTypeDetails {
	
	@Id
	private String jobTypeId;
	public String getJobTypeId() {
		return jobTypeId;
	}
	public void setJobTypeId(String jobTypeId) {
		this.jobTypeId = jobTypeId;
	}
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public String getCityId() {
		return cityId;
	}
	public void setCityId(String cityId) {
		this.cityId = cityId;
	}


	private String jobType;
	private String cityId;

	

	@OneToMany(cascade = CascadeType.MERGE,fetch=FetchType.EAGER,mappedBy="jobTypeId")
	List <JobCategoryDetails> jobCategoryDetails;
	
	public List<JobCategoryDetails> getJobCategoryDetails() {
		return jobCategoryDetails;
	}
	public void setJobCategoryDetails(List<JobCategoryDetails> jobCategoryDetails) {
		this.jobCategoryDetails = jobCategoryDetails;
	}
	
	
	public String toString()
	{
		return " \n JobTypeId = " + jobTypeId + " \n JobType =  " + jobType + "\n City id "+ cityId;
				
		
	}

}
