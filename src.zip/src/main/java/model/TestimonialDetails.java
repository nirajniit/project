package model;
import java.sql.Blob;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table
public class TestimonialDetails 
{
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int testiMonialId;
	private String testiMonial;
	private String testiMonialOrganization;
	private String testiMonialDateTime;
	private String testiMonialStatus;
	private String userEmail;
	private String approved;
	private String rrating;
	
	
	public String getApproved() 
	{
		return approved;
	}
	public void setApproved(String approved) 
	{
		this.approved = approved;
	}
	public String getRrating() {
		return rrating;
	}
	public void setRrating(String rrating) {
		this.rrating = rrating;
	}

	
	
	public int getTestiMonialId() {
		return testiMonialId;
	}
	public void setTestiMonialId(int testiMonialId) {
		this.testiMonialId = testiMonialId;
	}
	
	public String getTestiMonial() {
		return testiMonial;
	}

	public void setTestiMonial(String testiMonial) {
		this.testiMonial = testiMonial;
	}

	public String getTestiMonialOrganization() {
		return testiMonialOrganization;
	}
	public void setTestiMonialOrganization(String testiMonialOrganization) {
		this.testiMonialOrganization = testiMonialOrganization;
	}
	public String getTestiMonialDateTime() {
		return testiMonialDateTime;
	}

	public void setTestiMonialDateTime(String testiMonialDateTime) {
		this.testiMonialDateTime = testiMonialDateTime;
	}


	public String getTestiMonialStatus() {
		return testiMonialStatus;
	}


	public void setTestiMonialStatus(String testiMonialStatus) {
		this.testiMonialStatus = testiMonialStatus;
	}


	public String getUserEmail() {
		return userEmail;
	}


	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}


	
		
	public String toString()
	{
		return "\n TestiMonial Id= " + testiMonialId + "\n TestiMonial=" + testiMonial + "\n Organization= " + testiMonialOrganization + "\n DateTime =" + testiMonialDateTime + "\n Status ="+ testiMonialStatus;
	}
}
