package model;

import java.sql.Blob;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table
public class UserProfileDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String userName;
	private String nationality;
	private String Dob;
	private String careerLevel;
	private String currentLoction;
	private String currentPosition;
	private String currentCompany;
	private String salaryExpectaions;
	private String commitment;
	private String noticePeriod;
	private String visaStatus;
	private String hidePhoto;
	@JsonIgnore
	private Blob profileImg;
	private String dateTime;
	
	private String profileImgName;
	@JsonIgnore
	private Blob chooseFile;
	private  String cvFileName;
	
	private String education;
	private String yourCVsummary;
	private String iHavegot1;
	private String experienceIn1;
	private String iHavegot2;
	private String experienceIn2;
	private String iHavegot3;
	private String experienceIn3;
	private String iHavegot4;
	private String experienceIn4;
	private String iHavegot5;
	private String experienceIn5;
	
	private String checkBox1;
	private String checkBox2;	
	
	private String userEmail;
	

	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getProfileImgName() {
		return profileImgName;
	}

	public void setProfileImgName(String profileImgName) {
		this.profileImgName = profileImgName;
	}

	public String getCvFileName() {
		return cvFileName;
	}

	public void setCvFileName(String cvFileName) {
		this.cvFileName = cvFileName;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getDob() {
		return Dob;
	}


	public void setDob(String dob) {
		Dob = dob;
	}

	public String getCareerLevel() {
		return careerLevel;
	}

	public void setCareerLevel(String careerLevel) {
		this.careerLevel = careerLevel;
	}

	public String getCurrentLoction() {
		return currentLoction;
	}

	public void setCurrentLoction(String currentLoction) {
		this.currentLoction = currentLoction;
	}


	public String getCurrentPosition() {
		return currentPosition;
	}

	public void setCurrentPosition(String currentPosition) {
		this.currentPosition = currentPosition;
	}

	public String getCurrentCompany() {
		return currentCompany;
	}

	public void setCurrentCompany(String currentCompany) {
		this.currentCompany = currentCompany;
	}

	public String getSalaryExpectaions() {
		return salaryExpectaions;
	}
   public void setSalaryExpectaions(String salaryExpectaions) {
		this.salaryExpectaions = salaryExpectaions;
	}

	public String getCommitment() {
		return commitment;
	}

	public void setCommitment(String commitment) {
		this.commitment = commitment;
	}

	public String getNoticePeriod() {
		return noticePeriod;
	}

	public void setNoticePeriod(String noticePeriod) {
		this.noticePeriod = noticePeriod;
	}

	public String getVisaStatus() {
		return visaStatus;
	}

	public void setVisaStatus(String visaStatus) {
		this.visaStatus = visaStatus;
	}

	public String getHidePhoto() {
		return hidePhoto;
	}


	public void setHidePhoto(String hidePhoto) {
		this.hidePhoto = hidePhoto;
	}

	public Blob getProfileImg() {
		return profileImg;
	}

	public void setProfileImg(Blob profileImg) {
		this.profileImg = profileImg;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public Blob getChooseFile() {
		return chooseFile;
	}

	public void setChooseFile(Blob chooseFile) {
		this.chooseFile = chooseFile;
	}

	public String getEducation() {
		return education;
	}

	public void setEducation(String education) {
		this.education = education;
	}

   public String getYourCVsummary() {
		return yourCVsummary;
	}

	public void setYourCVsummary(String yourCVsummary) {
		this.yourCVsummary = yourCVsummary;
	}

	public String getiHavegot1() {
		return iHavegot1;
	}
	public void setiHavegot1(String iHavegot1) {
		this.iHavegot1 = iHavegot1;
	}
	public String getExperienceIn1() {
		return experienceIn1;
	}

	public void setExperienceIn1(String experienceIn1) {
		this.experienceIn1 = experienceIn1;
	}

	public String getiHavegot2() {
		return iHavegot2;
	}

	public void setiHavegot2(String iHavegot2) {
		this.iHavegot2 = iHavegot2;
	}

	public String getExperienceIn2() {
		return experienceIn2;
	}

	public void setExperienceIn2(String experienceIn2) {
		this.experienceIn2 = experienceIn2;
	}

	public String getiHavegot3() {
		return iHavegot3;
	}

	public void setiHavegot3(String iHavegot3) {
		this.iHavegot3 = iHavegot3;
	}





	public String getExperienceIn3() {
		return experienceIn3;
	}

    public void setExperienceIn3(String experienceIn3) {
		this.experienceIn3 = experienceIn3;
	}
   public String getiHavegot4() {
		return iHavegot4;
	}

	public void setiHavegot4(String iHavegot4) {
		this.iHavegot4 = iHavegot4;
	}

	public String getExperienceIn4() {
		return experienceIn4;
	}

	public void setExperienceIn4(String experienceIn4) {
		this.experienceIn4 = experienceIn4;
	}

	public String getiHavegot5() {
		return iHavegot5;
	}

	public void setiHavegot5(String iHavegot5) {
		this.iHavegot5 = iHavegot5;
	}

	public String getExperienceIn5() {
		return experienceIn5;
	}

	public void setExperienceIn5(String experienceIn5) {
		this.experienceIn5 = experienceIn5;
	}

	public String getCheckBox1() {
		return checkBox1;
	}

	public void setCheckBox1(String checkBox1) {
		this.checkBox1 = checkBox1;
	}

	public String getCheckBox2() {
		return checkBox2;
	}
   public void setCheckBox2(String checkBox2) {
 		this.checkBox2 = checkBox2;
	}
   public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String toString() 
    {
    	
		return "\n id=" + id + "\n UserName==" +userName +"\nnationality=" + nationality + "\n Dob=" + Dob + "\n careerLevel="
				+ careerLevel + "\n currentLoction=" + currentLoction + "\n currentPosition=" + currentPosition
				+ "\n currentCompany=" + currentCompany + "\n salaryExpectaions=" + salaryExpectaions + "\n commitment="
				+ commitment + "\n noticePeriod=" + noticePeriod + "\n visaStatus=" + visaStatus + "\n hidePhoto="
				+ hidePhoto+"\n BLOb"+profileImg +"\n dateTime"+dateTime +"\n UserEmail="+userEmail +"\n Choose File="+chooseFile 
				+"\n Education="+education+"yourCVsummar="+yourCVsummary+"\n IHaveGot1="+iHavegot1+"\n IHaveGot2="+iHavegot2
				+"\n IHaveGot3="+iHavegot3+"\n IHaveGot4="+iHavegot4+"\n IHaveGot4="+iHavegot4+"\n ExperienceIn1="+experienceIn1
				+"\n ExperienceIn2="+experienceIn2+"\n ExperienceIn3="+experienceIn3+"\n ExperienceIn4="+experienceIn4+"\n ExperienceIn5="+experienceIn5
				+"\n chechBox1="+checkBox1+"\n chechBox2="+checkBox2+"\n UserEmail="+userEmail+"\nProfileImgName="+profileImgName + "\n CvFileName="+cvFileName;
		
		
	}
	

}
