package dbconfig;
import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBuilder;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import model.*;



@Configuration
@ComponentScan("dbconfig")
@EnableTransactionManagement


public class ApplicationContextConfig
{
    	@Bean(name = "dataSource")
	    public static DataSource getDataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("oracle.jdbc.driver.OracleDriver");
		  // Connection string for hosting raja 
		  //dataSource.setUrl("jdbc:oracle:thin:103.120.177.113:1158//em");
		
		// Connection for Mochahosting 
		//dataSource.setUrl("jdbc:oracle:thin:@204.93.161.199:1521/new");
		//dataSource.setUrl("jdbc:oracle:thin:@204.93.161.199:1521/XE");
		//dataSource.setUsername("system");
		//dataSource.setPassword("Mohamed50");
				
		
		
		// webhosting.net Mysql 
		 
			//	dataSource.setDriverClassName("com.mysql.jdbc.Driver");
			//  dataSource.setUrl("jdbc:oracle:thin:@env-1174728.whelastic.net:8080/db1");
			//  dataSource.setUsername("root");
			//  dataSource.setPassword("c6LVoNZ43e");
			
		
		
		//dataSource.setUrl("jdbc:oracle:thin:@204.93.161.199:1558/em");
		dataSource.setUrl("jdbc:oracle:thin:@localhost:1521/XE");
		dataSource.setUsername("thegulfdb");
		dataSource.setPassword("adminworklooper");
				
		
		//dataSource.setPassword("njp3t2JyYtHndQda");
		return dataSource;
	   }

    	private static Properties getHibernateProperties()
    	{
    		Properties properties = new Properties();
    		properties.put("hibernate.show_sql", "true");
    		properties.put("hibernate.hbm2ddl.auto", "update");
    		properties.put("hibernate.dialect", "org.hibernate.dialect.OracleDialect");
    		//properties.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
			return properties;
	}

	@Autowired
	@Bean(name = "sessionFactory")
	public static SessionFactory getSessionFactory(DataSource dataSource)
	{
		LocalSessionFactoryBuilder sessionBuilder = new LocalSessionFactoryBuilder(dataSource);
		sessionBuilder.addProperties(getHibernateProperties());
		
		sessionBuilder.addAnnotatedClasses(UserDetails.class);
		sessionBuilder.addAnnotatedClasses(Blog.class);
		sessionBuilder.addAnnotatedClasses(CountryDetails.class);
		sessionBuilder.addAnnotatedClasses(CityDetails.class);
		sessionBuilder.addAnnotatedClasses(ProductDetails.class);
		sessionBuilder.addAnnotatedClasses(CategoryDetails.class);
		sessionBuilder.addAnnotatedClasses(JobTypeDetails.class);
		sessionBuilder.addAnnotatedClasses(JobCategoryDetails.class);
		sessionBuilder.addAnnotatedClasses(Message.class);
		sessionBuilder.addAnnotatedClasses(TestimonialDetails.class);
		sessionBuilder.addAnnotatedClasses(UserProfileDetails.class);
		sessionBuilder.addAnnotatedClasses(NewsDetails.class);
		sessionBuilder.addAnnotatedClasses(SubcategoryDetails.class);
		sessionBuilder.addAnnotatedClasses(ProductImageDetails.class);
		
		
		
		
		return sessionBuilder.buildSessionFactory();
	}

	@Autowired
	@Bean(name = "transactionManager")
	public HibernateTransactionManager getTransactionManager(SessionFactory sessionFactory) 
	{
		HibernateTransactionManager transactionManager = new HibernateTransactionManager(sessionFactory);
		return transactionManager;
	}

}
