var ws;

function connect() {
    var username = document.getElementById("username").value;
	http://thegulfroad.com:8889/thegulgrestapi
    //ws = new WebSocket("ws://" + thegulfroad.com + "/nn/thegulgrestapi:8889/chat/" + username);
	ws = new WebSocket("ws://http://thegulfroad.com:8889/thegulgrestapi/chat/" + username);
   alert(ws);


    ws.onmessage = function(event) {
    var log = document.getElementById("log");
        console.log(event.data);
        var message = JSON.parse(event.data);
        log.innerHTML += message.from + " : " + message.content + "\n";
    };
}

function send() {
    var content = document.getElementById("msg").value;
    var json = JSON.stringify({
        "content":content
    });

    ws.send(json);
}